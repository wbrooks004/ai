# Design System → ACSS → Bricks

## Contents

- Purpose
- Evidence Roles
- Derive Before You Configure
- Map to ACSS First
- Fill the Target Design System
- Custom Project Tokens
- Construct Bricks After ACSS
- Mockup Fidelity vs System Coherence
- Dashboard-Control Validation
- One-Off Test
- Delivery Gate

## Purpose

Use this reference when the build is driven by a brand guide, design system, Figma file, mockup, screenshot, visual reference, token set, or redesign brief.

The workflow is:

```text
design evidence
→ reusable design decisions
→ complete ACSS target configuration
→ Bricks composition using ACSS
→ dashboard-control validation
```

Do not style Bricks first and retrofit ACSS afterward.

## Evidence Roles

Treat inputs according to what they prove.

| Evidence | What it should control |
|---|---|
| explicit user/project requirements | required behavior and design intent |
| brand guide/design system | global brand roles, typography, spacing, component rules |
| Figma/mockup/screenshot | composition, hierarchy, visual relationships, repeated patterns |
| current project ACSS export | current settings state and compatible settings shape |
| example/baseline ACSS export | settings structure only unless explicitly declared project-authoritative |
| current Bricks export | existing project structure/classes/components/schema evidence |

Example exports from another site must not impose their colors, typography, toggle states, selectors, or component choices on the target project.

## Derive Before You Configure

Convert the visual reference into a reusable design-system inventory.

At minimum inspect:

- brand colors and semantic roles;
- light/dark/contextual relationships;
- body/heading families, weights, sizes, line heights, tracking;
- display/lead/eyebrow/stat or other recurring text roles;
- standard spacing rhythm;
- section rhythm;
- content/container widths and gutters;
- grid/flex patterns;
- radii, borders, dividers;
- box/drop/text shadows;
- button types and states;
- card families and variants;
- form patterns;
- icon treatment;
- surfaces and overlays;
- motion/easing;
- responsive behavior.

If a repeated design decision is visible but unnamed, infer one coherent reusable role from the evidence. Do not create multiple tokens merely because measured instances differ slightly.

## Map to ACSS First

Prefer native ACSS ownership.

| Design-system concern | Preferred owner |
|---|---|
| palette / semantic colors | ACSS Colors / Palette |
| contextual foreground/background behavior | Color Assignments / Automatic Color Relationships |
| typography | ACSS Typography |
| spacing scale | ACSS Standard Spacing |
| section rhythm | Section Spacing |
| container/content/grid gaps | Contextual / Automatic Spacing |
| content width/gutter | ACSS dimensions/layout settings |
| radius/borders | ACSS radius/border system |
| recurring shadows | ACSS shadow slots |
| buttons | ACSS Buttons |
| cards | ACSS Card Framework |
| forms | ACSS Forms + WS Forms Pro |
| icons | ACSS Icon Framework |
| surfaces | ACSS Surface system |
| overlays | Basic/Custom Overlay system |
| grids/layout | ACSS Grid/Flex/Content Grid/Recipes |
| motion | ACSS transition/effects/easing systems |

When the source export has the appropriate subsystem disabled, enable and configure it in the target if the design needs it.

A source `off` value is not a reason to bypass ACSS.

## Fill the Target Design System

A complete target configuration should not merely change the obvious brand colors while leaving unrelated stock design defaults in control.

When design evidence is sufficient, populate applicable design-facing settings so that the dashboard represents the project intentionally.

Examples:

- configure the complete active palette and relationships;
- configure body and heading typography;
- configure text and heading scales;
- configure spacing/section spacing/gutters;
- configure global radii/borders;
- configure buttons and used palette variants;
- configure Card Framework defaults/target selectors when cards exist;
- configure form system when forms exist;
- configure shadows/surfaces/overlays when the design uses recurring versions;
- configure grids/layout systems required by the page composition;
- configure focus/reduced-motion/accessibility behavior.

Preserve unrelated operational/admin/integration settings from a current project export.

## Custom Project Tokens

Do not create a parallel custom design system just because a reference design contains extra roles.

First determine whether ACSS can own the role natively.

Use a project custom property only when:

1. the value represents a real reusable project role;
2. ACSS has no appropriate native owner or the project intentionally needs a semantic alias;
3. the token is wired into ACSS/component behavior where practical;
4. it does not duplicate an entire native ACSS scale.

Project custom variables intentionally referenced by ACSS dashboard settings are approved project design tokens, not automatically hardcoding.

## Construct Bricks After ACSS

Once the target ACSS configuration is defined, build Bricks around it.

Use:

- semantic structure;
- semantic global/BEM component classes;
- ACSS behavior classes where behavior is class-activated;
- ACSS variables in controls/CSS values;
- component-local custom properties only for true component variants;
- local literal values only for genuine one-offs.

The component identity may live in a Bricks global class while its visual values remain ACSS-controlled.

Example:

```css
.service-card {
  gap: var(--card-gap);
  padding: var(--card-padding);
  border-radius: var(--card-radius);
}
```

is preferable to copying the current resolved pixel values onto each instance.

## Mockup Fidelity vs System Coherence

Match the intentional design, not measurement noise.

Normalize values when:

- repeated cards appear to use effectively the same padding;
- headings of the same role differ only by screenshot measurement noise;
- repeated section gaps vary by a few pixels without clear intent;
- equivalent buttons/cards use nearly identical geometry.

Preserve differences when they represent:

- an explicit component variant;
- hierarchy;
- a deliberate asymmetric composition;
- a one-off decorative offset;
- breakpoint-specific behavior visible in the reference.

Do not weaken design fidelity merely to force every value onto one token. The goal is the smallest coherent system that explains the design.

## Dashboard-Control Validation

For each significant repeated style, record or mentally resolve:

| Style | Intended owner | Bricks consumption |
|---|---|---|
| brand primary | ACSS Palette | `var(--primary)` / relationship behavior |
| section rhythm | Section Spacing | section behavior/variables |
| card geometry | Card Framework | targeted card class / `--card-*` |
| CTA geometry | Buttons | ACSS button behavior class |
| form fields | ACSS Forms | WS Forms integration |
| recurring shadow | ACSS shadow slot | shadow variable |
| display type | Typography/custom approved role | variable/class consuming configured value |

Fail the implementation when a value that should be changed globally from ACSS is duplicated as local Bricks styling.

## One-Off Test

Before accepting a literal or local override, ask:

1. Does this appear more than once?
2. Is it likely to change site-wide?
3. Does ACSS expose an owner?
4. Could a semantic component variable reference ACSS instead?
5. Is the difference clearly intentional in the mockup?

If the answer points to global/reusable ownership, move it upstream.

## Delivery Gate

A design-driven build is complete only when:

- ACSS target settings represent the target brand/design system;
- relevant ACSS subsystems are enabled/configured;
- Bricks structure matches the requested design;
- Bricks consumes ACSS-controlled values for reusable styling;
- repeated design decisions are not scattered as local literals;
- genuine one-off exceptions remain local;
- global ACSS edits would propagate to the expected Bricks elements.
