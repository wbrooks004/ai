# Bricks Import Reconciliation

Use this reference when output will be pasted/imported into an existing Bricks site or when dependencies may already exist.

## Separate Two Questions

1. **Artifact validity** — Is the JSON internally valid and dependency-complete?
2. **Destination reconciliation** — What happens when imported identifiers/names collide with existing site data?

Do not use successful internal validation as proof that destination reconciliation is conflict-free.

## Dependency Inventory

Identify applicable dependencies before delivery:

- global classes;
- global variables;
- components;
- pseudo-classes;
- templates;
- theme styles;
- breakpoints;
- color palettes;
- other project-global records referenced by the artifact.

Every referenced dependency must be either:
- bundled in the destination format;
- proven to exist in the target project; or
- explicitly listed as an installation/import prerequisite.

## Conflict Handling

Current Bricks import workflows may review or map conflicting reusable data. Do not assume that identical names or IDs will always be blindly overwritten.

When target-project evidence is available:
- detect name/ID collisions;
- prefer mapping to the intended existing project record when semantically identical;
- preserve distinct records when they are intentionally different;
- report ambiguous collisions instead of guessing.

## Global Import / Export

When the user is moving larger sets of related Bricks data, prefer the current Bricks Global Import/Export workflow when it better preserves dependencies than an isolated JSON fragment.

## Completion Check

Before calling an artifact import-ready, state:
- format used;
- dependencies included;
- dependencies expected to pre-exist;
- unresolved conflicts, if any;
- whether destination reconciliation was actually verified.
