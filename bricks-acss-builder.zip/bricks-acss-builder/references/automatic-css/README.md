# Automatic.css AI Knowledge Library

Source-grounded Markdown documentation library built from the official Automatic.css documentation available on 2026-08-23. The current official documentation identifies ACSS 4.x as the active line. Retained 3.x fundamentals and function pages are included only where the current site still exposes them and are labeled by version.

## Package Contents

- `knowledge/foundations/` - setup, versioning, workflow concepts, deprecations.
- `knowledge/design-system/` - backgrounds, borders, colors, effects, color scheme, shadows.
- `knowledge/layout/` - columns, dimensions, flexbox, grids, spacing, overlays.
- `knowledge/components/` - accessibility, buttons, links, cards, elements, forms, icons, typography.
- `knowledge/advanced/` - SCSS functions, mixins, and recipes.
- `knowledge/operations/` - WP-CLI reference.
- `indexes/token-index.csv` - machine-readable index of exact class, variable, recipe, mixin, function, and command tokens with file locations and version context.
- `indexes/token-index.md` - token-index usage notes and counts.
- `manifests/` - page-level source records by documentation track plus a combined source manifest.
- `package-manifest.json` - package metadata, counts, and SHA-256 checksums.

## Using as AI Project Knowledge

Upload the Markdown files under `knowledge/`. Add `indexes/token-index.md` and `indexes/token-index.csv` when the platform accepts CSV knowledge. Add `manifests/sources.csv` when answers must report official URLs or audit provenance.

Recommended project instruction:

> Use the Automatic.css knowledge files as the primary reference. Preserve classes, custom properties, recipes, mixins, commands, attributes, and syntax exactly. Prefer 4.x pages for 4.x work. Never promote a 3.x or deprecated token into 4.x guidance unless a 4.x source explicitly confirms it. When sources conflict or a file labels a source-rendered inconsistency, state the uncertainty and cite the canonical source URL. Do not invent undocumented tokens.

## Retrieval Conventions

- Each knowledge file begins with YAML metadata and ends with `## Sources`.
- Inline and fenced code preserves documented tokens. Suspected official-source typos are retained or explicitly described rather than silently normalized.
- Topic files synthesize official pages for retrieval; they are not verbatim site mirrors.
- The token index proves that a token appears in this library, not that it is active in every ACSS version. Open the referenced topic file for conditions and version status.

## Important Version Notes

- ACSS 4.x is documented as not backward compatible with 3.x.
- The 4.x overview says previously deprecated features were removed and recipes changed from `@` to `?`.
- The official 4.x overview says preset breakpoints were removed, while other current 4.x pages still document breakpoint settings, mixins, or recipes. The relevant files preserve and flag this conflict.
- The 4.x overview changes `XXL` to `2XL`, while some current topic pages still publish `xxl` tokens. Use page-level version and source notes instead of normalizing these mechanically.

## Validation

The build checks required front matter, one H1, a `## Sources` section, balanced code fences, CSV field counts, unique source URLs, token extraction, internal Markdown links, and ZIP integrity. See `package-manifest.json` for final counts.

This is an independent knowledge package derived from public official documentation. Automatic.css and AutomaticCSS are trademarks of their respective owner.

