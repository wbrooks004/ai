---
title: Automatic.css Token Index
source_scope: Derived index of exact code-form tokens in this package
version_scope: Mixed; see token-index.csv and source files
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# Token Index

The companion `token-index.csv` is the machine-readable inventory of classes, custom properties, recipes, mixins, functions, and WP-CLI command strings found in code formatting across the knowledge files. Each row includes its version context and source file location. Tokens are preserved textually; source-rendering anomalies are explained in their topic file.

## Counts

- class: 274
- command: 24
- function: 8
- mixin: 18
- recipe: 54
- variable: 462

## Use

Filter the CSV by `type` or `token`. Then open the listed knowledge file to read usage conditions, version warnings, and official source URLs. Do not treat presence in the index as proof that a token is active in every ACSS version.

## Sources

- Derived from 49 source-grounded knowledge files covering 155 official Automatic.css documentation URLs.
