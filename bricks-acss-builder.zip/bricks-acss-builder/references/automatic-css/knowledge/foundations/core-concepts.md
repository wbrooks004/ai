---
title: Automatic.css Core Concepts
source_scope: Official Automatic.css fundamentals documentation
version_scope: 3.x conceptual pages retained by the current site; 4.x differences called out
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# Core Concepts

## Version Warning

The current site links to several `/3.0/fundamentals/` pages from its 4.x welcome page. Their concepts remain useful, but their utility examples can be legacy. The 4.x overview says many utilities were removed, recipe syntax changed to `?`, `XXL` became `2XL`, and previously deprecated features were removed. Do not infer 4.x availability from a 3.x example.

## Variables and Custom Classes

ACSS defines variables at `:root`, making them site-wide. Use variables through `var()`, for example `var(--base-dark)` and `var(--space-l)`. ACSS recommends custom classes, preferably BEM-style, for reusable components and ACSS variables as their values. This preserves a single styling source of truth while retaining the framework's responsive scales.

Variables can be overridden locally:

```css
.my-card--secondary {
  --base-dark: var(--secondary);
  --white: var(--secondary-ultra-dark);
}
```

Avoid ID-level styling for reusable behavior. Utility classes are preset, narrowly scoped classes; custom classes represent a project-specific component or group.

## When to Use Utilities

Utilities are appropriate for one-off adjustments. For a component that repeats on a page or across pages, create custom classes and use ACSS variables. Utilities may be applied directly to an element, on a container when the utility is intentionally inherited/structural, and stacked when each class controls a different concern. Do not stack conflicting utilities for the same property.

## T-Shirt Sizes

The 3.x fundamentals page documents the scale `xs`, `s`, `m`, `l`, `xl`, `xxl`. The 4.x overview changes `XXL` to `2XL`. Verify the syntax for the installed major version. Common current documentation elsewhere still shows variables such as `--space-xs`, `--space-s`, `--space-m`, `--space-l`, `--space-xl`, and `--space-xxl`, which is another reason to preserve page-level version context.

## Pro Mode and Classless Workflow (3.x)

The 3.x page says Pro Mode disables utility modules while leaving variables available; “Classless Workflow” disables all utility classes. Enable these before or early in a build, because turning utilities off later can break existing markup. In 4.x, the framework is already described as variable-first and many utilities have been removed, so do not transplant the old reduction percentages or switches without checking the live 4.x dashboard.

## Deprecated or Removed Tokens

The 3.x deprecation page marks these as deprecated:

- `.text--larger`
- `.owl--{size}`
- `.pad--{size}` replaced by `.padding--{size}`
- `.pad-section--{size}` replaced by `.section--{size}`
- `.pad-header--{size}` replaced by `.header--{size}`
- Shade and Action colors
- Medium and Comp shades
- Shade, Action, White, and Black button styles

The 4.x overview says all previously deprecated features were removed. Treat the old tokens as 3.x migration/search terms, not 4.x recommendations.

## Sources

- [How to Use a Utility Class](https://docs.automaticcss.com/3.0/fundamentals/how-to-use-a-utility-class) - Version 3.x; last updated Aug 7, 2026.
- [T-Shirt Sizes for Enhanced Simplicity](https://docs.automaticcss.com/3.0/fundamentals/t-shirt-sizes-for-enhanced-simplicity) - Version 3.x; last updated Aug 7, 2026.
- [When Not to Use Utility Classes](https://docs.automaticcss.com/3.0/fundamentals/when-not-to-use-utility-classes) - Version 3.x; last updated Aug 7, 2026.
- [Deprecated Features](https://docs.automaticcss.com/3.0/fundamentals/deprecated-features) - Version 3.x; last updated Aug 7, 2026.
- [IDs vs. Classes vs. Utility Classes](https://docs.automaticcss.com/3.0/fundamentals/ids-vs-classes-vs-utility-classes) - Version 3.x; last updated Aug 7, 2026.
- [Pro Mode & Classless Workflow](https://docs.automaticcss.com/3.0/fundamentals/pro-mode-and-classless-workflow) - Version 3.x; last updated Aug 7, 2026.
- [Utility Classes: What & Why](https://docs.automaticcss.com/3.0/fundamentals/utility-classes-what-why) - Version 3.x; last updated Aug 7, 2026.
- [Variables: The Real Power of ACSS](https://docs.automaticcss.com/3.0/fundamentals/variables) - Version 3.x; last updated Aug 7, 2026.

