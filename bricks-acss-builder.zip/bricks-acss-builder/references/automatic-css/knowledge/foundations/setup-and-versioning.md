---
title: Automatic.css Setup and Versioning
source_scope: Official Automatic.css setup and welcome documentation
version_scope: 4.x, with explicitly labeled 3.x migration context
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# Setup and Versioning

## Current Documentation Baseline

The official documentation welcome page identifies the current line as **Automatic.css 4.x**. ACSS 4.x is not backward compatible with 3.x. The official recommendation is to leave existing 3.x sites on 3.x and begin new projects with 4.x. ACSS states that stability support for 3.x existing sites will continue for five years.

Key 4.x changes documented by ACSS:

- The framework is variable-first and custom-class/BEM-first; many utility modules were removed.
- Recipes use a `?` prefix instead of `@`, for example `?btn` and `?flex-grid`.
- CSS layers were added.
- The color system moved to OKLCH.
- Dark mode uses `color-scheme` and `light-dark()`; predefined transparency tokens were removed in favor of `color-mix()` and relative color syntax.
- The t-shirt label `XXL` became `2XL` in 4.x.
- Width utilities use literal 10-point increments such as `.width--60` rather than t-shirt sizes.
- Surfaces and overlays are separate systems.

### Official Source Conflict: Breakpoints

The 4.x overview says preset breakpoints were removed and calls 4.x a breakpoint-free framework. The separately published 4.x page “Website Width & Breakpoints” still documents `XL`, `L`, `M`, `S`, optional `XXL` and `XS`, and Bricks breakpoint mapping. Both pages show “Last updated on Aug 7, 2026.” Treat this as unresolved official-source inconsistency. For a live project, prefer the behavior visible in the installed 4.x dashboard and seek vendor clarification before assuming either page is authoritative.

## Installation

Install and activate the Automatic.css WordPress plugin, then enter the Automatic.css-specific license key in the dashboard License area. The vendor notes that the account may show a bundle/plan key and a separate key named with “Automatic.css”; use the Automatic.css key.

## Builder Configuration

### Etch

Etch is Digital Gravy's official builder. The documentation says ACSS requires zero configuration in Etch: install both plugins and begin building.

### Bricks

The official Bricks setup page offers downloadable settings/theme files for new projects and warns that importing them into an existing project overwrites settings/defaults. Documented important values include:

- Disable class chaining: On (required).
- HTML Font Size: `var(--root-font-size)`.
- Container width: `var(--content-width)`.
- Avoid unrelated Bricks global styles that can conflict with ACSS.

### Gutenberg

Options > Gutenberg controls palette generation/replacement, class-first workflow, blog post types, and editor background/text colors. Custom post types can be enabled with the `acss/gutenberg/allowed_post_types` filter. In 4.x, the “Load Styles in Block Editor” and “Use Block Editor for Page Building” toggles were removed because loading is automatic.

## Upgrade Scope

The published upgrade guide is specifically for moving an **ACSS 4.x prerelease** to final 4.0.0. It is not a 3.x-to-4.x migration guide. The final plugin installs separately. Back up files and database, retain the old key for rollback, install/activate final 4.0.0, set and activate the new v4 key, regenerate CSS, verify, and only then remove the prerelease plugin.

Relevant commands:

```text
wp acss license set
wp acss license activate
wp acss css regenerate
wp acss license get --format=json
wp acss status --format=json
```

For rollback:

```text
wp plugin deactivate automatic-css
wp plugin activate automaticcss-plugin
```

## Sources

- [Welcome](https://docs.automaticcss.com/) - Version 4.x; last updated Aug 7, 2026.
- [How to Install ACSS](https://docs.automaticcss.com/setup/how-to-install-acss) - Version 4.x; last updated Aug 7, 2026.
- [What's New in ACSS 4.x](https://docs.automaticcss.com/setup/whats-new-in-4) - Version 4.x; last updated Aug 7, 2026.
- [Upgrading a v4 prerelease to ACSS 4.0.0](https://docs.automaticcss.com/setup/upgrading-to-acss-4) - Version 4.x; last updated Aug 7, 2026.
- [Website Width & Breakpoints](https://docs.automaticcss.com/setup/website-width-breakpoints) - Version 4.x; last updated Aug 7, 2026.
- [Etch](https://docs.automaticcss.com/setup/builder-configuration/etch) - Version 4.x; last updated Aug 7, 2026.
- [Bricks](https://docs.automaticcss.com/setup/builder-configuration/how-to-setup-acss-with-bricks-builder) - official setup page; last updated Jul 6, 2026 in indexed source.
- [Gutenberg](https://docs.automaticcss.com/setup/builder-configuration/acss-gutenberg-setup) - official setup page; last updated Jul 6, 2026 in indexed source.

