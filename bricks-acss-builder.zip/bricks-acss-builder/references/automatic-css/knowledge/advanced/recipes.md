---
title: Automatic.css Recipe Reference
source_scope: Official Automatic.css recipe documentation
version_scope: 4.x
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# Recipe Reference

Recipes expand into CSS/JS in compatible builder CSS inputs or ACSS Custom SCSS. In 4.x they use `?`, not the 3.x `@` prefix. Many require typing the final semicolon to trigger expansion; pasted strings may not expand.

## Complete Published Recipe Inventory

### Cards, Buttons, and Accessibility

- `?card-container` adds a card container query; 3.x syntax was `@card-container`.
- `?btn` outputs local variables needed for a custom button; attach it to a class such as `.btn--custom` so global `.btn--` defaults also apply.
- `?clickable-parent` expands a heading link's clickable area; apply to the heading containing the link and set its parent to `position: relative`.
- `?focus-parent` moves internal-link focus indication to the parent; commonly paired with `?clickable-parent`.
- `?concentric-radius` calculates outer radius from inner radius and padding. It uses local `--padding` and defaults the inner radius to `var(--radius)`.

### Colors, Columns, and Grids

- Color: `?{color-name}-clr`.
- Shade: `?{color-name}-{shade}-clr`.
- `?columns` creates responsive text-flow columns and exposes `--col-count`, `--col-min-width`, `--col-rule-style`, `--col-rule-width`, `--col-rule-color`, `--col-gap`, `--row-gap`.
- `?content-grid;` creates a content grid and emits `%root%`. Assign zones with `grid-column`, including `feature`.
- `?grid-1` through `?grid-12`.
- Unbalanced grids: `?grid-1-2`, `?grid-1-3`, `?grid-2-1`, `?grid-2-3`, `?grid-3-1`, `?grid-3-2`.
- `?auto-grid` exposes `--column-count` and `--min`.
- `?variable-grid` exposes `--min`.

### Dividers, Flex, and Fades

- `?divider-all`, `?divider-bottom`, `?divider-top`.
- `?flex-row`, `?flex-column`.
- Centering: `?center-all`, `?center-left`, `?center-right`, `?center-top`, `?center-bottom`.
- `?flex-grid` exposes `--gap` (default `var(--grid-gap, 1.5rem)`), `--columns` (default `3`), and `--stretch` (default `0`; use `1` to stretch).
- Fades: `?fade-block;`, `?fade-inline;`, `?fade-top;`, `?fade-right;`, `?fade-bottom;`, `?fade-left;`. Local control: `--fade-amount`.

### Authoring and Queries

- `?property;` expands Houdini custom-property declaration syntax.
- `?ipsum-short` expands a short lede-style dummy paragraph.
- `?script` expands `<script type="module"> </script>`.
- `?list-none` resets list styling; the related utility is `.list--none`.
- Max-width queries: `?breakpoint-xs`, `?breakpoint-s`, `?breakpoint-m`, `?breakpoint-l`, `?breakpoint-xl`, `?breakpoint-xxl`.
- Min-width queries: `?breakpoint-up-xs`, `?breakpoint-up-s`, `?breakpoint-up-m`, `?breakpoint-up-l`, `?breakpoint-up-xl`, `?breakpoint-up-xxl`.
- `?query-children` queries children of a parent query loop in compatible builders.
- `?line-clamp` uses local `--line-count`.

The breakpoint recipe page is published inside the 4.x sidebar, but the 4.x overview says preset breakpoints were removed. Preserve the recipes as documented and verify live availability before relying on them.

### Overlap

- `?overlap;` creates a background-like overlap within the target box.
- `?overlap-alt;` applies background to the adjacent sibling and extends it upward.
- Custom properties are documented as `--background`, `--foreground`, `--overlap-amount`, `--overlay`.

The official “Native Properties” bullet list visually renders these four with an en dash (`–background`, etc.), but its surrounding prose and examples use valid double-hyphen CSS custom properties. This library preserves the valid code tokens and records the rendering issue here.

## Sources

- [Introduction to Recipes](https://docs.automaticcss.com/recipes) - Version 4.x; last updated Aug 7, 2026.
- [Card Container](https://docs.automaticcss.com/recipes/card-container-recipe), [Button](https://docs.automaticcss.com/recipes/button-recipes), [Accessibility](https://docs.automaticcss.com/recipes/accessibility-recipes), [Border Radius](https://docs.automaticcss.com/recipes/border-radius-recipes), [Color](https://docs.automaticcss.com/recipes/color-recipes), [Column](https://docs.automaticcss.com/recipes/column-recipes), [Content Grid](https://docs.automaticcss.com/recipes/content-grid-recipe) - Version 4.x; last updated Aug 7, 2026.
- [Custom Property](https://docs.automaticcss.com/recipes/custom-property-recipes), [Divider](https://docs.automaticcss.com/recipes/divider-recipes), [Flex](https://docs.automaticcss.com/recipes/flex-recipes), [Gradient Fades](https://docs.automaticcss.com/recipes/gradient-fades), [Grid](https://docs.automaticcss.com/recipes/grid-recipes) - Version 4.x; last updated Aug 7, 2026.
- [Ipsum](https://docs.automaticcss.com/recipes/ipsum-recipes), [Javascript](https://docs.automaticcss.com/recipes/javascript-recipes), [List](https://docs.automaticcss.com/recipes/list-recipes), [Media Query](https://docs.automaticcss.com/recipes/media-query-recipes), [Overlap](https://docs.automaticcss.com/recipes/overlap-recipes), [Query Loop](https://docs.automaticcss.com/recipes/query-loop-recipes), [Text](https://docs.automaticcss.com/recipes/text-recipes) - Version 4.x; last updated Aug 7, 2026.

