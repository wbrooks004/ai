---
title: Automatic.css Functions and Mixins
source_scope: Official Automatic.css functions and mixins documentation
version_scope: Mixins 4.x; functions currently published under 3.x paths
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# Functions and Mixins

## Execution Context

ACSS functions and mixins are for the Custom SCSS area of the ACSS dashboard. They do not work in builder CSS inputs or vanilla CSS. Functions used to create a custom property in `:root` may require SCSS interpolation such as `#{fluid(28,60)}`.

## Functions (Published as 3.x)

- `calc()` is standard CSS. ACSS examples combine it with variables, such as `calc(var(--content-gap) / 2)`.
- `ctr(24)` converts a pixel number to rem based on the site's root font size.
- `fluid(28,60)` generates a responsive clamp from minimum and maximum pixel values.
- `percent(5 * 5)` returns a whole-number percentage (`25%` in the official example).
- `pow($my-text-size, 3)` performs exponentiation.
- `rem($vp-max * .33)` attaches the rem unit to a unitless number/calculation.

## Mixins (4.x)

### Interaction and Card Mixins

- `@include clickable-parent;` applies to the actual `a` or `button`; the containing block must be `position: relative`.
- `@include focus-parent(shadow);` or `@include focus-parent(outline);` moves the focus presentation to the parent.
- `@include card-container("inline-size > 767px") { ... }` applies a container query to a Card Framework card. Card Framework and Auto Container Query support must be enabled.

The `.clickable-parent`, `.focus-parent`, `.focus-parent--shadow`, and `.focus-parent--outline` utility classes are removed in 4.x. Use `?clickable-parent`, `?focus-parent`, or the mixins.

### Button Mixin

Use `@include btn(primary);`. Valid documented styles are:

```text
primary primary-light primary-dark
secondary secondary-light secondary-dark
tertiary tertiary-light tertiary-dark
accent accent-light accent-dark
base base-light base-dark
neutral neutral-light neutral-dark
```

Each supports an outline form using `.btn--outline`, such as `@include btn("primary.btn--outline");`. Deprecated Action, White, Black, and Shade styles are unavailable in 4.x.

### Grid and Layout Mixins

- `auto-grid($column-count, $min, $flow, $force-even-column-count);` requires `$column-count`. `$flow` accepts `auto-fit` or `auto-fill`; `$force-even-column-count` accepts `true` or `false`.
- `@include content-grid;` creates a content grid; assign children with values such as `grid-column: feature`.
- `@include breakpoint(extension) { ... }` is max-width; `@include breakpoint-up(extension) { ... }` is min-width. The published mixin page names `xl`, `l`, `m`, `s` as extensions, but the 4.x overview separately says preset breakpoints were removed. Treat this as a source conflict.
- `@include center($alignment, $output);` supports alignments `all`, `left`, `right`, `top`, `bottom` and outputs `full`, `core`, `tokens`. Defaults: alignment `all`; output optional.

### Border and Type Mixins

- `@include border($style, $position, $radius);`. Defaults: main site style, `$position: null`, and `var(--radius)`. Example: `@include border(light, block-start, var(--radius-l));`.
- `@include heading-style(h2);` applies global and level-specific heading properties that are non-null.
- `@include text-style(l);` applies global and size-specific text properties that are non-null.
- `@include line-clamp($line-count);` clamps text to the supplied line count.

### Icon, Fade, Texture, and Overlay Mixins

- `@include icon;`, `@include icon(dark);`, or `@include icon(dark, off);`. `$style` accepts `light` or `dark`; `$box-style` uses `box` to enable the box style.
- `@include fade($axis, $amount);`. Axes: `block`, `inline`, `top`, `right`, `bottom`, `left`; amount defaults to `25%`.
- `@include texture(1);` applies numbered texture 1.
- `@include texture-overlay(1);` applies a numbered texture as an overlay when “Enable Overlay Class” is on.

### Line Clamp Classes

The official page lists `line-clamp--1`, `line-clamp--2`, `line-clamp--3`, `line-clamp--4`, `line-clamp--5`, and `line-clamp--custom`. Elsewhere ACSS class syntax normally includes a leading dot; the page's list omits it, while prose explicitly uses `.line-clamp--custom`. Preserve the selector as `.line-clamp--custom` in CSS. Pair custom count with local `--line-count`. Recipe: `?line-clamp;`.

## Sources

- [Calc()](https://docs.automaticcss.com/3.0/functions/calc), [ctr()](https://docs.automaticcss.com/3.0/functions/ctr), [fluid()](https://docs.automaticcss.com/3.0/functions/fluid-function), [percent()](https://docs.automaticcss.com/3.0/functions/percent-function), [pow()](https://docs.automaticcss.com/3.0/functions/pow-function), [rem()](https://docs.automaticcss.com/3.0/functions/rem-function) - Version 3.x; last updated Aug 7, 2026.
- [Clickable Parent](https://docs.automaticcss.com/mixins/clickable-parent), [Focus Parent](https://docs.automaticcss.com/mixins/focus-parent), [Card Container Mixin](https://docs.automaticcss.com/mixins/card-container-mixin), [Button Mixins](https://docs.automaticcss.com/mixins/button-mixins) - Version 4.x; last updated Aug 7, 2026.
- [Auto Grid Mixin](https://docs.automaticcss.com/mixins/auto-grid-mixin), [Border Mixin](https://docs.automaticcss.com/mixins/border-mixin), [Breakpoint Mixins](https://docs.automaticcss.com/mixins/breakpoint-mixins), [Centering Mixin](https://docs.automaticcss.com/mixins/center-mixin), [Content Grid Mixin](https://docs.automaticcss.com/mixins/content-grid-mixin) - Version 4.x; last updated Aug 7, 2026.
- [Gradient Fades](https://docs.automaticcss.com/mixins/gradient-fades), [Heading & Text Style Mixins](https://docs.automaticcss.com/mixins/heading-text-style-mixins), [Icon Mixin](https://docs.automaticcss.com/mixins/icon-mixin), [Line Clamp Utilities](https://docs.automaticcss.com/mixins/line-clamp-utilities), [Texture & Overlay Mixins](https://docs.automaticcss.com/mixins/texture-overlay-mixins), [What are Mixins?](https://docs.automaticcss.com/mixins/what-are-mixins) - Version 4.x; last updated Aug 7, 2026.

