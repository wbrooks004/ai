---
title: Automatic.css WP-CLI Reference
source_scope: Official Automatic.css WP-CLI documentation
version_scope: 4.x
retrieved_at: 2026-08-23
official_base_url: https://docs.automaticcss.com/
---

# WP-CLI Reference

Prerequisites: WP-CLI, ACSS 4.x active, and shell access to the WordPress installation. Commands use the `wp acss` namespace.

## Settings

```text
wp acss settings get [<key>] [--format=<format>]
wp acss settings set <key> <value> [--force] [--skip-css]
wp acss settings list [--search=<pattern>] [--format=<format>]
wp acss settings export [--file=<path>]
wp acss settings import <file> [--force] [--skip-css] [--yes]
wp acss settings reset [--skip-css] [--yes]
```

`get` formats: `json`, `yaml`, `var_export`. `list` formats: `table`, `json`, `csv`, `yaml`, `count`. Import replaces all settings; export first. Reset wipes dashboard configuration. `--force` bypasses validation; `--skip-css` delays CSS regeneration.

## CSS and Status

```text
wp acss css regenerate
wp acss status [--format=<format>] [--section=<section>]
```

Status formats: `text`, `json`, `yaml`. Sections: `plugin`, `integrations`, `css`, `settings`, `flags`. CSS regeneration overwrites compiled outputs without changing saved settings and is safe to repeat.

## Logs

Files: `wp-content/uploads/automatic-css/activity.log` and `debug.log`.

```text
wp acss logs tail [--events=<n>] [--lines=<n>] [--type=<type>] [--follow]
wp acss logs clear [--type=<type>] [--yes]
wp acss logs path [--format=<format>]
```

Tail type: `activity` (default) or `debug`; defaults are `--events=20` and `--lines=100`. Clear type: `activity`, `debug`, or `all`. Path formats: `table`, `json`, `yaml`.

## Doctor

```text
wp acss doctor [--format=<format>] [--fix]
```

Formats: `text`, `json`. Checks environment, filesystem, plugin state, config, CSS, integrations, and recent activity. `--fix` currently creates the CSS uploads directory when missing; other checks remain read-only.

## Feature Flags

Priority: `flags.user.json`, then `flags.dev.json`, then canonical `flags.json`. Only flags declared in `flags.json` are valid.

```text
wp acss flags list [--format=<format>]
wp acss flags get <flag>
wp acss flags set <flag> <value>
wp acss flags unset <flag>
wp acss flags path [--format=<format>]
```

Flag values: `on`, `off`. Regenerate CSS after a change when the flag may affect compiled output.

## License

```text
wp acss license get [--format=<format>] [--show-key]
wp acss license set
wp acss license activate
wp acss license deactivate
```

Do not pass license keys as arguments. `set` reads a hidden prompt or standard input. `--show-key` exposes the full secret. For automation:

```text
printf '%s' "$ACSS_LICENSE_KEY" | wp acss license set
wp acss license activate
wp acss license get --format=json
```

Store `$ACSS_LICENSE_KEY` in a secret store.

## Sources

- [WP-CLI Commands](https://docs.automaticcss.com/cli) - Version 4.x; last updated Aug 7, 2026.
- [wp acss settings](https://docs.automaticcss.com/cli/settings), [wp acss css](https://docs.automaticcss.com/cli/css), [wp acss status](https://docs.automaticcss.com/cli/status) - Version 4.x; last updated Aug 7, 2026.
- [wp acss logs](https://docs.automaticcss.com/cli/logs), [wp acss doctor](https://docs.automaticcss.com/cli/doctor), [wp acss flags](https://docs.automaticcss.com/cli/flags), [wp acss license](https://docs.automaticcss.com/cli/license) - Version 4.x; last updated Aug 7, 2026.

