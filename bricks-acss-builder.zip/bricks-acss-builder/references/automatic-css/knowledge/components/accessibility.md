---
title: "Accessibility"
source_scope: "Official Automatic.css 4.x Accessibility sidebar: Clickable Parent, Focus Styling, Hidden Accessible Class, Focus Parent, Reduce Motion"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Accessibility

AI retrieval reference for ACSS accessibility behavior. Tokens below preserve the official rendering, including removed 3.x identifiers.

## Clickable Parent

Wrapping a whole card in one link creates poor semantics and poor assistive-technology output. ACSS instead extends the clickable area of a meaningful heading link with an absolutely positioned pseudo-element.

- Recommended recipe: `?clickable-parent`.
- SCSS mixin: `@include clickable-parent`.
- The parent must be `position: relative`; the heading must contain an `<a>`.
- The documentation's recipe paragraph says to apply the recipe to the parent containing the link. The mixin must be placed on the actual `a` or `button` element in an SCSS stylesheet.

```scss
.clickable-card {
    position: relative;
}
.clickable-card__heading a {
    @include clickable-parent;
}
```

When multiple child links exist, special handling is required and clickable parent may be inadvisable.

In 4.0, `.clickable-parent` was removed. Use `?clickable-parent`; `@include clickable-parent` remains available.

## Global Focus Styling

Configure at Additional Styling > Focus. Choose `outline` or `box-shadow`; configure focus color, width, and, for outline only, offset. All focus styling uses the locally scoped variable `--focus-color`, so override it on an element or ancestor:

```css
.dark-section {
    --focus-color: var(--white);
}
```

In 4.0, `.focus--{color}` utilities such as `.focus--primary` and `.focus--secondary` were removed. Set `--focus-color` directly. The dashboard panel moved from Accessibility to Focus under Additional Styling.

## Hidden Accessible Class

Use `.hidden-accessible` to visually hide descriptive text while retaining it for assistive technology and search engines. An `aria-label` is an alternative, but it may be unavailable in a builder, omitted from translation, or forgotten during edits. ACSS displays an editor-only accessibility icon beside hidden text.

```html
<a href="#">
    <i class="fb-icon"></i>
    <span class="hidden-accessible">Follow us on Facebook</span>
</a>
```

## Focus Parent

Focus parent removes focus styling from focusable children and applies the indication to the parent using `:focus` and `:focus-within`.

- Recommended recipe: `?focus-parent`, applied to the parent.
- SCSS mixin: `@include focus-parent`.
- Mixin options: `shadow` or `outline`.
- Mixins work in an SCSS stylesheet such as ACSS Custom SCSS, not vanilla CSS or builder CSS inputs.

```scss
.clickable-card {
    position: relative;
    @include focus-parent(shadow);
}
.clickable-card__heading a {
    @include clickable-parent;
}
```

In 4.0, `.focus-parent`, `.focus-parent--shadow`, and `.focus-parent--outline` were removed. `?focus-parent`, `@include focus-parent(shadow)`, and `@include focus-parent(outline)` are the current mechanisms.

## Reduce Motion

The switch at Options > Defaults & Misc > Reduce Motion is on by default. Leave it enabled to respect the OS-level `prefers-reduced-motion` preference.

When `prefers-reduced-motion: reduce` is active:

- Scroll animations (On Enter, On Exit): `animation: none` and immediate appearance.
- On Visible: `transition: none` and immediate appearance.
- Hover effects: `transition: none`; `translate` and `scale` transforms reset to `none`.

In 4.0 this setting moved from Options > Accessibility to Options > Defaults & Misc.

## Sources

- [Clickable Parent](https://docs.automaticcss.com/accessibility/clickable-parent) — last updated Aug 7, 2026.
- [Focus Styling](https://docs.automaticcss.com/accessibility/focus-styling) — last updated Aug 7, 2026.
- [Hidden Accessible Class](https://docs.automaticcss.com/accessibility/hidden-accessible-class) — last updated Aug 7, 2026.
- [Focus Parent](https://docs.automaticcss.com/accessibility/focus-parent) — last updated Aug 7, 2026.
- [Reduce Motion](https://docs.automaticcss.com/accessibility/reduce-motion) — last updated Aug 7, 2026.
