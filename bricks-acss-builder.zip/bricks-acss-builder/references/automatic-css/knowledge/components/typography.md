---
title: "Typography"
source_scope: "Official Automatic.css 4.x Typography sidebar: Custom Fonts, Default Typography Styling, Fluid Headings, Fluid Text, Marker Classes, Text Classes, Text & Heading Line Length, Typography Variables"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Typography

## Custom Fonts

Typography > Fonts registers up to five self-hosted fonts and emits `@font-face`. Prefer `.woff2` and a relative path such as `/wp-content/uploads/2025/your-font.woff2`.

Fields and accepted tokens:

- Font Type: Static or Variable.
- Font Family: arbitrary reference name such as `Inter`.
- Font File Path: relative file path.
- Font Format: `woff2`, `woff`, `truetype`, or `opentype`.
- Font Style: optional `normal`, `italic`, or `oblique`.
- Font Weight: static fonts only, such as `400`, `600`, `700`.
- Font Display: optional `auto`, `block`, `swap`, `fallback`, or `optional`.
- Font Stretch: variable fonts only, such as `normal`, `condensed`, `expanded`.
- Font Variation Settings: variable fonts only, for example `'wght' 700, 'slnt' 0`.
- Fallbacks optionally add a second Font File Path and Font Format.

Apply the registered Font Family in heading/text defaults or CSS:

```css
.my-element {
  font-family: "Inter", sans-serif;
}
```

## Default Typography Styling

Typography > Headings/Text controls Root Font Size; Base Heading/Text Size min/max; mobile/desktop Type Scale; Font Family; and global color, line-height, font-weight, letter-spacing, max-width, font-style, text-transform, and text-wrap. Each heading and text level also has granular defaults.

Smart Line Height uses a formula adding desired leading to twice the typeface x-height; adjust the `ex` value inside `calc()` if needed. Bricks does not receive heading/text max-width defaults because of its own defaults. `text-wrap: pretty` is the default; `balance` suits headings of at most four lines; `wrap` disables this behavior.

## Fluid Headings

Set Typography > Headings Base Heading Size. It is the desktop H4 size and scale starting point. Desktop and mobile scales may differ; a hierarchy requires scale values greater than `1`. Individual min/max overrides remove only that size from the scale. H5/H6 minimums protect against inaccessible results.

Bridge syntax: `var(--h{large}-to-h{small})`.

- `--h1-to-h2`, `--h1-to-h3`, `--h1-to-h4`, `--h1-to-h5`, `--h1-to-h6`
- `--h2-to-h3`, `--h2-to-h4`, `--h2-to-h5`, `--h2-to-h6`
- `--h3-to-h4`, `--h3-to-h5`, `--h3-to-h6`
- `--h4-to-h5`, `--h4-to-h6`
- `--h5-to-h6`

The left heading is the desktop maximum; the right is the mobile minimum:

```css
.hero-heading {
  font-size: var(--h1-to-h3);
}
```

Use the `fluid()` function to create custom heading sizes.

## Fluid Text

Root Font Size should be a percentage; typical values are `100%` (default) or `62.5%`. ACSS converts stated pixel inputs to rem and uses rem, em, and dynamic units. Base text is desktop paragraph/M size; S and XS scale down, larger sizes scale up. Desktop and mobile scales are independent and must be greater than `1` for hierarchy. Per-size min/max overrides feed `clamp()` and `calc()`.

Bridge syntax: `var(--text-{large}-to-{small})`.

- `--text-xxl-to-xl`, `--text-xxl-to-l`, `--text-xxl-to-m`, `--text-xxl-to-s`, `--text-xxl-to-xs`
- `--text-xl-to-l`, `--text-xl-to-m`, `--text-xl-to-s`, `--text-xl-to-xs`
- `--text-l-to-m`, `--text-l-to-s`, `--text-l-to-xs`
- `--text-m-to-s`, `--text-m-to-xs`
- `--text-s-to-xs`

```css
.feature-description {
  font-size: var(--text-xl-to-s);
}
```

Use `fluid()` for custom text sizes.

## Marker Classes

Example `.marker--primary`. General syntax is `.marker--[color]-[shade]`, available for every active color and shade. Action color is deprecated. The source example contains the prose typo “Listen item 3”; identifiers are unaffected.

## Text Classes

All patterns use `.text--`:

- Size: `.text--{size}`; `xs`, `s`, `m`, `l`, `xl`, `xxl`.
- Color: `.text--{color}`; any ACSS color except transparency colors.
- Weight: `.text--{weight}`; `100`–`900`.
- Style: `.text--{style}`; `italic`, `oblique`.
- Decoration: `.text--{decoration}`; `none`, `underline`, `underline-wavy`, `underline-dotted`, `underline-double`, `underline-dashed`, `overline`, `line-through`.
- Transform: `.text--{transform}`; `none`, `uppercase`, `lowercase`, `capitalize`.
- Alignment: `.text--{alignment}`; `left`, `center`, `right`, `justify`.

They work directly on text or on an ancestor containing multiple text elements.

## Line Length

Typography inputs accept any unit; use an explicit character value such as `48ch`. The docs recommend capping body text generally around 50–60 characters for 16–20px text. A configured cap affects paragraphs, list content, and matching size classes such as `.text--l`. Heading sizes have parallel controls. Inputs are blank by default.

## Typography Variables

### Sizes

- `--h1`, `--h2`, `--h3`, `--h4`, `--h5`, `--h6`
- `--text-xxl`, `--text-xl`, `--text-l`, `--text-m`, `--text-s`, `--text-xs`

### Global headings

- `--heading-font-family` (if declared)
- `--heading-color` (if declared)
- `--heading-line-height` (default)
- `--heading-font-weight` (default)
- `--heading-font-style` (if declared)
- `--heading-letter-spacing` (if declared)
- `--heading-text-transform` (if declared)
- `--heading-text-wrap` (default)

Per-level pattern, shown officially for H1 and applicable to other heading levels:

- `--h1-font-family`, `--h1-color`, `--h1-line-height`, `--h1-font-weight`, `--h1-font-style`, `--h1-letter-spacing`, `--h1-text-transform` (when declared)
- `--h1-max-width` (default)

### Global text

- `--text-font-family` (if declared)
- `--text-color` (if declared)
- `--text-line-height` (default)
- `--text-font-weight` (default)
- `--text-font-style` (if declared)
- `--text-letter-spacing` (if declared)
- `--text-text-transform` (if declared)
- `--text-max-width` (if declared)
- `--text-text-wrap` (default)

Per-size pattern, shown officially for XL and applicable to other text sizes:

- `--text-xl-line-height`, `--text-xl-font-weight`, `--text-xl-font-style`, `--text-xl-letter-spacing`, `--text-xl-text-transform` (when declared)
- `--text-xl-max-width` (default)

### Examples

```css
.my-special-heading {
    font-size: var(--h4);
}
```

```css
.my-custom-component {
    font-family: var(--heading-font-family);
}
```

Official advanced example, preserving source-rendered units:

```css
.fancy-heading {
    --heading-font-family: "Birthstone", cursive;
    --heading-color: var(--accent);  /* see color palette documentation */
    --heading-letter-spacing: 0.0125 em;
    --heading-line-height: calc(6 px + 2 ex);
    font-size: var(--h1);
}
```

Potential source issue: `0.0125 em`, `6 px`, and `2 ex` render with spaces; preserved exactly.

## Sources

- [Custom Fonts](https://docs.automaticcss.com/typography/custom-fonts) — last updated Aug 7, 2026.
- [Default Typography Styling](https://docs.automaticcss.com/typography/default-typography-styling) — last updated Aug 7, 2026.
- [Fluid Headings](https://docs.automaticcss.com/typography/fluid-headings) — last updated Aug 7, 2026.
- [Fluid Text](https://docs.automaticcss.com/typography/fluid-text) — last updated Aug 7, 2026.
- [Marker Classes](https://docs.automaticcss.com/typography/marker-classes) — last updated Aug 7, 2026.
- [Text Classes](https://docs.automaticcss.com/typography/text-classes) — last updated Aug 7, 2026.
- [Text & Heading Line Length](https://docs.automaticcss.com/typography/text-heading-line-length) — last updated Aug 7, 2026.
- [Typography Variables](https://docs.automaticcss.com/typography/typography-variables) — last updated Aug 7, 2026.
