---
title: "Cards"
source_scope: "Official Automatic.css 4.x Cards sidebar: Card Framework Philosophy, Card Workflow, Card Styling, Card Targeting, Card Color Scheme"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Cards

## Framework Model and Workflow

The optional Card Framework centralizes padding, gap, radius, typography, colors, media, icon, avatar, border, and shadow styling. Enable it before building cards, explicitly add each wrapper selector to Card Selectors, configure defaults while building the first card, follow recognized BEM patterns, override with tokens, and reserve manual CSS for unique properties.

The philosophy page contrasts duplicated hard values with shared tokens. Its token-based illustration is:

```css
.service-card {
    padding: var(--card-padding);
    border-radius: var(--card-radius);
    gap: var(--card-gap);
}
.team-card {
    padding: var(--card-padding);
    border-radius: var(--card-radius);
    gap: var(--card-gap);
}
```

Recognized descendants:

- `__media` for featured media.
- `__avatar` for profile images.
- `[data-icon]` for icons; the data attribute is required.
- Standard heading elements `h1`–`h6`.

Example token override:

```css
.pricing-card {
    --card-padding: var(--space-l);
    --card-heading-size: var(--h2);
}
```

## Styling

Configure Cards > Card Styling > Styling Options. Main controls cover background and foreground; card padding/content gap; heading/text sizes; concentric radius, borders and radius; links/buttons; `[data-icon]` icons and optional boxed styling; `__avatar` avatars; `__media` media; and Card Shadow such as `var(--box-shadow-1)`.

Avatar controls are size, border width/style/color, radius (`50vw` makes a circle), and aspect ratio (`1` for circles). Media controls are radius, aspect ratio, and object fit. Boxed icons add padding, border width/style/color, radius, and background.

Concentric Radius options:

- Off: no math; set the card Border Radius directly.
- Standard: outer radius is expanded as `--radius + --card-padding`; inner items use global `--radius`.
- Reverse: outer card stays at global `--radius`; inner radius is `--radius - --card-padding`, clamped to Minimum Radius (default `4px`).

Cards default to `display: flex` and `flex-direction: column`. Enable Default Cards to Display Grid under Card Options to use grid.

Full override example:

```css
.pricing-card {
    --card-padding: var(--space-l);
    --card-heading-size: var(--h2);
    --card-radius: var(--radius-l);
}
```

Move the framework values to an inner wrapper when the outer card must have no padding/gap:

```css
.article-card {
    padding: 0;
    gap: 0;
}
.article-card__content-wrapper {
    padding: var(--card-padding);
    gap: var(--card-gap);
}
```

## Card Variables

- `--card-padding`
- `--card-gap`
- `--card-radius`
- `--card-min-radius`
- `--card-border-width`
- `--card-border-style`
- `--card-border-color`
- `--card-background`
- `--card-heading-size`
- `--card-heading-color`
- `--card-text-size`
- `--card-text-color`
- `--card-link-color`
- `--card-link-color-hover`
- `--card-button-font-size`
- `--card-icon-size`
- `--card-icon-color`
- `--card-avatar-size`
- `--card-avatar-radius`
- `--card-media-radius`
- `--card-media-aspect-ratio`
- `--card-shadow`

## Explicit Targeting

At Cards > Card Options > Card Selectors, enter a comma-separated list:

```text
.service-card, .article-card, .media-card, .team-card
```

Target wrapper classes, not descendants. Recommended consistent names include `.service-card`, `.team-card`, `.testimonial-card`, `.pricing-card`, and `.blog-card`.

Apply the framework without adding a dashboard selector by using the SCSS mixin:

```scss
.custom-element {
    @include card;
}
```

Automatic card targeting was removed in 4.0; every selector must be explicit.

## Card Color Scheme

Prerequisite: enable Colors > Color Scheme. Set Cards > Card Styling > Default Card Scheme to Inherit, Light, or Dark. Inherit follows the parent/site scheme.

Per-card modifiers are detected anywhere in the class name:

```html
<!-- Force this card to be dark regardless of default -->
<div class="service-card--dark">
    ...
</div>
<!-- Force this card to be light regardless of default -->
<div class="testimonial-card--light">
    ...
</div>
```

The current system uses CSS `color-scheme`; recognized modifiers are `--light` and `--dark`. In 4.0 this replaced the separate light/dark class systems and added Inherit.

The page's explanatory CSS pattern is:

```css
.my-card {
    /* Light scheme styles apply by default */
    background: var(--white);
    color: var(--text-dark);
}
@media (prefers-color-scheme: dark) {
    .my-card {
        /* Dark scheme styles when user prefers dark */
        background: var(--neutral-dark);
        color: var(--text-light);
    }
}
```

## Source-Rendered Inconsistencies

The philosophy page's illustrative “traditional” CSS renders `2 rem`, `8 px`, and `1 rem`. They are examples of duplicated hard values, not recommended framework syntax, and are preserved here as a traceability note rather than silently normalized.

## Sources

- [Card Framework Philosophy](https://docs.automaticcss.com/cards/card-framework-philosophy) — last updated Aug 7, 2026.
- [Card Workflow](https://docs.automaticcss.com/cards/card-workflow) — last updated Aug 7, 2026.
- [Card Styling](https://docs.automaticcss.com/cards/card-styling) — last updated Aug 7, 2026.
- [Card Targeting](https://docs.automaticcss.com/cards/card-targeting) — last updated Aug 7, 2026.
- [Card Color Scheme](https://docs.automaticcss.com/cards/card-color-scheme) — last updated Aug 7, 2026.
