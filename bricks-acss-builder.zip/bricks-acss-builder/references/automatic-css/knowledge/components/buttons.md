---
title: "Buttons"
source_scope: "Official Automatic.css 4.x Buttons sidebar: Button Styling, Button Classes, Button Variables, Outline Buttons, Gradient Outline Buttons, Auto Button Styling & Exclusions"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Buttons

## Dashboard Styling

Configure global defaults under Buttons & Links. Defaults apply to every button color: block/inline padding, minimum width, line height, letter spacing, font weight/family/style, text transform, text decoration and hover decoration, optional custom min/max text size, border width/style/radius, and transition. The docs recommend `em` padding, line height `1`, and dashboard radius rather than `.rounded` utilities.

Active color families are Primary, Secondary, Tertiary, Accent, Base, and Neutral; each supports Light and Dark variants. Styles for inactive palette colors do not load. Solid, outline, and light/dark groups can also be disabled individually.

Per-style controls are background, background hover, text, text hover, border, border hover, and focus color. Prefer color variables for color-scheme compatibility.

Locally override tokens on an individual selector or context. The source renders spaced units exactly as below; see Source-rendered inconsistencies.

```css
#btn123 {
    --btn-padding-block: 2 em;
    --btn-padding-inline: 4 em;
    --btn-font-weight: 900;
    --btn-background: var(--primary-dark);
    --btn-background-hover: var(--primary-ultra-dark);
}
```

```css
body.custom .btn--primary {
    --btn-padding-block: 2 em;
    --btn-padding-inline: 4 em;
    --btn-font-weight: 900;
    --btn-background: var(--primary-dark);
    --btn-background-hover: var(--primary-ultra-dark);
}
```

Add `.unrelate` to a button to prevent automatic color relationships. Any class beginning `.btn--` receives global button defaults automatically.

## Button Classes

- Namespace: `.btn--` (not `.button`).
- Solid color: `.btn--primary`; other active colors are secondary, tertiary, accent, base, and neutral.
- Variant syntax: `.btn--{color}-{variant}`, for example `.btn--primary-light`. Use the variant independently, not together with the main color class.
- Outline: combine `.btn--{color}` with `.btn--outline`. Outline supports light/dark variants.
- Size: `.btn--{size}` where sizes are `xs`, `s`, `m`, `l`, `xl`, `xxl`; examples `.btn--l` and `.btn--s`.
- Example combination: `.btn--primary` `.btn--outline` `.btn--s`. Class order does not matter.

Deprecated 4.0 removals: action, white, black, and shade button styles. Solid and outline border width is unified.

## Button Variables

These may be referenced or locally changed:

- `--btn-background`
- `--btn-background-hover`
- `--btn-text-color`
- `--btn-text-color-hover`
- `--btn-text-transform`
- `--btn-text-decoration`
- `--btn-text-decoration-hover`
- `--btn-letter-spacing`
- `--btn-line-height`
- `--btn-font-size`
- `--btn-font-weight`
- `--btn-font-family`
- `--btn-font-style`
- `--btn-padding-block`
- `--btn-padding-inline`
- `--btn-min-width`
- `--btn-align-items`
- `--btn-transition-duration`
- `--btn-border-color`
- `--btn-border-color-hover`
- `--btn-border-style`
- `--btn-radius`
- `--btn-border-width`
- `--btn-outline-background-color`
- `--btn-outline-border-hover`
- `--btn-outline-text-color`
- `--btn-outline-text-color-hover`
- `--focus-color`

The docs recommend the button mixin for new custom buttons. Their vanilla-variable fallback example is preserved:

```css
.gradient-button {
    background: linear-gradient(var(--primary-medium), var(--primary));
    padding: var(--btn-padding-block) var(--btn-padding-inline);
    font-size: var(--btn-font-size);
    line-height: var(--btn-line-height);
    letter-spacing: var(--btn-letter-spacing);
    border-width: var(--btn-border-width);
    border-style: var(--btn-border-style);
    border-radius: var(--btn-border-radius);
    border-color: transparent;
    font-weight: var(--btn-font-weight);
    text-decoration: var(--btn-text-decoration);
    font-style: var(--btn-font-style);
    text-transform: var(--btn-text-transform);
    min-inline-size: var(--btn-min-width);
    transition: background var(--btn-transition-duration) ease-in-out;
}
```

In 4.0, `--btn-font-family` and `--btn-align-items` were added; `--btn-outline-border-width` was removed in favor of `--btn-border-width`.

## Outline Buttons

`.btn--outline` requires `.btn--{color}` and can be combined with `.btn--{size}`. Enable Outline Variants under Buttons & Links > Options.

## Gradient Outline Recipe

Prerequisite: Primary palette color and Primary button style active. Set Primary background and background-hover to:

```css
linear-gradient(var(--gradient-angle), var(--gradient-color-1), var(--gradient-color-2));
```

The official full SCSS example is preserved exactly as rendered:

```scss
@property --gradient-color-1 {
    initial-value: transparent;
}
@property --gradient-color-2 {
    initial-value: transparent;
}
.btn--primary.btn--primary {
    --gradient-angle: 45 deg;
    --gradient-transition: --gradient-color-1 .6 s ease, --gradient-color-2 var(--transition-duration) var(--transition-timing);
    position: relative;
    border: none !important;
    padding-block: calc(var(--btn-padding-block) + var(--btn-outline-border-width));
    padding-inline: calc(var(--btn-padding-inline) + var(--btn-outline-border-width));
    transition: var(--gradient-transition);
    &::before {
        --gradient-color-1: var(--secondary);
        --gradient-color-2: var(--primary);
        content: '';
        position: absolute;
        inset: 0;
        border-radius: inherit;
        padding: var(--btn-outline-border-width);
        background: linear-gradient(var(--gradient-angle), var(--gradient-color-1), var(--gradient-color-2));
        -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        -webkit-mask-composite: xor;
        mask-composite: exclude;
        transition: var(--gradient-transition);
    }
    &:hover {
        --gradient-color-1: var(--primary);
        --gradient-color-2: var(--secondary);
        &::before {
            --gradient-color-1: var(--primary);
            --gradient-color-2: var(--secondary);
        }
    }
}
```

Official vanilla CSS example:

```css
@property --gradient-color-1 {
    syntax: " <color>";
    inherits: false;
    initial-value: transparent;
}
@property --gradient-color-2 {
    syntax: " <color>";
    inherits: false;
    initial-value: transparent;
}
.btn--primary.btn--primary {
    --gradient-angle: 45 deg;
    --gradient-transition: --gradient-color-1 .6 s ease, --gradient-color-2 var(--transition-duration) var(--transition-timing);
    position: relative;
    border: none !important;
    padding-block: calc(var(--btn-padding-block) + var(--btn-outline-border-width));
    padding-inline: calc(var(--btn-padding-inline) + var(--btn-outline-border-width));
    transition: var(--gradient-transition);
}
.btn--primary.btn--primary::before {
    --gradient-color-1: var(--secondary);
    --gradient-color-2: var(--primary);
    content: '';
    position: absolute;
    inset: 0;
    border-radius: inherit;
    padding: var(--btn-outline-border-width);
    background: linear-gradient(var(--gradient-angle), var(--gradient-color-1), var(--gradient-color-2));
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    transition: var(--gradient-transition);
}
.btn--primary.btn--primary:hover {
    --gradient-color-1: var(--primary);
    --gradient-color-2: var(--secondary);
}
.btn--primary.btn--primary:hover::before {
    --gradient-color-1: var(--primary);
    --gradient-color-2: var(--secondary);
}
```

The doubled `.btn--primary.btn--primary` raises specificity. The pseudo-element is positioned by `position: relative`, `position: absolute`, and `inset: 0`; its masks cut out the center. Both background and pseudo-element transition the locally scoped gradient tokens.

## Automatic Styling and Exclusions

Any class starting `.btn--` receives the framework. At Buttons & Links > Options > Additional Options, list selectors to exclude, comma-separated:

```text
.btn--third-party-example, .btn--another, .btn--yet-another
```

Excluded selectors receive no ACSS button styling.

## Source-Rendered Inconsistencies

- Button Styling renders `2 em` and `4 em` in override examples.
- Button Variables lists `--btn-radius`, but its example references `--btn-border-radius`. This may be a source typo or stale identifier.
- Gradient Outline Buttons uses `--btn-outline-border-width`, although Button Variables says that token was removed in 4.0 for `--btn-border-width`. It also renders `45 deg`, `.6 s`, and `syntax: " <color>"`. These are preserved, not silently corrected.

## Sources

- [Button Styling](https://docs.automaticcss.com/buttons/button-styling) — last updated Aug 7, 2026.
- [Button Classes](https://docs.automaticcss.com/buttons/button-classes) — last updated Aug 7, 2026.
- [Button Variables](https://docs.automaticcss.com/buttons/button-variables) — last updated Aug 7, 2026.
- [Outline Buttons](https://docs.automaticcss.com/buttons/outline-buttons) — last updated Aug 7, 2026.
- [Gradient Outline Buttons](https://docs.automaticcss.com/buttons/gradient-outline-buttons) — last updated Aug 7, 2026.
- [Auto Button Styling & Exclusions](https://docs.automaticcss.com/buttons/auto-button-styling-exclusions) — last updated Aug 7, 2026.
