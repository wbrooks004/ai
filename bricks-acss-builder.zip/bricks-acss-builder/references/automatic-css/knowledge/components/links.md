---
title: "Links"
source_scope: "Official Automatic.css 4.x Links sidebar: Link Styling and External Link Indication"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Links

## Global Link Styling

Configure under Buttons & Links > Links. The global panel controls color (the docs recommend a variable such as `--primary`), weight (`inherit` matches surrounding text), decoration, decoration color, decoration thickness, underline offset, and whether hover uses the global transition style.

Enable Add Link Default Exclusions to reveal a textarea for selectors excluded from global styling. Wrap every selector in quotes and comma-separate them so they are parsed into the `:not()` selector:

```text
"header a", "footer a", ".nav a"
```

In 4.0, color utilities such as `.link--primary` and `.link--secondary` were removed. Use CSS custom properties or custom classes.

## External Link Indication

Enable Buttons and Links > Links > External Links > Indicate External Links. ACSS adds visual and screen-reader cues to links that open in a new tab/window. The source recommends using this only for external domains.

Controls: External Link Indicator (any HTML entity code), position before/after, gap, size, vertical alignment, normal/hover color, weight, X/Y offset, and auditory Accessibility Text. The default spoken cue is “Link to external site.” An individual link may instead receive its own `aria-label`.

Default indicator exclusions use direct children inside `:has()`:

```css
:has(> img, > figure, > picture, > svg)
```

Add more child object selectors inside `:has(...)`, or add independent selectors after it:

```css
:has(> img, > figure, > picture, > svg), .exclude-this-link, #exclude-this-link
```

Any valid selector is accepted.

## Sources

- [Link Styling](https://docs.automaticcss.com/links/link-styling) — last updated Aug 7, 2026.
- [External Link Indication](https://docs.automaticcss.com/links/external-link-indication) — last updated Aug 7, 2026.
