---
title: "Elements"
source_scope: "Official Automatic.css 4.x Elements sidebar: Blockquotes and Ribbons"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Elements

## Blockquotes

Introduced in ACSS 4.0. Under Additional Styling > Blockquotes > Options, Blockquote Styling controls whether variables/styles load at all. Auto Style Blockquotes targets every `<blockquote>` by default; turn it off to style only `.blockquote`. Exclude Selectors accepts a comma-separated list such as:

```css
.custom-quote, .special-container blockquote
```

ACSS applies exclusions with `:where(:not(:is(...)))`.

### Dashboard controls and defaults

- Main: Padding `var(--space-m)`; Gap `1em`; Border Width `0 0 0 3px`; Border Style `solid`; Border Color `var(--primary)`; Border Radius `var(--radius)`; Background `var(--neutral-ultra-light)`; Box Shadow `none`; Max Width empty/no limit.
- Text on inner `<p>`: Color `inherit`; Font Family `inherit`; Font Style `normal`; Font Size `var(--text-l)`; Font Weight `normal`; Line Height `inherit`; Text Align `left`; Text Transform `none`.
- Footer/caption: Padding `0`; Margin `1em 0`; Font Family `inherit`; Font Size `var(--text-s)`; Font Weight `normal`; Font Style `normal`; Line Height `1.5`; Text Transform `none`; Color `currentColor`.
- Cite: Font Size/Weight/Style/Line Height/Text Transform `inherit`; Color `currentColor`.

### Variables

Main:

- `--blockquote-padding`
- `--blockquote-gap`
- `--blockquote-border-width`
- `--blockquote-border-style`
- `--blockquote-border-color`
- `--blockquote-border-radius`
- `--blockquote-background`
- `--blockquote-box-shadow`
- `--blockquote-max-inline-size`

Text:

- `--blockquote-text-color`
- `--blockquote-text-font-family`
- `--blockquote-text-font-style`
- `--blockquote-text-font-size`
- `--blockquote-text-font-weight`
- `--blockquote-text-line-height`
- `--blockquote-text-align`
- `--blockquote-text-transform`

Footer:

- `--blockquote-footer-padding`
- `--blockquote-footer-margin-block`
- `--blockquote-footer-font-family`
- `--blockquote-footer-font-size`
- `--blockquote-footer-font-weight`
- `--blockquote-footer-font-style`
- `--blockquote-footer-line-height`
- `--blockquote-footer-text-transform`
- `--blockquote-footer-color`

Cite:

- `--blockquote-cite-font-size`
- `--blockquote-cite-font-weight`
- `--blockquote-cite-font-style`
- `--blockquote-cite-line-height`
- `--blockquote-cite-text-transform`
- `--blockquote-cite-color`

### Markup patterns

Basic:

```html
<blockquote>
  <p>This is a blockquote. It will be automatically styled according to your dashboard settings.</p>
</blockquote>
```

With footer/cite:

```html
<blockquote>
  <p>The only way to do great work is to love what you do.</p>
  <footer>
    — Steve Jobs, <cite>Stanford Commencement Address</cite>
  </footer>
</blockquote>
```

Figure/figcaption:

```html
<figure>
  <blockquote cite="https://example.com/source">
    <p>The only thing we have to fear is fear itself.</p>
  </blockquote>
  <figcaption>— Franklin D. Roosevelt, <cite>First Inaugural Address</cite></figcaption>
</figure>
```

In the figure pattern, the `<figure>` gets container styles; its inner blockquote does not. `<p>`, `<figcaption>`, and `<cite>` retain their respective styles.

When auto styling is off:

```html
<blockquote class="blockquote">
  <p>This blockquote will be styled because it has the .blockquote class.</p>
</blockquote>
```

For the figure pattern, place `.blockquote` on `<figure>`.

Official custom examples, including source-rendered units:

```css
.testimonial-blockquote {
  --blockquote-background: var(--primary-ultra-light);
  --blockquote-border-color: var(--primary);
  --blockquote-border-width: 0 0 0 4 px;
  --blockquote-padding: var(--space-l);
  --blockquote-text-font-style: italic;
}
```

```css
.highlight-quote {
  --blockquote-background: var(--accent-ultra-light);
  --blockquote-border-color: var(--accent);
  --blockquote-border-width: 2 px;
  --blockquote-border-radius: var(--radius-l);
  --blockquote-box-shadow: var(--box-shadow-1);
  --blockquote-max-inline-size: 60 ch;
}
```

Potential source issue: `4 px`, `2 px`, and `60 ch` are rendered with spaces and are preserved exactly.

## Ribbons

To add a corner ribbon:

1. Set `position: relative;` and `overflow: hidden;` on its container.
2. Add a text element.
3. Add `.ribbon`.
4. Add `.ribbon--top-right` or `.ribbon--top-left`.

Locally scoped variables:

- `--ribbon-offset`
- `--ribbon-width`
- `--ribbon-padding`
- `--ribbon-background-color`
- `--ribbon-text-color`
- `--ribbon-text-size`
- `--ribbon-shadow`

Source-rendered defaults: Offset `-2rem`; Width `30rem`; Padding `.5em 1em`; Background Color `var(–action)`; Text Color `var(–white)`; Text Size `var(–text-s)`; Shadow `0 5px 10px var(–shade-trans-10);`.

Potential source issue: the default variable examples use an en dash (`–`) rather than `--`, and `action` is deprecated. They are preserved for traceability.

Custom modifier:

```css
.ribbon--sale {
    --ribbon-background-color: var(--primary);
    --ribbon-text-color: var(--primary-ultra-light);
    --ribbon-shadow: 0 0 30 px -3 px var(--primary-ultra-dark-trans-20);
}
```

Use both `.ribbon` and `.ribbon--sale`.

For dynamic position, add `data-ribbon-position` with `top-right` or `top-left`. Dynamic style example:

```css
[data-ribbon-style="sale"] {
    --ribbon-background-color: var(--primary);
    --ribbon-text-color: var(--primary-ultra-light);
    --ribbon-shadow: 0 0 30 px -3 px var(--primary-ultra-dark-trans-20);
}
```

Potential source issue: both shadow examples render `30 px` and `-3 px`; preserved exactly.

## Sources

- [Blockquotes](https://docs.automaticcss.com/elements/blockquotes) — last updated Aug 7, 2026.
- [Ribbons](https://docs.automaticcss.com/elements/ribbons) — last updated Aug 7, 2026.
