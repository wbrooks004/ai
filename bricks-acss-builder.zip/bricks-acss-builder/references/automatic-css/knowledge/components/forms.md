---
title: "Forms"
source_scope: "Official Automatic.css 4.x Forms sidebar: Form Styling Basics"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Forms

Enable Load Forms on the Forms dashboard screen. ACSS then applies one unified structural and spacing configuration and adapts form colors through CSS `light-dark()` according to the site's `color-scheme`.

Optional explicit utilities are `.form--light` and `.form--dark`. Put either on the form or an ancestor to override automatic scheme detection. Automatic adaptation is the recommended default.

Current official support is WS Form only. WS Form's Styler must be enabled because ACSS relies on the variables it exposes. If styling fails, save the WS Form settings page so the system files regenerate.

## Sources

- [Form Styling Basics](https://docs.automaticcss.com/forms/form-styling-basics) — last updated Aug 7, 2026.
