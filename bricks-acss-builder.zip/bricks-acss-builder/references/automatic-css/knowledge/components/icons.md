---
title: "Icons"
source_scope: "Official Automatic.css 4.x Icons sidebar: Icon Framework and Icon Mixin"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com/"
---

# Icons

## Icon Framework

The framework is on by default for new installs; verify at Dashboard > Icons. Add `data-icon` directly to the SVG/Icon/Code element. A Code element must render without a wrapper:

```html
<svg data-icon xmlns="http://www.w3.org/2000/svg" ... />
```

Icon style is boxed or naked. Global themes are Light and Dark, where the name describes icon color, not box styling. Global controls are Default Icon Style and, for boxed icons, padding, border width/style, and radius. Each theme controls icon color plus boxed background, border color, and box shadow. All except `box-shadow` have hover variants.

### Sizes and lists

- Size class: `.icon--{size}`; example `.icon--l`.
- Size attribute: `data-icon-size="{size}"`.
- Accepted values use t-shirt sizing (`s`, `m`, `l`, etc.). Three sizes load by default; Icons > Options > Expand Icon Sizes loads more.
- Icon-list class: `.icon-list`.
- Icon-list attribute: `[data-icon-list]` on `<ul>` or `<ol>`.

```html
<ul class="icon-list"></ul>
<ul data-icon-list class="whatever"></ul>
```

Icon lists support boxed-list-icon switching, icon size, list gap, inline offset, and block offset. Pseudo-element icons are not supported out of the box.

### Manual theme/style overrides

- Theme classes: `.icon--light`, `.icon--dark`.
- Theme attributes: `data-icon-theme="light"`, `data-icon-theme="dark"`.
- Style classes: `.icon--boxed`, `.icon--naked`.
- Style attributes: `data-icon-style="boxed"`, `data-icon-style="naked"`.

All methods work on individual icons or an ancestor group.

Every Icon Framework property is represented by a variable, but this page does not enumerate their identifiers. For Bricks specificity, the official workaround is the double-root selector `%root%%root% {}`.

## Icon Mixin

Functions and mixins work only in ACSS Custom SCSS, not builder inputs or builder CSS.

Signature: `icon($style, $box-style)`. Both arguments are described as optional, with the caveat that `$style` is optional only when `$box-style` is not supplied.

```scss
.my-icon {   @include icon; }
```

```scss
.my-icon {   @include icon(dark); }
```

`$style` accepts `light` or `dark`.

```scss
.my-icon {   @include icon(dark, off); }
```

`$box-style` accepts `box` to enable boxed style; any value other than `box` disables boxed style. Arguments are positional, so this is invalid:

```scss
.my-icon {   @include icon(box); }
```

If boxed styling is globally off, calling it through the mixin does not work out of the box because ACSS does not load variables/code for disabled features.

## Sources

- [Icon Framework](https://docs.automaticcss.com/icons/icon-framework) — last updated Aug 7, 2026.
- [Icon Mixin](https://docs.automaticcss.com/icons/icon-mixin) — last updated Aug 7, 2026.
