---
title: "Auto Object Fit"
source_scope: "Dimension > Auto Object Fit"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Auto Object Fit

Enable under Options > Workflow Enhancements. ACSS then sets every `img` to:

- `object-fit: var(--object-fit, cover);`
- `object-position: var(--object-position, 50% 50%);`

Override by setting the properties on an image or ancestor:

```css
.this-specific-area {
  --object-fit: contain;
}
```

`--object-position` accepts values such as `top left` or `50% 0`.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/auto-object-fit
- Last updated: Aug 7, 2026
