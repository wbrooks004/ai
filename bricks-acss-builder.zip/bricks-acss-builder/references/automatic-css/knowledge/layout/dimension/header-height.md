---
title: "Header Height"
source_scope: "Dimension > Header Height"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Header Height

In Layout > Header > Header Sizing, provide Header Height (Desktop) and Header Height (Mobile); ACSS produces fluid `--header-height`. Offset Content Automatically can add `margin-block-start: var(--header-height)`. Offset Scroll Margin Automatically keeps hash targets below the header.

Header exclusions accept comma-separated selectors. Default: `[data-sticky-header='0'], .content-offset--off`. Page exclusions can use selectors such as `.page-id-2` or `.post-type-services`.

Additional Styling > Sticky > Offset Sticky Automatically uses `--header-height`; an element can override it with `--sticky-offset` or `inset-block-start`.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/header-height
- Last updated: Aug 7, 2026
