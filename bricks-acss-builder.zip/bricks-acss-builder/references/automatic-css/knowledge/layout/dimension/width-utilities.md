---
title: "Width Utilities"
source_scope: "Dimension > Width Utilities"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Width Utilities

Enable Width classes and Width Variables separately under Options. Disabling width variables does not remove `--content-width`.

Standard class pattern: `.width--[value]` for `10`, `20`, `30`, `40`, `50`, `60`, `70`, `80`, `90`. Matching variables are `var(--width-10)` through `var(--width-90)`.

```css
inline-size: 100%;
max-inline-size: calc(var(--content-width) * 0.2);
```

Special classes:

- `.content-width`: content-width maximum, centered.
- `.content-width--safe`: content width with virtual gutter.
- `.width--full`: `inline-size: 100%`; `max-inline-size: 100%`.
- `.width--auto`: `inline-size: auto`; `max-inline-size: 100%`.
- `.width--max-content`: `inline-size: max-content`; `max-inline-size: 100%`.
- `.width--min-content`: `inline-size: min-content`; `max-inline-size: 100%`.
- `.width--fit-content`: `inline-size: fit-content`; `max-inline-size: 100%`.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/width-utilities
- Last updated: Aug 7, 2026
