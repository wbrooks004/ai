---
title: "Content Width"
source_scope: "Dimension > Content Width"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Content Width

Set content width under Layout > Website Dimensions. `.content-width` sets `max-inline-size` to `var(--content-width)`. Use the variable in theme or BEM styling so global changes propagate.

```css
.custom-element {
  width: 100%;
  max-width: var(--content-width);
}

.my-element {
  width: 100%;
  max-width: calc(var(--content-width) * 0.75);
}
```

The variable-based maximum becomes effectively full width on smaller screens. In 4.0 the class uses logical `max-inline-size`; `var(--content-width-safe)` remains available.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/content-width
- Last updated: Aug 7, 2026
