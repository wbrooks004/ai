---
title: "Content Width (Safe)"
source_scope: "Dimension > Content Width (Safe)"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Content Width (Safe)

The site gutter is `var(--gutter)`. Use `.content-width--safe` or `var(--content-width-safe)` where the parent does not already supply a gutter. The effective width uses `min(var(--content-width), calc(100% - var(--gutter) * 2))`.

The class applies `inline-size: 100%`, `max-inline-size: var(--content-width-safe)`, and `margin-inline: auto`. With the variable alone, center the element yourself:

```css
.my-element {
  width: 100%;
  max-width: var(--content-width-safe);
  margin-inline: auto;
}
```

Do not use the safe utility inside a parent that already establishes a gutter; that creates a double gutter. Documentation formerly referred to `--section-space-x`; the 4.x canonical gutter variable is `--gutter`.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/content-width-safe
- Last updated: Aug 7, 2026
