---
title: "Scroll Offsets"
source_scope: "Dimension > Scroll Offsets"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Scroll Offsets

Configure Scroll Offset (Desktop) and Scroll Offset (Mobile), in px, under Additional Styling > Scroll Offsets. These values add extra scroll margin above hash targets. If Layout > Header > Offset Scroll Margin Automatically is enabled, header-height offset is included and the two Scroll Offset values are added on top.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/scroll-offsets
- Last updated: Aug 7, 2026
