---
title: "Boxed Layout"
source_scope: "Dimension > Boxed Layout"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Boxed Layout

Enable under Layout > Boxed Layout. `html` supplies the edge-to-edge canvas; `body` supplies the contained visual background; normal content width and gutter still apply.

Dashboard options: Boxed Layout, Device Background (background shorthand), Body Width, Top Margin, Border Style, Border Width, Border Color, Border Radius, and Body Shadow (`box-shadow`). Border style, width, and color accept top/right/bottom/left sequences. Device Background may use `--white`, variables, colors, gradients, or images. Bottom margin is not supported by this structure.

## Sources

- Canonical: https://docs.automaticcss.com/dimension/boxed-layout
- Last updated: Aug 7, 2026
