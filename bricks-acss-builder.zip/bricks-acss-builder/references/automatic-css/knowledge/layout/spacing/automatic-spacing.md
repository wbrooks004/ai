---
title: "Automatic Spacing"
source_scope: "Spacing > Automatic Spacing"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Automatic Spacing

Automatic Spacing uses zero specificity and has independent controls:

- Auto Container Gap targets `section` and spaces direct-child divs with container-gap.
- Auto Content Gap targets divs/containers that are direct children of `section` and applies content-gap.
- Auto Grid Gap targets grids using grid utility classes and applies grid-gap.

Utilities, custom classes, IDs, inline styles, and any nonzero-specificity global rule can override it.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/automatic-spacing
- Last updated: Aug 7, 2026
