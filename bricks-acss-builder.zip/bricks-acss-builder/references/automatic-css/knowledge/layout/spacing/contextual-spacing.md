---
title: "Contextual Spacing"
source_scope: "Spacing > Contextual Spacing"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Contextual Spacing

Three contexts are documented:

- Container gap: `.container-gap` or `var(--container-gap)` between direct-child containers of a `section`.
- Content gap: `.content-gap` or `var(--content-gap)` between content elements.
- Grid gap: `.grid-gap` or `var(--grid-gap)` for grids and columnized content.

Keep the contextual token when varying its value:

```css
.my-grid {
    display: grid;
    grid-template-columns: var(--grid-3);
    gap: calc(var(--grid-gap) * 2);
}
```

Automatic Spacing can apply these contexts by default.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/contextual-spacing
- Last updated: Aug 7, 2026
