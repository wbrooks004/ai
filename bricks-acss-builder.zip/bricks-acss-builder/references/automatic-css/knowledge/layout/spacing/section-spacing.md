---
title: "Section Spacing Setup"
source_scope: "Spacing > Section Spacing Setup"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Section Spacing Setup

The dashboard controls block padding and inline gutter. Section spacing multiplies Base Spacing using Base Spacing Multiplier; first value is mobile and second desktop, with fluid interpolation. Gutter inputs produce responsive inline padding. Block Padding accepts one value for both ends or two values for top then bottom. All inputs map to M; other sizes derive from the regular Spacing Scale.

This affects default top-level `section` spacing, spacing variables, and section classes.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/section-spacing
- Last updated: Aug 7, 2026
