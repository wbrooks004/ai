---
title: "Spacing Variables"
source_scope: "Spacing > Spacing Variables"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Spacing Variables

Standard pattern: `var(--space-{size})`, where size is `xs`, `s`, `m`, `l`, `xl`, or `xxl`. Section pattern: `var(--section-space-{size})`; gutter: `var(--gutter)`.

```css
.testimonial-card {
    padding: var(--space-m);
    gap: var(--space-m);
}

.hero {
    padding-block: calc(var(--section-space-l) * 1.1);
}
```

## Bridge variables

Standard: `--space-xxl-to-xl`, `--space-xxl-to-l`, `--space-xxl-to-m`, `--space-xxl-to-s`, `--space-xxl-to-xs`, `--space-xl-to-l`, `--space-xl-to-m`, `--space-xl-to-s`, `--space-xl-to-xs`, `--space-l-to-m`, `--space-l-to-s`, `--space-l-to-xs`, `--space-m-to-s`, `--space-m-to-xs`, `--space-s-to-xs`.

Section: `--section-space-xxl-to-xl`, `--section-space-xxl-to-l`, `--section-space-xxl-to-m`, `--section-space-xxl-to-s`, `--section-space-xxl-to-xs`, `--section-space-xl-to-l`, `--section-space-xl-to-m`, `--section-space-xl-to-s`, `--section-space-xl-to-xs`, `--section-space-l-to-m`, `--section-space-l-to-s`, `--section-space-l-to-xs`, `--section-space-m-to-s`, `--section-space-m-to-xs`, `--section-space-s-to-xs`.

Pattern: `var(--space-{large}-to-{small})` or `var(--section-space-{large}-to-{small})`; desktop uses the larger size maximum and mobile the smaller size minimum.

## Calculations and positioning

```css
.overlapping-image {
    margin-block-start: calc((var(--section-space-m) + var(--space-l)) * -1);
}
.overlapped-section {
    padding-block-end: calc(var(--section-space-m) + var(--space-l));
}
```

Use small multiplication/division adjustments; if a result equals another named size, use the named variable.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/spacing-variables
- Last updated: Aug 7, 2026
