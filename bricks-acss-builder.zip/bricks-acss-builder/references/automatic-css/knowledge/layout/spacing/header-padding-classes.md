---
title: "Header Padding Classes"
source_scope: "Spacing > Header Padding Classes"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Header Padding Classes

Pattern: `.header--{size}`. All typical t-shirt sizes are available. These change header block padding while preserving the inline gutter and use the standard spacing system rather than the larger section spacing system.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/header-padding-classes
- Last updated: Aug 7, 2026
