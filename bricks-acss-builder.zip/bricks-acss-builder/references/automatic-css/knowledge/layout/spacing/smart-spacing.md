---
title: "Smart Spacing"
source_scope: "Spacing > Smart Spacing"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Smart Spacing

Smart Spacing removes default margins from headings, paragraphs, lists, and list items so parent `gap` works evenly, then reapplies configured adjacent-sibling spacing inside rich text, post content, `.smart-spacing`, additional selectors, and WooCommerce content. Only direct children are targeted.

Use `.smart-spacing` on the direct parent when automatic targeting misses an area. Additional selectors must be quoted and comma-separated; the source shows `".extra-wrapper" ".brxe-text > div"`. Use `.smart-spacing--off` at box, section, page, or template scope to remove all Smart Spacing.

Dashboard groups include Text and Lists (paragraphs, lists, list items, nested variants, indentation) and Other (Flow Spacing, Figures, Figcaptions, Blockquotes). Inputs labeled “(block)” accept top then bottom values.

Available variables:

`--paragraph-spacing`, `--heading-spacing`, `--h2-spacing`, `--h3-spacing`, `--h4-spacing`, `--h5-spacing`, `--h6-spacing`, `--list-spacing`, `--list-indent-spacing`, `--list-item-spacing`, `--nested-list-spacing`, `--nested-list-indent-spacing`, `--nested-list-item-spacing`, `--flow-spacing`, `--figure-spacing`, `--figcaption-spacing`, `--blockquote-spacing`.

Avoid Duplicate Margins exposes the selectors whose combined block margins ACSS removes.

> Source fidelity note: the displayed selector example lacks the comma that the following sentence requires. Preserve the literal example as source text, but operationally follow the documented comma-separated rule.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/smart-spacing
- Last updated: Aug 7, 2026
