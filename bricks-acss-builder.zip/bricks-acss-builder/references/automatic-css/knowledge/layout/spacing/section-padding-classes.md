---
title: "Section Padding Classes"
source_scope: "Spacing > Section Padding Classes"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Section Padding Classes

Top-level sections receive M section spacing by default. Pattern: `.section--{size}` with `XS` through `XXL`. These alter block padding while retaining the inline gutter. Use `calc()` for an in-between size or create a class using `fluid()`.

Recommended structure is `section` plus inner content-width `div`, with gutter on the section and content width/centering on the inner div.

> Source fidelity note: the official prose says “the `section` itself and and inner `div`”; the duplicated “and” is a source typo and does not change the structural guidance.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/section-padding-classes
- Last updated: Aug 7, 2026
