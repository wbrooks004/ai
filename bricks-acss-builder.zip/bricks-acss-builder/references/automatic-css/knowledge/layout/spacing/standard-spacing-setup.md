---
title: "Standard Spacing Setup"
source_scope: "Spacing > Standard Spacing Setup"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Standard Spacing Setup

Base Spacing maps directly to all M spacing and influences section spacing. Desktop and mobile base values define the fluid endpoints. Base Scale generates sizes above M by multiplication and below M by division. Desktop Ratio and Mobile Ratio control variance across their respective ranges.

Standard spacing affects spacing variables, section padding classes, contextual spacing utilities, and header classes.

## Sources

- Canonical: https://docs.automaticcss.com/spacing/standard-spacing-setup
- Last updated: Aug 7, 2026
