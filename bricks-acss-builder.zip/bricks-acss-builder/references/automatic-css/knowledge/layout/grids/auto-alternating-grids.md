---
title: "Auto Alternating Grids"
source_scope: "Grids > Auto Alternating Grids"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Auto Alternating Grids

Build repeated two-column rows with `.grid--` classes such as `.grid--2` or `.grid--2-3`. Add `.grid-alternate--[breakpoint]` at the wrapper to alternate children at that min-width breakpoint and above; the official example is `.grid-alternate--l`. Add normal `.grid--` breakpoint classes for row responsiveness.

## Sources

- Canonical: https://docs.automaticcss.com/grids/auto-alternating-grids
- Last updated: Aug 7, 2026
