---
title: "Masonry Layouts (Grids page)"
source_scope: "Grids > Masonry Layouts"
version_scope: "Automatic.css 4.x navigation page containing legacy utility documentation"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Masonry Layouts (Grids page)

This current-sidebar page documents legacy masonry utilities: `.masonry--1`, `.masonry--2`, `.masonry--3`, `.masonry--4`, `.masonry--5`; responsive `.col-width--[size]`; and manual `.masonry--[breakpoint]-[columns]`. It also says existing gap utilities and separate column-gap/row-gap utilities work, and that column rule utilities apply.

> Version conflict: the current Columns > Masonry Layouts page explicitly says ACSS 4.0 removed `.masonry--1` through `.masonry--5` and directs users to `?columns`. Treat this Grids page as stale even though it remains in the official 4.x sidebar.

## Sources

- Canonical: https://docs.automaticcss.com/grids/masonry-layouts
- Last updated: Aug 7, 2026
