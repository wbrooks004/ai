---
title: "Content Grid"
source_scope: "Grids > Content Grid"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Content Grid

Apply `.content-grid`, a Content Grid mixin, or a Content Grid recipe. For global top-level sections enable Layout > Content Grid > Default Sections to Content Grid; disable an instance with `.content-grid--off`. A content-grid `section` loses normal inline padding and column gap because the grid supplies `var(--gutter)`.

Zones and tokens:

- Content: default `var(--content-width)`; override `--content-width`; grid line `content`.
- Feature: `.content--feature`; `grid-column: feature`; width `--feature-width`.
- Feature Max: `.content--feature-max`; `grid-column: feature-max`; width `--feature-max-width`.
- Full: `.content--full`; `grid-column: full`.
- Full Width Safe: `.content--full-safe`; programmatic equivalent `grid-column: full; padding-inline: var(--gutter);`.

```css
.my-box {
    grid-column: full;
    padding-inline: var(--gutter);
}
```

The documented 50/50 token is rendered exactly as:

```css
grid-template-columns: calc((min(50 vw - var(--gutter), var(--content-width) / 2)) - (var(--grid-gap) / 2)) minmax(0, 1 fr);
```

> Source fidelity notes: the official page renders `70 ch`, `75 px`, `50 vw`, and `1 fr` with spaces and describes `.content--full` as filling “Feature Max” despite placing it on `full`. These are preserved source defects; standard CSS would normally omit those unit spaces.

## Sources

- Canonical: https://docs.automaticcss.com/grids/content-grid
- Last updated: Aug 7, 2026
