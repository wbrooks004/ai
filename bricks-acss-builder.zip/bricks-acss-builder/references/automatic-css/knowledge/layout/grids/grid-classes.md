---
title: "Grid Classes"
source_scope: "Grids > Grid Classes"
version_scope: "Automatic.css 4.x page; source includes a suspected token typo"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Grid Classes

Parent grids use `.grid--[columns]` with 1–12 columns, e.g. `.grid--3`. Responsive convention is `.grid--[breakpoint]-[columns]`; example: `.grid--4 .grid--l-2 .grid--m-1`. Use `.grid-gap` or `var(--grid-gap)` (preferred), `.gap--` utilities, and `.stretch` for equal-height cells.

Uneven source tokens are rendered without leading dots and with en dashes: `grid–1-2`, `grid–2-1`, `grid–1-3`, `grid–3-1`, `grid–3-2`, `grid–2-3`. The prose example uses `.grid--1-2`.

Placement and order:

- `.col-span--2`; breakpoint example `.col-span--l-1`.
- `.order--first`, `.order--last`, `.order--first-l`, `.order--last-s`.
- `.col-start--`, `.col-end--`, `.row-start--`, `.row-end--`.
- `.col-start--1 .col-end--9`; `.col-end--last`; source also says `.col-row--last` for the last row.

Content alignment patterns: `.justify-content--[position]`, `.justify-content--[position]-[breakpoint]`, `.align-content--[position]`, `.align-content--[position]-[breakpoint]`; values `start`, `end`, `center`, `stretch`, `space-between`, `space-around`, `space-evenly`.

Item alignment patterns: `.align-items--[position]`, `.align-items--[position]-[breakpoint]`, `.justify-items--[position]`, `.justify-items--[position]-[breakpoint]`; values `start`, `end`, `center`, `baseline`, `stretch`.

> Source fidelity note: `.col-row--last` is preserved exactly but appears inconsistent with the documented `.row-end--` prefix and is likely a source typo. The page itself warns that some alignment classes changed and directs users to the ACSS cheat sheet.

## Sources

- Canonical: https://docs.automaticcss.com/grids/grid-classes-standard
- Last updated: Aug 7, 2026
