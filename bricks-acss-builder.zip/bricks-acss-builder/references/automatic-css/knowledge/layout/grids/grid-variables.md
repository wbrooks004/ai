---
title: "Grid Variables"
source_scope: "Grids > Grid Variables"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Grid Variables

Use grid variables with custom/BEM classes for maintainable structures.

```css
.service-grid {
   display: grid;   grid-template-columns: var(--grid-3);   gap: var(--grid-gap);
}
```

Available structures:

`var(--grid-1) var(--grid-2) var(--grid-3) var(--grid-4) var(--grid-5) var(--grid-6) var(--grid-7) var(--grid-8) var(--grid-9) var(--grid-10) var(--grid-11) var(--grid-12) var(--grid-1-2) var(--grid-1-3) var(--grid-2-1) var(--grid-2-3) var(--grid-3-1) var(--grid-3-2)`

The official responsive example renders `@media (max-width: 991 px)` and changes to `var(--grid-2)`.

> Source fidelity note: `991 px` is preserved exactly; the embedded space is likely a source-rendering typo.

## Sources

- Canonical: https://docs.automaticcss.com/grids/grid-variables
- Last updated: Aug 7, 2026
