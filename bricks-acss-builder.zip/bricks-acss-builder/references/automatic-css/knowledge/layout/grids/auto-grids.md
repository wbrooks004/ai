---
title: "Auto Grids"
source_scope: "Grids > Auto Grids"
version_scope: "Automatic.css 4.x page; contains legacy syntax marked below"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Auto Grids

Auto Grids respond to content width rather than explicit breakpoints. Enable under Options > Utility Classes.

## Classes and variables

Classes: `.grid--auto-2` through `.grid--auto-12`; ratios `.grid--auto-1-2`, `.grid--auto-2-1`, `.grid--auto-2-3`, `.grid--auto-3-2`, `.grid--auto-1-3`, `.grid--auto-3-1`.

Instance minimum: `--min` (Aggressiveness accepts decimal `0` to `1`). Example is rendered as:

```css
%root% {
    --min: 280 px;
}
```

Variable use:

```css
.your-selector {
    display: grid;
    grid-template-columns: var(--grid-auto-4);
}
```

The source says variable encapsulation prevents local `--min` from controlling a variable-applied grid; use a class, mixin, or recipe for that control.

## Even stacking and flow

- `.grid--stack-even` forces even stacking for an instance.
- `.grid--stack-any` disables a global force-even setting for an instance.
- `.grid--stack-{type}-{breakpoint}` overrides the breakpoint.
- `stack-even` is min-width; `stack-any` is max-width.
- `.grid--auto-fill` selects `auto-fill`; `.grid--auto-fit` selects `auto-fit`.

## Exact legacy tokens on the current page

The 4.x page still renders `@include auto-grid($col-count, $min-item-width);`, recipe `@auto-grid;`, and `var(–min)` with an en dash in introductory prose. Preserve these only as source claims. The dedicated current mixin page documents `auto-grid($column-count, $min, $flow, $force-even-column-count);`, and current 4.x recipe pages generally use `?`, so the `@auto-grid;` recipe call appears stale. The rendered `280 px` is also likely a unit-spacing typo.

## Sources

- Canonical: https://docs.automaticcss.com/grids/auto-grids
- Last updated: Aug 7, 2026
