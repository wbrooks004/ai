---
title: "Variable Grids"
source_scope: "Grids > Variable Grids"
version_scope: "Automatic.css 4.x page; contains legacy recipe prefix marked below"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Variable Grids

Variable Grids automatically fit equal columns according to an item minimum. Apply `.variable-grid`; tune an instance with `--min`, preferably at ID/instance scope.

```css
%root% {
    --min: 380 px;
}
```

The current page describes three methods: `.variable-grid`, `@variable-grid-columns` in a `grid-template-columns` input, and `@variable-grid;` in CSS. It says the full recipe exposes all code including `--min`. `--min` may be treated as a literal minimum or an optimal width, reset at breakpoints, or set inline:

```html
<div class="my-variable-grid" style="--min: 320 px;"></div>
```

Variable Grids are inappropriate when precise per-breakpoint column counts or uneven columns are required.

> Source fidelity notes: `380 px` and `320 px` are preserved exactly and likely contain unit-spacing typos. The page renders recipe prefixes `@variable-grid-columns` and `@variable-grid;`; current 4.x recipe documentation elsewhere says recipe syntax changed from `@` to `?`, so these may be stale.

## Sources

- Canonical: https://docs.automaticcss.com/grids/variable-grid
- Last updated: Aug 7, 2026
