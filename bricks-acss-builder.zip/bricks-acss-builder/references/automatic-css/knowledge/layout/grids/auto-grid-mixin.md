---
title: "Auto Grid Mixin"
source_scope: "Grids > Auto Grid Mixin"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Auto Grid Mixin

Mixins run only in the ACSS dashboard Custom SCSS area, not builder inputs or builder CSS.

Full signature:

```scss
auto-grid($column-count, $min, $flow, $force-even-column-count);
```

Only `$column-count` is required.

```scss
.my-grid {
    @include auto-grid(4);
}

.my-grid {
    @include auto-grid(4, $flow: auto-fill, $force-even-column-count: true);
}
```

Arguments: `$column-count` initial columns; `$min` minimum inline dimension before stacking; `$flow` is `auto-fit` or `auto-fill`; `$force-even-column-count` is `true` or `false` and is useful for an initially even count. Named arguments can be passed in any order.

## Sources

- Canonical: https://docs.automaticcss.com/grids/auto-grid-mixin
- Last updated: Aug 7, 2026
