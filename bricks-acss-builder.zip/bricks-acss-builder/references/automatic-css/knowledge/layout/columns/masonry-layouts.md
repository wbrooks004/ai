---
title: "Masonry Layouts"
source_scope: "Columns > Masonry Layouts"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Masonry Layouts

ACSS 4.x builds masonry with CSS Columns through `?columns`.

```css
.my-masonry {
  --col-count: 3;
  --col-gap: var(--space-l);
  --row-gap: var(--space-l);
}
```

For content-responsive stacking, set `--col-min-width`:

```css
.my-masonry {
  --col-min-width: 300 px;
  --col-gap: var(--space-l);
  --row-gap: var(--space-l);
}
```

`--col-gap` is horizontal; `--row-gap` is vertical and is applied as margin to child elements. Ruled masonry uses the column recipe's rule-style, rule-color, and rule-width properties.

In 4.0, `.masonry--1` through `.masonry--5` were removed; use `?columns`.

> Source fidelity note: the official example renders `300 px` with a space. This is preserved exactly and is likely a source typo because CSS dimensions normally use `300px`.

## Sources

- Canonical: https://docs.automaticcss.com/columns/masonry-layouts
- Last updated: Aug 7, 2026
