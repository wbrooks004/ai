---
title: "CSS Columns"
source_scope: "Columns > CSS Columns"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# CSS Columns

CSS Columns flow content dynamically across visual columns. ACSS recommends them for long text, lists, and masonry. They do not support native `row-gap`, do not work on flex containers, and lack Grid-style placement.

## Interface

Apply `?columns` to an element. Local properties:

- `--col-count:`
- `--col-min-width:`
- `--col-rule-style`
- `--col-rule-width`
- `--col-rule-color`
- `--col-gap`
- `--row-gap`

Predefined widths: `var(--col-width-s)`, `var(--col-width-m)`, `var(--col-width-l)`.

Rule widths: `var(--col-rule-width-s)`, `var(--col-rule-width-m)`, `var(--col-rule-width-l)`.

```css
.my-columns {
  --col-rule-style: solid;
  --col-rule-width: var(--col-rule-width-m);
  --col-rule-color: var(--border-color);
}
```

In 4.0, `.col-count--`, `.col-width--`, `.col-rule--`, and `.col-span--` utilities were removed in favor of `?columns`.

## Sources

- Canonical: https://docs.automaticcss.com/columns/css-columns
- Last updated: Aug 7, 2026
