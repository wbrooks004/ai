---
title: "Custom Overlays"
source_scope: "Overlays > Custom Overlays"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Custom Overlays

Configure up to five overlays under Surfaces & Overlays > Custom Overlays. Options: Name (creates `.overlay-[name]`), Background Color, Background Type (`gradient`, `image`, `none`), Background/Asset, Background Size, Background Position, Background Attachment (`scroll`, `fixed`, `local`), Background Repeat, Backdrop Blur, Blend Mode, Opacity (default `0.7`), Border Radius, Animation, and Inset (default `0`).

Classes: numbered `.overlay-1` (through the configured overlay count) and optional named form such as `.overlay-gradient` or `.overlay-dark-gradient`.

Global/per-overlay property pairs:

- `--overlay-bg-color` / `--overlay-[n]-bg-color`
- `--overlay-background` / `--overlay-[n]-background`
- `--overlay-background-size` / `--overlay-[n]-background-size`
- `--overlay-background-position` / `--overlay-[n]-background-position`
- `--overlay-background-repeat` / `--overlay-[n]-background-repeat`
- `--overlay-background-attachment` / `--overlay-[n]-background-attachment`
- `--overlay-background-blur` / `--overlay-[n]-background-blur`
- `--overlay-opacity` / `--overlay-[n]-opacity`
- `--overlay-blend-mode` / `--overlay-[n]-blend-mode`
- `--overlay-border-radius` / `--overlay-[n]-border-radius`
- `--overlay-animation` / `--overlay-[n]-animation`
- `--overlay-inset` / `--overlay-[n]-inset`
- `--overlay-z-index` / `--overlay-[n]-z-index` (default `-1`)

Example gradient value: `linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.8) 100%)`. Blur example: `rgba(255, 255, 255, 0.1)` and `10px`.

```css
.card {
  --overlay-opacity: 0.7;
  transition: --overlay-opacity 0.3 s ease;
}
.card:hover {
  --overlay-opacity: 0.3;
}
```

The pseudo-element is configurable as `::before` or `::after`; it uses `position: absolute`, `inset`, and `z-index: -1`; the parent receives `position: relative` and `isolation: isolate`. 4.0 adds backdrop blur, animation, nested-overlay `border-image`, inset, and runtime custom properties.

> Source fidelity note: `0.3 s` is preserved exactly from the official example and is likely a unit-spacing typo; CSS durations normally use `0.3s`.

## Sources

- Canonical: https://docs.automaticcss.com/overlays/custom-overlays
- Last updated: Aug 7, 2026
