---
title: "Basic Overlays"
source_scope: "Overlays > Basic Overlays"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Basic Overlays

Enable under Surfaces & Overlays > Basic Overlays. Choose Before (`::before`, default) or After (`::after`). Add `.overlay` or any class containing `overlay--` followed by a descriptor, such as `.overlay--dark`.

Variables: `--overlay-color` (default `rgba(0, 0, 0, 0.7)`) and `--overlay-z-index` (default `-1`). On `figure` containing `img`, `picture`, `svg`, `video`, or `iframe`, the overlay receives `--overlay-z-index: 0`.

```css
.overlay {
  position: relative;
  z-index: 0;
  isolation: isolate;
}
.overlay::before {
  content: "";
  background: var(--overlay-color, rgba(0, 0, 0, 0.7));
  position: absolute;
  inset: 0;
  z-index: var(--overlay-z-index, -1);
}
```

In 4.0, basic/custom overlays have separate toggles, pseudo-element selection is configurable, and isolation, z-index control, and figure handling were added.

## Sources

- Canonical: https://docs.automaticcss.com/overlays/overlay-classes
- Last updated: Aug 7, 2026
