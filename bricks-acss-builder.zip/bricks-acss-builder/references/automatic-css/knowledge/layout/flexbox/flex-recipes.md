---
title: "Flex Recipes"
source_scope: "Flexbox > Flex Recipes"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Flex Recipes

Documented recipes:

- `?flex-row` expands to `display: flex; flex-direction: row;`.
- `?flex-column` expands to `display: flex; flex-direction: column;`.
- `?center-all`: column flex; `align-items: center`; `justify-content: center`; `text-align: center`.
- `?center-left`: column flex; `align-items: flex-start`; `justify-content: center`; `text-align: left`.
- `?center-right`: column flex; `align-items: flex-end`; `justify-content: center`; `text-align: right`.
- `?center-top`: column flex; `align-items: center`; `justify-content: flex-start`; `text-align: center`.
- `?center-bottom`: column flex; `align-items: center`; `justify-content: flex-end`; `text-align: center`.
- `?flex-grid`: flex-based grid; properties `--gap`, `--columns`, `--stretch`.

`?flex-grid` defaults: `--gap: var(--grid-gap, 1.5rem)`, `--columns: 3`, `--stretch: 0`.

Example call:

```css
.my-container {
  ?flex-row;
}
```

In 4.0, recipe prefix changed from `@` to `?`; these recipes replace removed `.flex--row`, `.flex--col`, and flex-grid utilities.

## Sources

- Canonical: https://docs.automaticcss.com/flexbox/flex-recipes
- Last updated: Aug 7, 2026
