---
title: "Flex Grids (Flexbox Grids)"
source_scope: "Flexbox > Flex Grids (Flexbox Grids)"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23"
official_base_url: "https://docs.automaticcss.com"
---

# Flex Grids (Flexbox Grids)

Flex Grid centers or stretches an unbalanced final row. Apply `?flex-grid` to the parent.

```css
.my-grid {
  ?flex-grid;
  --columns: 4;
  --gap: var(--space-l);
  --stretch: 1; /* Stretch unbalanced items */
}
```

Local properties and defaults: `--gap: var(--grid-gap, 1.5rem)`, `--columns: 3`, and `--stretch: 0` (`1` enables stretching).

The documented responsive defaults render as:

```css
@media (max-width: 900 px) {
  --columns: 2;
}
@media (max-width: 600 px) {
  --columns: 1;
}
```

In 4.0, `.flex-grid--1` through `.flex-grid--6` and breakpoint variants were replaced by the recipe and media-query control.

> Source fidelity note: the official examples render spaces in `900 px`, `600 px`, `1200 px`, `768 px`, and `480 px`. This is preserved and is likely a source-rendering typo; CSS dimensions normally omit the space.

## Sources

- Canonical: https://docs.automaticcss.com/flexbox/flex-grids
- Last updated: Aug 7, 2026
