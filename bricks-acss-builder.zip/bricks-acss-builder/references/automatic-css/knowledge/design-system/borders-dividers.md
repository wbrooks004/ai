---
title: "Borders and Dividers"
source_scope: "Official Automatic.css 4.x documentation: Global Border System, Global Divider System, and Inverted Radius Framework"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Borders and Dividers

## Global border system

Use `var(--radius)` for the project's primary border radius. Set it to `0` when the design has no radius. The **Add Radius Automatically** option can target selectors; defaults include `img` and `figure` elements that do not contain images. Selector entries must be quoted and comma-separated. The concentric-radius recipe is `?concentric-radius`.

Use `var(--border)` for the configured global border shorthand. Its constituent tokens are:

- `var(--border-size)` — border width.
- `var(--border-style)` — border style.
- `var(--border-color-light)` — light border color.
- `var(--border-color-dark)` — dark border color.
- `var(--border-light)` — explicit light variant.
- `var(--border)` — global default variant, light or dark according to the dashboard.

```css
.card {
  border: var(--border);
  border-radius: var(--radius);
}
```

For an alternate variant, use `border: var(--border-light);`. For a local instance, remap granular tokens.

```css
.card {
  --border-width: 5 px;
  border: var(--border-width) var(--border-style) var(--border-color-dark);
}
```

> Source anomaly: the page introduces width as `var(--border-size)` but its local override example uses `--border-width` and the rendered value `5 px`. Both strings are retained exactly here.

In 4.0, border utility classes such as `.border`, `.border-dark`, and `.border-light` were removed. Border colors use `color-mix()`, for example `color-mix(in oklch, var(--black) 20%, transparent)`.

## Global divider system

Use `var(--divider)` with a border property for the configured global divider style.

```css
.accent-heading {
  border-block-end: var(--divider);
}
```

Documented divider tokens:

- `var(--divider)` — combined default style.
- `var(--divider-dark)` — explicit dark combined style.
- `var(--divider-inline-size)` — inline size for a custom divider.
- `var(--divider-size)` — thickness.
- `var(--divider-style)` — literal border style.
- `var(--divider-color-dark)` — dark color.
- `var(--divider-gap)` — associated spacing.

The dashboard also establishes a light divider color and light/dark combined styles. When not using a border property, `var(--divider-style)` cannot create dashed/dotted variants.

```css
.heading::after {
  content: '';
  position: absolute;
  inline-size: var(--divider-inline-size);
  height: var(--divider-size);
  background-color: var(--divider-color-dark);
}
```

Recipes:

- `?divider-top` — top divider plus desired gap.
- `?divider-bottom` — bottom divider plus desired gap.
- `?divider-all` — dividers and even gaps between all direct children. It uses programmatic margin; set a flex/grid parent's gap to `0` for consistent spacing.

Local remapping pattern:

```css
#unique-element {
  --divider: var(--divider-size) var(--divider-style) var(--accent);
}
```

In 4.0, `.divider-top`, `.divider-bottom`, and `.divider--all` were removed in favor of the recipes. Divider colors use `color-mix()`.

## Inverted Radius Framework

Enable under **Borders & Dividers > Additional Radius Options > Inverted Radius Support**. Apply the framework to the box that the curves bend away from. It uses pseudo-elements and therefore supports at most two corners per box.

Required data-attribute patterns:

- `data-inverted-radius-1-position`
- `data-inverted-radius-1-slice`
- `data-inverted-radius-2-position`
- `data-inverted-radius-2-slice`
- General forms: `data-inverted-radius-[#]-position` and `data-inverted-radius-[#]-slice`.

Define `--bg` at the appropriate parent scope; both the attached box and radius edges adopt it.

```css
.this-section {
  --bg: var(--primary-light);
  background-color: var(--bg);
}
```

All 16 documented position values:

`top-left`, `top-outside-left`, `top-left-outside`, `top-outside-left-outside`, `top-right`, `top-outside-right`, `top-right-outside`, `top-outside-right-outside`, `bottom-left`, `bottom-outside-left`, `bottom-left-outside`, `bottom-outside-left-outside`, `bottom-right`, `bottom-outside-right`, `bottom-right-outside`, `bottom-outside-right-outside`.

All slice values: `top-left`, `top-right`, `bottom-left`, `bottom-right`.

```html
<div
  class="my-box"
  data-inverted-radius-1-position="bottom-left-outside"
  data-inverted-radius-1-slice="bottom-right"
  data-inverted-radius-2-position="bottom-right-outside"
  data-inverted-radius-2-slice="bottom-left"
></div>
```

For breakpoint changes, each corner is controlled by:

- `--inverted-radius-[#]-position`
- `--inverted-radius-[#]-slice`
- `--inverted-radius-[#]-shadow`

```css
@media (max-width: 767 px) {
  .my-box {
    --inverted-radius-1-position: var(--position-top-right-outside);
    --inverted-radius-1-slice: var(--slice-bottom-left);
    --inverted-radius-1-shadow: var(--shadow-bottom-left);
  }
}
```

> Source anomaly: `767 px` is the exact rendered source string. Slice and shadow must target the same side; variable values add `position-`, `slice-`, or `shadow-` prefixes to the data-attribute value.

Rare rendering artifacts can be resolved by forcing GPU acceleration on the offending element with `transform: translate3d(0,0,0);`. The shadow technique does not support gradient, pattern, or texture backgrounds; use a masking approach when those are required.

Clickable-parent constraints: the link cannot be the inverted-radius element or its child; it must wrap the inverted-radius box and cannot be positioned relative/absolute; the documented viable case uses a heading as the only content.

The framework is largely unchanged in 4.0.

## Sources

- [Global Border System](https://docs.automaticcss.com/borders-dividers/global-border-system) — last updated 2026-08-07.
- [Global Divider System](https://docs.automaticcss.com/borders-dividers/global-divider-system) — last updated 2026-08-07.
- [Inverted Radius Framework](https://docs.automaticcss.com/borders-dividers/inverted-radius-framework) — last updated 2026-08-07.
