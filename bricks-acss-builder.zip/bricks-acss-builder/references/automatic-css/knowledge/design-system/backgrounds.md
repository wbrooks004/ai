---
title: "Backgrounds"
source_scope: "Official Automatic.css 4.x documentation: Contextual Backgrounds, Surfaces, and Is Background"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Backgrounds

## Contextual backgrounds

Contextual background utilities describe intent rather than a palette color. Their actual colors are assigned under **Color Assignments > Backgrounds**. With Automatic Color Relationships enabled, the utility also changes foreground headings, text, links, buttons, icons, and focus indicators. The variable alone cannot trigger these relationships.

| Class | Variable | Meaning |
| --- | --- | --- |
| `.bg--light` | `--bg-light` | Light background |
| `.bg--ultra-light` | `--bg-ultra-light` | Ultra-light background |
| `.bg--dark` | `--bg-dark` | Dark background |
| `.bg--ultra-dark` | `--bg-ultra-dark` | Ultra-dark background |

Configure relationship colors under **Color Assignments > Light Relationships** and **Color Assignments > Dark Relationships**. The available relationship inputs are Heading Color, Text Color, Link Color, Link Hover Color, Button Background, Icon Color, and Focus Color. The feature toggle is under **Options > Defaults & Misc**.

## Surfaces

Surfaces are reusable background styles for images, textures, CSS gradients, patterns, positioning, sizing, animation, overlays, and Automatic Color Relationships. Create up to five under **Surfaces & Overlays > Custom Surfaces**.

Each slot supports:

- Name: creates `.surface-{name}`; examples are `.surface-hero` and `.surface-card`. Default numeric names produce `.surface-1`, `.surface-2`, etc.
- Background Color: fallback.
- Surface Asset: an image path such as `/path/to/image.png`, a gradient such as `linear-gradient(to right, var(--primary), var(--secondary))`, or any valid `background-image` value.
- Asset is URL: adds the `url()` wrapper.
- Surface Size: a `background-size` value such as `cover`, `contain`, or `200px`.
- Surface Position: a `background-position` value such as `center center` or `top left`.
- Attachment: `scroll`, `fixed`, or `local`.
- Repeat: values such as `repeat`, `no-repeat`, or `repeat-x`.
- Color Relationship: `ultra-light`, `light`, `ultra-dark`, or `dark`; activates the corresponding foreground relationship.
- Animation: any CSS animation shorthand, such as `gradientMove 10s infinite linear`; its `@keyframes` must be defined in custom CSS.
- Overlay: Enable Overlay, Overlay Color, and Overlay Opacity.

Usage patterns:

```html
<section class="surface-hero">
  <!-- Content here -->
</section>
```

```css
.my-element {
  background: var(--surface-1);
}
```

Use `.bg--{color}` for simple solid colors and `.surface-{name}` for reusable images, textures, patterns, animation, or built-in overlays. Both support color relationships; the surface Background Color is a solid fallback.

## `.is-bg`

Add `.is-bg` to a real image or almost any box to make it the background of its direct parent. Real images retain indexing, lazy loading, alt text, `srcset`, and `<picture>` support. Multiple `.is-bg` elements can be stacked; a blank `.is-bg` box placed after an image can act as an overlay.

The utility positions the element absolutely, sizes it to the parent, uses z-index `-2`, and makes the direct parent `position: relative` with an isolated stacking context. The overlay layer uses `-1`.

Every `.is-bg` value is locally overridable:

| Token | Documented default |
| --- | --- |
| `--bg-position` | `absolute` |
| `--bg-inset` | `0` |
| `--bg-width` | `100%` |
| `--bg-height` | `100%` |
| `--bg-radius` | `0` |
| `--bg-z-index` | `-2` |
| `--bg-object-fit` | `cover` (images only) |
| `--bg-object-position` | `center` (images only) |

The `.is-bg` utility is unchanged from 3.x. Surfaces are new in 4.0.

## Sources

- [Contextual Backgrounds](https://docs.automaticcss.com/backgrounds/contextual-background-colors) — last updated 2026-08-07.
- [Surfaces](https://docs.automaticcss.com/backgrounds/surfaces) — last updated 2026-08-07.
- ["Is Background" (.is-bg)](https://docs.automaticcss.com/backgrounds/is-background-is-bg) — last updated 2026-08-07.
