---
title: "Colors (Palette)"
source_scope: "Official Automatic.css 4.x documentation: Palette Intro, Main Colors, Semantic Colors, Unified Lightness, and Transparencies"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Colors (Palette)

## Palette model

Configure the palette under **Palette**. ACSS converts entered colors to OKLCH, whose channels are Lightness (0–1), Chroma, and Hue. The panel contains Main Colors, Semantic Colors, and Palette Options.

For every enabled main color, ACSS generates these exact shade names: `ultra-light`, `light`, `semi-light`, `semi-dark`, `dark`, `ultra-dark`, plus a dedicated `hover` shade. All generated shades can be overridden.

## Main colors

The six exact named slots are:

| Name | Documented role |
| --- | --- |
| Primary | Main brand, key CTAs, links, and primary action |
| Secondary | Supporting brand/actions |
| Tertiary | Sparse third-brand variety |
| Accent | Rare special emphasis |
| Base | Backgrounds, body text, and default UI |
| Neutral | Greys, borders, dividers, disabled states, subtle backgrounds |

Enable only needed slots. Think in roles and use the matching token, such as `.btn--primary` or `var(--base-dark)`. The documentation explicitly demonstrates the main variable/shade naming pattern through `var(--base-dark)` and later color-scheme examples such as `var(--primary)` and `var(--primary-dark)`.

## Semantic colors

Exact semantic names:

- Warning — alert/caution.
- Info — general information.
- Success — safe/correct.
- Danger — error/wrong.

Semantic colors use the exact utility prefixes `.text--`, `.bg--`, and `.link--`. Append `{color}` or `{color-shade}`, for example `.text--warning-light`.

The documentation states variable patterns `var(--{name})` and `var(--{name}-{shade}` and lists these partial patterns for every semantic color:

- `{color}-hex`
- `{color}-hsl`
- `{color}-h`
- `{color}-s`
- `{color}-l`
- `{color}-rgb`
- `{color}-r`
- `{color}-g`
- `{color}-b`

> Source anomaly: the rendered shade-variable example is missing a closing `})`: `var(--{name}-{shade}`. It is preserved verbatim above and should not be treated as corrected syntax.

Before v3.0 these were called “contextual colors”; the current name is Semantic Colors.

## Unified Lightness

Configure under **Palette > Palette Options**:

- **Unify Brand Lightness**: forces the base swatch OKLCH L channel for Primary, Secondary, Tertiary, Accent, and Base; hue/chroma remain individual and generated shades retain their own lightness steps.
- **Unify Semantic Lightness**: applies the same base lightness to Success, Warning, Info, and Danger.
- **Unified Lightness**: shared value from `0` to `1`; documented default `0.65`. It appears when either toggle is on.

Neutral is not listed in the documented Unify Brand Lightness set.

## Transparencies in 4.x

ACSS 4.x ships no pre-built transparency tokens. Removed examples include `--primary-trans-10` and `--base-ultra-dark-trans-60`.

### `color-mix()`

Exact syntax: `color-mix(in <color-space>, <color> <percentage>, transparent)`.

```css
background: color-mix(in oklch, var(--primary) 20%, transparent);
border-color: color-mix(in srgb, var(--neutral) 60%, transparent);
```

Prefer `in oklch` for palette consistency; `in srgb` is also supported. The percentage is the proportion of the first color.

### Relative Color Syntax

Exact OKLCH syntax: `oklch(from <color> l c h / <alpha>)`.

```css
background: oklch(from var(--primary) l c h / 0.5);
color: oklch(from var(--base) l c h / 0.1);
```

Here `l`, `c`, and `h` retain the source channels and the value after `/` changes alpha. The channels may also be adjusted with `calc()`.

Choose `color-mix(in oklch, var(--color) X%, transparent)` for “this color at X% opacity”; choose `oklch(from var(--color) l c h / 0.5)` to retain the exact channels while changing alpha. Custom project transparency variables remain possible.

## Sources

- [Palette Intro](https://docs.automaticcss.com/colors/palette-intro) — last updated 2026-08-07.
- [Main Colors](https://docs.automaticcss.com/colors/main-colors) — last updated 2026-08-07.
- [Semantic Colors](https://docs.automaticcss.com/colors/semantic-colors) — last updated 2026-08-07.
- [Unified Lightness](https://docs.automaticcss.com/colors/unified-lightness) — last updated 2026-08-07.
- [Transparencies](https://docs.automaticcss.com/colors/transparencies) — last updated 2026-08-07.
