---
title: "Color Scheme"
source_scope: "Official Automatic.css 4.x documentation: Modern Color Scheme Workflow, Color Scheme Setup, and Implementing Color Scheme"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Color Scheme

## Modern workflow

ACSS 4.x uses the CSS `color-scheme` property with `light-dark()`. `color-scheme` declares the effective rendering context; documented values are `light`, `dark`, and `light dark`. `light-dark(light-value, dark-value)` returns the first argument in a light context and the second in a dark context.

```css
:root {
  color-scheme: light dark;
  --surface: light-dark(#fff, #1a1a1a);
  --text: light-dark(#111, #eee);
}
```

When Color Scheme Support is enabled, palette variables are emitted as `light-dark(light-value, dark-value)`. The light value is the dashboard design value. Shade pairs are auto-inverted (`ultra-light` ↔ `ultra-dark`, `light` ↔ `dark`, and `semi-light` ↔ `semi-dark`); main and hover dark values can be manually overridden. Existing names such as `--primary`, `--primary-dark`, and `--base-dark` resolve according to context.

Exact scheme utilities:

- `.scheme--light` — sets `color-scheme: light` for the subtree.
- `.scheme--dark` — sets `color-scheme: dark` for the subtree.

## Dashboard setup

Configure under **Color Scheme (Light/Dark)**.

**Enable Color Scheme Support**:

- Emits every palette variable as `light-dark(light-value, dark-value)`.
- Auto-inverts the shade scale.
- Activates `.scheme--light`, `.scheme--dark`, and force selectors.

**Website Scheme** sets `color-scheme` on `:root`:

| Dashboard option | Output/behavior |
| --- | --- |
| `light only` | `color-scheme: light` |
| `dark only` | `color-scheme: dark` |
| `light dark` | `color-scheme: light dark`; browser typically follows preference |
| `normal` | Browser decides without a declared preference |

**Color Settings** provides per-color Main Color Override and Hover Override controls for the dark side of `light-dark(main, alt)`, each using Lightness and Chroma. Leaving them blank retains the light-scheme value.

**Force Scheme** accepts CSS selectors in Force Dark Scheme or Force Light Scheme. These set `color-scheme: dark` or `color-scheme: light` on the matched subtree. The utility classes provide the same local forcing without dashboard selectors.

## Implementation patterns

### Follow the user

Enable support and choose Website Scheme `light dark`. ACSS sets `color-scheme: light dark` on `:root`; browser/OS preference resolves every `light-dark(light, dark)` value and native form controls/scrollbars follow it.

### Manual switch

Enable support, choose `light only` or `dark only`, and have a control set `color-scheme: dark` or `color-scheme: light` on `<html>` or a root wrapper. A preference may be stored in `localStorage`. No token/class replacement is required.

### Local/component scheme

Keep the site default fixed and apply `.scheme--dark`, `.scheme--light`, custom `color-scheme`, or dashboard Force Scheme selectors to a wrapper. The nearest ancestor with `color-scheme` controls descendant palette resolution. Explicit background and foreground colors are required for visibly correct local inversion; inherited body colors/backgrounds do not themselves switch on an otherwise unstyled section.

### Custom light/dark value

Use `light-dark(light-value, dark-value)` directly in custom CSS or ACSS dashboard inputs for custom borders, shadows, backgrounds, or local palette overrides. Inside `.scheme--dark` the second value is used; inside `.scheme--light` or a light page the first is used.

## Sources

- [Modern Color Scheme Workflow](https://docs.automaticcss.com/color-scheme/modern-color-scheme-workflow) — last updated 2026-08-07.
- [Color Scheme Setup](https://docs.automaticcss.com/color-scheme/color-scheme-setup) — last updated 2026-08-07.
- [Implementing Color Scheme](https://docs.automaticcss.com/color-scheme/implementing-color-scheme) — last updated 2026-08-07.
