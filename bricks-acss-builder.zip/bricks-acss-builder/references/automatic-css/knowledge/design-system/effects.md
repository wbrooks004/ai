---
title: "Effects"
source_scope: "Official Automatic.css 4.x documentation: Effects Overview, Hover Effects, Entrance Effects, Exit Effects, On Visible, Easing Presets, Transition, Selection Styling, Gradient Fades, and Sticky"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Effects

All effects are opt-in and composable, and respect `prefers-reduced-motion`. Enable only required effects under **Effects > Options**; configure timing/distance in **Effects**. Hover effects work in modern browsers. Scroll animations depend on `animation-timeline: view()` (documented support: Chrome 115+ and Edge 115+) and fall back to visible, unanimated content. On Visible uses Intersection Observer.

## Hover effects

All hover utilities use `.on-hover--*`.

| Group | Exact classes |
| --- | --- |
| Transform | `.on-hover--grow`, `.on-hover--shrink`, `.on-hover--float`, `.on-hover--sink`, `.on-hover--slide-right`, `.on-hover--slide-left` |
| Shadow | `.on-hover--shadow`, `.on-hover--glow` |
| Filter/opacity | `.on-hover--brighten`, `.on-hover--fade` |
| Ripple | `.on-hover--ripple-out`, `.on-hover--ripple-in` |
| Outline | `.on-hover--outline-out`, `.on-hover--outline-in` |
| Underline | `.on-hover--underline-left`, `.on-hover--underline-center`, `.on-hover--underline-right` |

Effects can be combined, for example `class="card on-hover--grow on-hover--shadow on-hover--glow"`.

Documented local variables:

- `--hover-grow-amount`
- `--hover-float-amount`
- `--hover-shadow`
- `--hover-glow-color`
- `--hover-glow-spread`
- `--hover-glow-opacity`
- `--border-ripple-color`, `--border-ripple-width`, `--border-ripple-duration`, `--border-ripple-distance`
- `--border-outline-color`, `--border-outline-width`, `--border-outline-duration`
- `--border-underline-color`, `--border-underline-width`, `--border-underline-duration`
- `--hover-duration` — default `var(--transition-duration, 0.3s)`.
- `--hover-timing` — default `var(--transition-timing, ease-in-out)`.

Border effects reset existing `border` and `outline`; outline effects also set `overflow: visible` and inherit `border-radius`.

> Source anomaly: example values render with spaces between numbers and units, including `-12 px`, `0 12 px 32 px`, `30 px`, `2 px`, `0.4 s`, `8 px`, and `0.15 s`. These renderings are preserved here rather than silently corrected.

## Entrance effects

Entrance effects continuously respond to scroll through `animation-timeline: view()`.

Exact element classes: `.on-enter--fade`, `.on-enter--float`, `.on-enter--sink`, `.on-enter--slide-left`, `.on-enter--slide-right`, `.on-enter--grow`, `.on-enter--shrink`, `.on-enter--blur`, `.on-enter--parallax`.

Use the `-all` pattern for direct children, such as `.on-enter-all--fade` and `.on-enter-all--float`. Add `.on-enter--stagger` to the parent to stagger direct children; the documented default interval is `5%` of the scroll range and relies on `sibling-index()`.

Exact variables and documented defaults/examples:

| Variable | Value or role |
| --- | --- |
| `--animate-range-start` | default `entry 20%` |
| `--animate-range-end` | default `entry 100%` |
| `--enter-opacity-start` | example `0.2` |
| `--enter-float-distance` | example `60 px` |
| `--enter-sink-distance` | example `60 px` |
| `--enter-slide-distance` | example `60 px` |
| `--enter-scale-start` | example `0.8` |
| `--enter-scale-shrink` | example `1.2` |
| `--enter-blur-amount` | example `12 px` |
| `--enter-parallax-distance` | example `200 px` |

The parallax parent should have `overflow: hidden`. ACSS includes an unsupported-browser fallback matching `[class*="on-enter--"]` and setting `opacity: 1`, `transform: none`, and `filter: none`.

## Exit effects

Exact element classes: `.on-exit--fade`, `.on-exit--float`, `.on-exit--sink`, `.on-exit--slide-left`, `.on-exit--slide-right`, `.on-exit--grow`, `.on-exit--shrink`, `.on-exit--blur`.

Use the `-all` pattern for direct children, such as `.on-exit-all--fade`. Add `.on-exit--stagger`; its documented default is `5%` of the scroll range and it relies on `sibling-index()`.

| Variable | Value or role |
| --- | --- |
| `--exit-range-start` | default `cover 50%` |
| `--exit-range-end` | default `cover 100%` |
| `--exit-opacity-target` | example `0.3` |
| `--exit-float-distance` | example `60 px` |
| `--exit-sink-distance` | example `60 px` |
| `--exit-slide-distance` | example `60 px` |
| `--exit-blur-amount` | example `12 px` |
| `--exit-scale-grow` | example `1.2` |
| `--exit-scale-amount` | example `0.8` |

Range values can also use `exit`, as in `exit 0%` and `exit 80%`. Entrance and exit utilities may be combined on one element.

## On Visible

On Visible plays once when an element enters the viewport, adds `acss-visible`, and stays at the final state. Exact element classes: `.on-visible--fade`, `.on-visible--float`, `.on-visible--sink`, `.on-visible--slide-left`, `.on-visible--slide-right`, `.on-visible--grow`, `.on-visible--shrink`, `.on-visible--blur`.

Use the `-all` pattern for direct children, such as `.on-visible-all--fade`, `.on-visible-all--float`, and `.on-visible-all--blur`. Add `.on-visible--stagger`; its documented default interval is `0.1s` and it relies on `sibling-index()`.

| Variable | Documented default/example |
| --- | --- |
| `--visible-duration` | default `0.6s` |
| `--visible-timing` | default `var(--ease-smooth)` |
| `--visible-delay` | default `0s` |
| `--visible-threshold` | default `0.2` (range 0–1) |
| `--visible-opacity-start` | example `0.2` |
| `--visible-float-distance` | example `60 px` |
| `--visible-sink-distance` | example `60 px` |
| `--visible-slide-distance` | example `60 px` |
| `--visible-scale-start` | example `0.8` |
| `--visible-scale-shrink` | example `1.2` |
| `--visible-blur-amount` | example `12 px` |

For UI controlled by application logic, add the exact boolean attribute `data-skip-acss-visible` so the observer ignores it, then add/remove `acss-visible` in JavaScript. Removing the class resets the hidden state and permits replay.

Reduced-motion behavior targets `[class*="on-visible--"]`, sets `transition: none !important`, `opacity: 1`, `translate: none`, `scale: none`, and `filter: none`.

## Easing presets

Configure five nameable slots under **Effects > Options > Easing Presets**. The first four are populated; the fifth is empty. Renaming slot 1 to `default` produces `var(--ease-default)`.

| Variable | Exact documented default |
| --- | --- |
| `--ease-smooth` | `cubic-bezier(0.4, 0, 0.2, 1)` |
| `--ease-snappy` | `cubic-bezier(0.16, 1, 0.3, 1)` |
| `--ease-gentle` | `cubic-bezier(0.65, 0, 0.35, 1)` |
| `--ease-bouncy` | `cubic-bezier(0.68, -0.55, 0.265, 1.55)` |
| `--ease-elastic` | `linear(0, 0.029 1.6%, ...)` |

Accepted input forms include `cubic-bezier(x1, y1, x2, y2)`, `linear`, `ease`, `ease-in`, `ease-out`, `ease-in-out`, `steps(n, start|end)`, and `linear(...)`. Disable under **Effects > Options > Easing Preset Variables**. In 4.0, easing uses five nameable slots; default names remain `smooth`, `snappy`, `gentle`, and `bouncy`.

## Transition variables

`var(--transition)` is the precomputed combination of duration, timing function, and delay. Specify the property separately:

```css
.my-card {
  transition: background var(--transition), color var(--transition);
}
```

Granular variables are `var(--transition-duration)`, `var(--transition-timing)`, and `var(--transition-delay)`. Use them for local overrides because remapping a constituent does not change the already-computed `var(--transition)`. Disable with **Transition Variables**. The `.transition` class and manual transition-assembly input were removed in 4.0.

## Selection styling

The Selection Styling panel under **Additional Styling** provides default foreground/background fields and a second alternate pair. Use `.selection--alt` on a box to apply the alternate style to it and all descendants. Color tokens are recommended for color-scheme compatibility.

## Gradient fades

Fade utilities visually blend content into any background. Utilities must be enabled under **Options > Utility Classes > Fade Classes**; the recipes and mixin remain available when utilities are disabled.

- Class pattern: `.fade--{axis}`.
- Exact axis extensions: `block`, `inline`, `top`, `right`, `bottom`, `left`.
- Local amount variable: `--fade-amount`.
- SCSS mixin: `@include fade($axis, $amount)`; `$amount` is optional and defaults to `25%`.
- Recipes: `?fade-block;`, `?fade-inline;`, `?fade-top;`, `?fade-right;`, `?fade-bottom;`, `?fade-left;`.

The mixin works only in the ACSS Custom SCSS area, not builder inputs or builder CSS. Recipes expand only when the final semicolon is typed, not when the string is pasted.

> Source anomaly: the source says “inline access” where context indicates the inline axis, and “Choose and element” where context indicates choose an element. The source wording is not used to alter any token.

## Sticky

Add `.sticky` to an element. It applies `position: -webkit-sticky`, `position: sticky`, and `inset-block-start: var(--sticky-offset, 0)`. The local token is `--sticky-offset`, default `0`.

Manual offset classes are `.sticky-top--s`, `.sticky-top--m`, and `.sticky-top--l`; configure their values under **Additional Styling > Sticky Settings**. Responsive global values are also supported there.

In 4.0, position utilities such as `.relative` and z-index utilities such as `.z--10` and `.z--20` were removed. Sticky now uses `--sticky-offset` and `inset-block-start`.

> Source anomaly: examples render offset values as `80 px`, `100 px`, and `3 em`.

## Sources

- [Effects Overview](https://docs.automaticcss.com/effects/effects-overview) — last updated 2026-08-07.
- [Hover Effects](https://docs.automaticcss.com/effects/hover-effects) — last updated 2026-08-07.
- [Entrance Effects](https://docs.automaticcss.com/effects/entrance-effects) — last updated 2026-08-07.
- [Exit Effects](https://docs.automaticcss.com/effects/exit-effects) — last updated 2026-08-07.
- [On Visible](https://docs.automaticcss.com/effects/visible-effects) — last updated 2026-08-07.
- [Easing Presets](https://docs.automaticcss.com/effects/easing-presets) — last updated 2026-08-07.
- [Transition](https://docs.automaticcss.com/effects/transition) — last updated 2026-08-07.
- [Selection Styling](https://docs.automaticcss.com/effects/selection-styling) — last updated 2026-08-07.
- [Gradient Fades](https://docs.automaticcss.com/effects/gradient-fades) — last updated 2026-08-07.
- [Sticky](https://docs.automaticcss.com/effects/sticky) — last updated 2026-08-07.
