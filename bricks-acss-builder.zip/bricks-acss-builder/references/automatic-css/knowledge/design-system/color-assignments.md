---
title: "Color Assignments"
source_scope: "Official Automatic.css 4.x documentation: Background & Text Assignments and Automatic Color Relationships"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Color Assignments

Color Assignments map palette colors to usage contexts so markup can remain stable when the palette changes.

## Background and text assignments

Default website tokens are `var(--body-bg-color)` and `var(--body-color)`. Configure background and text assignments under **Backgrounds & Text**.

Background options:

| Class | Variable |
| --- | --- |
| `.bg--light` | `--bg-light` |
| `.bg--dark` | `--bg-dark` |
| `.bg--ultra-light` | `--bg-ultra-light` |
| `.bg--ultra-dark` | `--bg-ultra-dark` |

There is also the default body background. Use classes when Automatic Color Relationships are required; the variables do not trigger relationships.

Text options:

| Class | Variable |
| --- | --- |
| `.text--light` | `--text-light` |
| `.text--dark` | `--text-dark` |
| `.text--light-muted` | `--text-light-muted` |
| `.text--dark-muted` | `--text-dark-muted` |

Both text classes and text variables are compatible with Automatic Color Relationships. The documented default main text value is `var(--text-dark)`; `var(--text-dark-muted)` is offered as an alternative default.

> Source anomaly: the setup prose renders the default background as `var(–white)` with an en dash; a later example renders the valid `var(--white)`. Both source forms are recorded without silently replacing the anomalous one.

## Automatic Color Relationships

Enable under **Backgrounds & Text > Options > Automatic Color Relationships**. This reveals **Light Relationships** and **Dark Relationships** panels. For each context, inputs include Text Color, Heading Color, Link Color, and Button Style. Use ACSS color variables; leave an input blank to retain its default.

For Button Style, enter a style name such as `primary` or `secondary`. To request an outline, append `.btn--outline`, for example `primary.btn--outline`.

The relationship is activated by a contextual class such as `.bg--ultra-dark`. This variable-only rule does **not** activate it:

```css
.my-hero {
  background: var(--bg-ultra-dark);
}
```

Individual relationship styles can be overridden with a custom class. For a secondary button inside a relationship, the documented Custom SCSS pattern is:

```scss
.button-you-want-to-override {
  @include btn(secondary);
}
```

The documented programmatic second-button pattern uses the CSS `nth-of-class` syntax:

```scss
.bg--ultra-dark :nth-child(2 of [class*="btn--"]) {
  @include btn(secondary);
}
```

> Source anomaly: explanatory prose after the example prints `.bg–ultra-dark` with an en dash, while the code block and the defined utility use `.bg--ultra-dark`. The anomalous prose form is not treated as a class.

## Sources

- [Background & Text Assignments](https://docs.automaticcss.com/color-assignments/background-text-assignments) — last updated 2026-08-07.
- [Automatic Color Relationships](https://docs.automaticcss.com/color-assignments/automatic-color-relationships) — last updated 2026-08-07.
