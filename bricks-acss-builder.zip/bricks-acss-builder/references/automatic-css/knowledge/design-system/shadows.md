---
title: "Shadows"
source_scope: "Official Automatic.css 4.x documentation: Shadows Overview, Box Shadows, Text Shadows, and Drop Shadows"
version_scope: "Automatic.css 4.x"
retrieved_at: "2026-08-23T16:25:00Z"
official_base_url: "https://docs.automaticcss.com"
---

# Shadows

The **Shadows** panel centralizes box, text, and drop-shadow presets. Each type has five nameable slots, default names `1` through `5`. Renaming a slot changes its custom-property suffix, such as `var(--box-shadow-subtle)`, `var(--text-shadow-subtle)`, or `var(--drop-shadow-subtle)`.

## Box shadows

Configure under **Shadows > Box Shadows**.

- `var(--box-shadow-1)`
- `var(--box-shadow-2)`
- `var(--box-shadow-3)`
- `var(--box-shadow-4)` — empty by default.
- `var(--box-shadow-5)` — empty by default.

```css
.my-card {
  box-shadow: var(--box-shadow-1);
}
```

Enter any valid `box-shadow` value without a semicolon; compound/multi-layer values are allowed. The first three slots ship as Subtle (light three-layer), Medium (four-layer), and Heavy (six-layer). Disable under **Options > Box Shadow Variables**.

In 4.0, the settings moved from Additional Styling; default names changed from `m`, `l`, `xl` to `1`, `2`, `3`; the total increased from three to five. Classes such as `.box-shadow--m` were removed; use variables. Numeric aliases such as `--box-shadow-1` are now primary.

## Text shadows

Configure under **Shadows > Text Shadows**.

- `var(--text-shadow-1)`
- `var(--text-shadow-2)`
- `var(--text-shadow-3)`
- `var(--text-shadow-4)` — empty by default.
- `var(--text-shadow-5)` — empty by default.

```css
.hero-heading {
  text-shadow: var(--text-shadow-1);
}
```

Enter any valid `text-shadow` value without a semicolon. Exact property form: `offset-x offset-y blur-radius color`.

| Slot | Exact documented default |
| --- | --- |
| 1 | `0 1px 2px hsl(0 0% 0% / 0.2)` |
| 2 | `0 2px 4px hsl(0 0% 0% / 0.3)` |
| 3 | `0 4px 8px hsl(0 0% 0% / 0.4)` |

Multi-layer values are supported. Use text shadows for legibility over images/gradients/video, heading depth, or glows. Disable under **Options > Text Shadow Variables**.

## Drop shadows

Configure under **Shadows > Drop Shadows**.

- `var(--drop-shadow-1)`
- `var(--drop-shadow-2)`
- `var(--drop-shadow-3)`
- `var(--drop-shadow-4)` — empty by default.
- `var(--drop-shadow-5)` — empty by default.

```css
.my-icon {
  filter: var(--drop-shadow-1);
}
```

Enter only the raw inner value; ACSS wraps it in `drop-shadow()`. Exact function value form: `offset-x offset-y blur-radius color`.

| Slot | Exact documented raw default |
| --- | --- |
| 1 | `0 1px 2px hsl(0 0% 0% / 0.15)` |
| 2 | `0 4px 6px hsl(0 0% 0% / 0.2)` |
| 3 | `0 10px 15px hsl(0 0% 0% / 0.25)` |

The rendered output example is:

```css
--drop-shadow-1: drop-shadow(0 1 px 2 px hsl(0 0% 0% / 0.15));
```

> Source anomaly: several free-form examples render spaces between values and units (`1 px`, `2 px`, etc.), while the default tables render valid compact units (`1px`, `2px`). Both forms are retained exactly in their relevant contexts.

Unlike `box-shadow`, `filter: drop-shadow()` follows the alpha channel and is suited to SVGs, transparent PNG/WebP images, `clip-path`, masks, and irregular shapes. It has no inset support and accepts one shadow per function, though multiple `drop-shadow()` filters can be chained. Disable under **Options > Drop Shadow Variables**.

## Sources

- [Shadows Overview](https://docs.automaticcss.com/shadow-filters/shadows-overview) — last updated 2026-08-07.
- [Box Shadows](https://docs.automaticcss.com/shadow-filters/box-shadows) — last updated 2026-08-07.
- [Text Shadows](https://docs.automaticcss.com/shadow-filters/text-shadows) — last updated 2026-08-07.
- [Drop Shadows](https://docs.automaticcss.com/shadow-filters/drop-shadows) — last updated 2026-08-07.
