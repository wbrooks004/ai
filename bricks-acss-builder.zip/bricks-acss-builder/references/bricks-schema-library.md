# Official Bricks Schema Library

## Authority

Bricks Academy publishes a machine-readable Bricks Data Model and a downloadable schema bundle for AI coding assistants, build tools, import/export scripts, validation, and transformation.

Official entry point:
- `https://academy.bricksbuilder.io/developer/schema/`

Official bundle:
- `https://academy.bricksbuilder.io/downloads/bricks-schema.zip`

Resolved JSON schemas are also exposed under:
- `https://academy.bricksbuilder.io/schema-resolved/`

The current documented schema version at the time this reference was revised is **2.3**. Treat the version as a runtime fact: verify it from the official source when currency matters.

## Usage Rule

Use the Bricks-supplied schema library as the generic JSON/schema authority.

Do not substitute a hand-maintained element-name registry for the official library.

Project-specific Bricks exports/configuration remain authoritative for:
- custom elements;
- project components;
- project global classes and variables;
- project pseudo-classes;
- project-specific state not represented by the generic schema.

## Validation Layers

Validate in this order:

1. JSON parse validity.
2. Common Bricks element envelope.
3. Element-specific schema/settings.
4. Parent/child graph integrity.
5. Global class/component/dependency integrity.
6. Project-specific evidence.
7. ACSS policy and target-configuration dependencies.

Schema validity and ACSS compliance are separate claims.

## Local Use

Refresh the official bundle:

```bash
python scripts/sync_bricks_schema.py
```

Validate using the downloaded zip:

```bash
python scripts/validate_acss_bricks.py \
  --strict \
  --bricks-schema-library references/data/bricks-schema.zip \
  output.json
```

An extracted schema directory may be supplied instead of the zip.

If the official library is unavailable, do not invent element-specific keys. Use supplied project evidence and mark schema-specific conclusions NOT VERIFIABLE.
