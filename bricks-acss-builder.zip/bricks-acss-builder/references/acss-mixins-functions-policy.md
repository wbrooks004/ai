# ACSS Mixins and Functions Policy

## Hard Boundary

ACSS mixins/functions are SCSS features intended for ACSS Custom SCSS/dashboard contexts.

They do not belong in Bricks builder CSS inputs.

### Allowed in ACSS Custom SCSS

Examples:

```scss
.third-party-button {
  @include btn(primary);
}
```

```scss
.some-icon {
  @include icon;
}
```

A supported ACSS function may also be used in Custom SCSS when appropriate.

### Not allowed in Bricks CSS

Do not emit:

```scss
@include btn(primary);
```

or SCSS-only ACSS functions into Bricks `_cssCustom`.

Bricks final CSS must be normal runtime-valid CSS.

## When Mixins Are Useful

Use ACSS mixins in Custom SCSS when:

- a third-party plugin selector cannot receive a normal ACSS class;
- a global generated selector should receive ACSS Button/Card/Icon behavior;
- a framework pattern must be compiled once at ACSS level;
- the behavior is clearly site-wide and belongs to the ACSS stylesheet.

Examples include:
- third-party buttons
- third-party icons
- externally generated markup
- selectors not controlled by Bricks
- global content/style integrations

## When Recipes Are Better

Use a Recipe for BEM/custom-class authoring inside a supported builder CSS field when the behavior is intended to live with that semantic class.

For generated Bricks JSON, resolve the Recipe into normal CSS before output.

## Functions

Use functions in ACSS Custom SCSS only.

A function such as `fluid()` can be appropriate for a genuinely unique fluid value.

Do not use `fluid()` to create a second global spacing/type system when ACSS already provides those systems.

For a one-off tweener, a small CSS `calc()` based on ACSS variables may be simpler and keeps the result directly attached to ACSS.

## Custom Properties

A custom property created through SCSS is justified when:
- the value is genuinely unique/reused;
- no native ACSS setting represents the role;
- it does not duplicate an existing ACSS scale;
- its ownership and scope are clear.

Prefer component-local scope to `:root` for component-specific behavior.

## Validator Rules

Bricks JSON should error when `_cssCustom` contains:
- `@include`
- SCSS variable declarations such as `$foo:`
- known SCSS-only ACSS function usage

The ACSS settings file may contain those constructs only inside the intended Custom SCSS field/context.

## Sources

- https://docs.automaticcss.com/mixins/button-mixins
- https://docs.automaticcss.com/mixins/icon-mixin
- https://docs.automaticcss.com/3.0/functions/fluid-function
