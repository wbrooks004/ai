# ACSS Layout and Responsive Decision Tree

## Goal

Produce layouts that respond to content first and viewport/device labels second.

Do not auto-generate tablet/mobile overrides.

## Decision Tree

```text
Need layout?
   ↓
Can normal block/flex/grid intrinsic behavior solve it?
   ↓ yes → use it
   ↓ no
Is it a repeated equal-priority collection?
   ↓ yes
Can Auto Grid / Variable Grid solve it?
   ↓ yes → use Auto/Variable Grid
   ↓ no
Does an incomplete final row need centering/stretch behavior?
   ↓ yes → Flex Grid
   ↓ no
Is exact column proportion important?
   ↓ yes → standard/unbalanced ACSS grid
   ↓ no
Is it editorial/rich content with feature/full-width zones?
   ↓ yes → Content Grid
   ↓ no
Does behavior depend on component width rather than viewport?
   ↓ yes → container query / card-container
   ↓ no
Use a content-driven media query only when necessary.
```

## Automatic Spacing First

If enabled, ACSS Automatic Spacing can own ordinary:

- section → child container gap
- content container child gap
- ACSS grid gap

Do not duplicate these values on every Bricks class.

Because Automatic Spacing is low/zero-specificity by design, component-specific overrides can still be added when needed.

## Contextual Spacing

Use:
- `--container-gap`
- `--content-gap`
- `--grid-gap`

for their actual contexts.

Use standard `--space-*` values for component-specific spacing that is not contextual.

## Sections

Use semantic `<section>` structure when appropriate.

Let ACSS own:
- default section block spacing
- gutter
- content width relationships

Use section spacing classes/variables for deliberate section rhythm changes.

Do not make every section carry identical manual padding.

## Standard Grid

Use for:
- fixed intended column count
- unequal ratio layouts
- layouts with clear structural tracks

Use current ACSS grid variables/Recipe behavior.

## Auto Grid

Use when:
- repeated items should intrinsically stack;
- a desired column count/minimum item width can control layout;
- device breakpoints are not meaningful.

A Recipe/mixin can provide more control than only the grid variable.

## Variable Grid

Use when minimum viable item width is the primary responsive constraint.

Use the Recipe when the full behavior/encapsulation is needed.

## Flex Grid

Use when:
- wrapping items should remain balanced;
- incomplete final rows should center or stretch;
- a conventional CSS Grid final row would look awkward.

Use current `?flex-grid` behavior.

## Content Grid

Use for:
- editorial/post content;
- controlled feature/full-width zones;
- rich content that needs breakout tracks.

Do not use it for normal cards merely because it is called a grid.

## Columns

Use `?columns` for flowing rich text columns.

Do not confuse flowing text columns with a component grid.

## Container Queries

Prefer a container query when a reusable component should adapt to its own available width.

Card Framework + `?card-container` is the first choice for card-specific component responsiveness.

## Media Queries

ACSS 4.x removed the old framework-wide fixed breakpoint dependency.

Media queries remain valid CSS.

Use them when:
- intrinsic layout cannot solve the state change;
- container size is not the right signal;
- a true viewport-related requirement exists.

Prefer content-driven thresholds over arbitrary device labels.

## Breakpoint Recipes

Current ACSS 4.x documents `?breakpoint-*` and `?breakpoint-up-*` Recipes.

Use them only when a media query is genuinely appropriate.

Resolve Recipe syntax before final Bricks JSON.

## Bridge Spacing Variables

Current ACSS spacing documentation includes bridge variables that transition between larger desktop and smaller mobile spacing roles.

They can reduce the need for media queries when a single t-shirt size does not provide enough fluid range.

Verify exact token spelling against the target ACSS project/runtime before use.

## Fine-Tuning

A small `calc()` adjustment from an ACSS variable is preferable to creating a new global token for a one-off tweener.

Do not create a custom spacing scale to avoid a small local calculation.

## Sources

- https://docs.automaticcss.com/spacing/automatic-spacing
- https://docs.automaticcss.com/spacing/spacing-variables
- https://docs.automaticcss.com/recipes/grid-recipes
- https://docs.automaticcss.com/grids/auto-grids
- https://docs.automaticcss.com/flexbox/flex-recipes
- https://docs.automaticcss.com/recipes/content-grid-recipe
- https://docs.automaticcss.com/recipes/card-container-recipe
- https://docs.automaticcss.com/recipes/media-query-recipes
- https://docs.automaticcss.com/setup/whats-new-in-4
