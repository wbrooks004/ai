# Layout Recipes — Automatic.css 4.x + Bricks

Composition guidance for generating maintainable Bricks layouts on Automatic.css 4.x projects.

Pair this file with:

- `references/acss-4x.md` for framework tokens and system rules
- `references/acss-json-policy.md` for raw Bricks JSON constraints
- `references/acss-style-examples.md` for component styling patterns
- `style-settings.md` for verified Bricks setting shapes
- `patterns/` for verified paste-ready structural examples

This file controls **layout decisions**.

It does not override verified Bricks JSON schema.

---

# Core Rule

Do not reproduce with generic Bricks settings or hand-written CSS what Automatic.css already provides as a framework, Recipe, variable, contextual token, or specialized feature.

Use the highest-level appropriate ACSS abstraction.

Priority:

1. ACSS dedicated framework
2. ACSS specialized layout system
3. ACSS Recipe
4. Framework-local token/property
5. Contextual ACSS variable
6. General ACSS variable
7. Native CSS / Bricks setting
8. Raw design value

Do not skip directly to levels 7–8 because they are easier to generate.

---

# ACSS 4.x Authority

Automatic.css 4.x is variable-first and BEM/custom-class-first.

Do not recreate ACSS 3.x utility-heavy workflows.

Do not build a parallel system for:

- section spacing
- gutters
- content width
- grid gaps
- content gaps
- container gaps
- card layout/styling
- responsive grid behavior
- sticky offsets
- contextual backgrounds
- color relationships
- divider styling
- icon behavior
- reusable animation/easing

Use ACSS before introducing custom equivalents.

---

# Documentation Version Rule

Use current ACSS 4.x documentation as the authority.

If an older feature page conflicts with a dedicated current 4.x Recipe page, use the current 4.x Recipe documentation.

Examples:

- Recipe syntax is `?`, not `@`.
- Auto Grid Recipe is `?auto-grid`.
- Flex Grid Recipe is `?flex-grid`.
- Cards must be explicitly targeted in ACSS 4.x.
- Old breakpoint utility workflows must not be restored.

Do not copy a 3.x example merely because it still exists in an older documentation URL.

---

# Recipes and Raw Bricks JSON

ACSS Recipes are **authoring-time expansion commands**.

Examples:

```css
?grid-3;
?auto-grid;
?flex-grid;
?content-grid;
?columns;
```

They expand into actual CSS in supported ACSS-aware CSS inputs.

They are not runtime CSS.

## When generating authoring instructions

Use the Recipe directly.

Example:

```css
.services-grid {
  ?auto-grid;

  --column-count: 3;
  --min: 18rem;
}
```

## When generating final raw Bricks paste JSON

Do not leave an unexpanded Recipe such as:

```css
?auto-grid;
```

inside JSON unless the target workflow is explicitly confirmed to perform ACSS Recipe expansion after paste.

Instead:

1. use the Recipe to choose the correct ACSS architecture
2. use native Bricks settings with ACSS variables when equivalent
3. or use the verified expanded CSS representation
4. preserve ACSS local variables/tokens
5. never replace the Recipe with an unrelated approximation

---

# Layout Selection Decision

Before constructing a layout, determine which ACSS system matches the problem.

## Use Content Grid when:

- content needs content / feature / feature-max / full-width zones
- editorial content needs occasional breakout media
- a section needs full-width children while preserving the site gutter
- wrapper reduction is useful
- the content should inherit ACSS content width automatically

## Use Auto Grid when:

- cards/items are equal-priority
- automatic content-driven stacking is desirable
- manual breakpoints are unnecessary
- column/row spanning is not important

Preferred authoring Recipe:

```css
?auto-grid;
```

Local controls include:

```css
--column-count
--min
```

## Use standard ACSS Grid when:

- the column count is intentional
- item placement matters
- column/row spans are needed
- asymmetric ratios are required
- layout changes must be explicitly controlled

Use ACSS grid variables or Grid Recipes.

## Use Variable Grid when:

- the layout should respond intrinsically to a minimum item width
- its behavior matches the Variable Grid system

Preferred Recipe:

```css
?variable-grid;
```

## Use Flex Grid when:

- an incomplete final row should center
- orphan grid items should optionally stretch
- CSS Grid's fixed row alignment is undesirable

Preferred Recipe:

```css
?flex-grid;
```

## Use Flexbox when:

- layout is fundamentally one-dimensional
- button groups, navigation, actions, simple rows, or simple stacks are involved

Preferred Recipes:

```css
?flex-row;
?flex-column;
```

## Use CSS Columns when:

- long text should flow through columns
- lists should flow through columns
- masonry behavior is desired

Preferred Recipe:

```css
?columns;
```

Do not use CSS Columns as a replacement for normal card grids.

---

# Page Anatomy

There are two primary ACSS page structures.

---

## Mode A — Standard Section Structure

Preferred default:

```text
section
└── inner div / container
    └── blocks / component trees
```

The section owns:

- section block spacing
- site gutter

The inner container owns:

- content width
- centering

Do not add unnecessary inline padding to the inner container.

Do not create an extra site gutter inside the inner container.

ACSS automatically applies its normal medium section spacing to top-level `section` elements.

Therefore:

**Do not add `_padding` to every generated Bricks section.**

Only override section block spacing when the design actually calls for a different rhythm.

---

## Mode B — Content Grid Section

Use Content Grid when the section benefits from ACSS layout zones.

Conceptually:

```text
section.content-grid
├── normal content       → content zone
├── feature content      → feature zone
├── wider content        → feature-max zone
└── full-width content   → full zone
```

Content Grid establishes:

- content width
- gutter behavior
- breakout zones
- responsive behavior

When Content Grid is applied directly to a `section`, ACSS handles the gutter differently and removes the section's normal inline padding.

Do not blindly combine a Content Grid section with the standard section/container structure.

Do not create a double gutter.

---

# Section Spacing

## Default

Use ACSS default section spacing.

Do not output:

```json
"_padding": {
  "top": "clamp(4rem, 8vw, 7rem)",
  "bottom": "clamp(4rem, 8vw, 7rem)"
}
```

for normal sections.

ACSS already controls top-level section spacing.

---

## Section Variant

When the design calls for a different section rhythm, prefer the section spacing class:

```text
.section--xl
```

or another appropriate ACSS section size.

When a semantic custom class needs to own the value:

```css
.hero {
  padding-block: var(--section-space-xl);
}
```

Do not create:

```css
--hero-section-padding
```

unless there is a legitimate component-specific reason and it maps back to ACSS.

---

# Contextual Spacing

Use contextual spacing according to meaning.

## Container gap

Spacing between multiple containers/groups in a section:

```css
gap: var(--container-gap);
```

## Content gap

Spacing between normal content elements:

```css
gap: var(--content-gap);
```

## Grid gap

Spacing between grid/column items:

```css
gap: var(--grid-gap);
```

Selection priority matters.

For example:

Card Framework `--card-gap`

beats:

```css
var(--content-gap)
```

because the framework-specific token is the stronger abstraction.

---

# Standard Grids

For reusable semantic grids, use ACSS grid variables.

Example:

```css
.services-grid {
  display: grid;
  grid-template-columns: var(--grid-3);
  gap: var(--grid-gap);
}
```

Bricks-setting equivalent when the fields accept CSS values:

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "var(--grid-3)",
  "_gridGap": "var(--grid-gap)"
}
```

Supported standard grid structures include one through twelve columns and the documented ratio grids.

Common ratios include:

```css
var(--grid-1-2)
var(--grid-1-3)
var(--grid-2-1)
var(--grid-2-3)
var(--grid-3-1)
var(--grid-3-2)
```

Do not replace these with:

```css
repeat(3, minmax(0, 1fr))
```

when the ACSS grid variable already represents the desired structure.

---

# Grid Recipes

ACSS exposes standard grid structures as Recipes.

Examples:

```css
?grid-2;
?grid-3;
?grid-4;
?grid-1-2;
?grid-2-1;
?grid-2-3;
?grid-3-2;
```

Use Recipes during ACSS-aware authoring when they improve workflow.

For raw JSON, prefer the equivalent verified Bricks grid setting with the ACSS grid variable when possible.

---

# Auto Grid

Use Auto Grid for intrinsically responsive collections of equal-priority items.

Preferred authoring:

```css
.services-grid {
  ?auto-grid;

  --column-count: 3;
}
```

When the content dictates a minimum useful item width:

```css
.services-grid {
  ?auto-grid;

  --column-count: 3;
  --min: 18rem;
}
```

The minimum item width should represent actual content requirements, not an arbitrary global breakpoint.

Do not generate:

```json
"_gridTemplateColumns:tablet_portrait": "...",
"_gridTemplateColumns:mobile_portrait": "..."
```

when Auto Grid solves the layout intrinsically.

## Auto Grid variable form

ACSS also provides:

```css
var(--grid-auto-3)
```

and related Auto Grid variables.

The variable form is less configurable because Recipe-local controls such as `--min` do not provide the same behavior through the encapsulated grid variable.

Use the Recipe when per-grid responsiveness must be tuned.

---

# Variable Grid

When Variable Grid better matches the design:

```css
.product-grid {
  ?variable-grid;

  --min: 18rem;
}
```

Use it before hand-writing an equivalent intrinsic `repeat()` formula.

Do not use Variable Grid merely because "responsive" appears in the request.

Choose the grid system based on the actual content behavior.

---

# Flex Grid

Use Flex Grid when orphan items on the final row should center or stretch.

```css
.logo-grid {
  ?flex-grid;

  --columns: 5;
  --gap: var(--grid-gap);
}
```

Local controls:

```css
--columns
--gap
--stretch
```

Example:

```css
.logo-grid {
  ?flex-grid;

  --columns: 5;
  --gap: var(--grid-gap);
  --stretch: 1;
}
```

Do not recreate Flex Grid's sizing math manually.

---

# Two-Column Layouts

Do not default every two-column layout to Flexbox.

Prefer CSS Grid for most content/media split layouts.

## Equal split

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "var(--grid-2)",
  "_gridGap": "var(--grid-gap)",
  "_alignItemsGrid": "center"
}
```

## Content-heavy split

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "var(--grid-2-3)",
  "_gridGap": "var(--grid-gap)",
  "_alignItemsGrid": "center"
}
```

## Media-heavy split

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "var(--grid-3-2)",
  "_gridGap": "var(--grid-gap)",
  "_alignItemsGrid": "center"
}
```

Do not use:

```json
"_columnGap": "64px"
```

when `var(--grid-gap)` represents the layout context.

---

# Responsive Two-Column Layouts

First determine whether the layout can be intrinsic.

Prefer, in order:

1. Auto Grid / Variable Grid when appropriate
2. Content Grid when appropriate
3. container query for reusable components
4. a content-driven media query
5. Bricks device-specific settings only when necessary

Do not automatically produce tablet and mobile overrides.

---

# Media Query Recipes

When custom CSS genuinely needs a media query, ACSS provides Recipes so the author does not need to memorize configured breakpoint values.

Max-width Recipes:

```css
?breakpoint-xs
?breakpoint-s
?breakpoint-m
?breakpoint-l
?breakpoint-xl
?breakpoint-xxl
```

Min-width Recipes:

```css
?breakpoint-up-xs
?breakpoint-up-s
?breakpoint-up-m
?breakpoint-up-l
?breakpoint-up-xl
?breakpoint-up-xxl
```

Use these during authoring.

Do not place the unexpanded command into final JSON.

Do not add a breakpoint merely because a desktop layout exists.

---

# Content Grid

Content Grid should be considered before manually constructing complex full-width breakout layouts.

Authoring Recipe:

```css
?content-grid;
```

Default content uses the normal content zone.

Feature content can be assigned programmatically:

```css
.article-body > figure {
  grid-column: feature;
}
```

Feature-max:

```css
.article-body > .wide-media {
  grid-column: feature-max;
}
```

Full:

```css
.article-body > .full-bleed {
  grid-column: full;
}
```

Full-width-safe behavior:

```css
.full-safe {
  grid-column: full;
  padding-inline: var(--gutter);
}
```

Do not reproduce these zones with arbitrary negative margins and viewport-width calculations when Content Grid solves the problem.

---

# Cards

Cards are not generic decorated blocks when the ACSS Card Framework is available.

## Card workflow

1. Create a semantic card class.
2. Use correct BEM child naming.
3. Explicitly target the main card selector in ACSS Card Options.
4. Let the Card Framework apply defaults.
5. Override framework tokens only where the design differs.

Example classes:

```text
.service-card
.service-card__media
.service-card__heading
.service-card__text
.service-card__actions
```

Icons inside Card Framework cards must participate in the Icon Framework through:

```text
data-icon
```

Do not style a new card from scratch with literal background, padding, border, radius, and gap values.

---

# Card Framework Tokens

Use Card Framework controls before generic values.

Examples:

```css
.service-card {
  --card-padding: var(--space-l);
  --card-gap: var(--space-m);
  --card-heading-size: var(--h3);
}
```

Relevant framework tokens include:

```css
--card-padding
--card-gap
--card-radius
--card-border-width
--card-border-style
--card-border-color
--card-background
--card-heading-size
--card-heading-color
--card-text-size
--card-text-color
--card-link-color
--card-link-color-hover
--card-button-font-size
--card-icon-size
--card-icon-color
--card-avatar-size
--card-avatar-radius
--card-media-radius
--card-media-aspect-ratio
--card-shadow
```

Framework token overrides are preferred to redeclaring their consuming properties.

---

# Card Media

Use Card Framework media controls.

Example:

```css
.article-card {
  --card-media-aspect-ratio: 16 / 9;
}
```

If media needs different object-fit behavior and ACSS Auto Object Fit is enabled, remap its controls rather than repeating object-fit on every image.

Example:

```css
.article-card {
  --object-fit: cover;
}
```

Do not invent:

```css
--article-image-fit
```

when the framework already provides an appropriate control.

---

# Responsive Cards

Use the Card Framework's container-query workflow before page-level device breakpoints.

Authoring Recipe:

```css
?card-container
```

Inside the card container query, remap card tokens.

Conceptually:

```css
--card-heading-size
--card-gap
--card-padding
--card-icon-size
--card-media-aspect-ratio
```

Do not rewrite every consuming property inside the query.

The point of the Card Framework is to keep those properties globally connected.

---

# Clickable Cards

Prefer ACSS's accessible Clickable Parent workflow when a card needs a stretched click target.

When focus should visually transfer to the parent, ACSS provides:

```css
?focus-parent
```

Do not create an inaccessible absolutely positioned pseudo-link implementation merely to make the card clickable.

Avoid nested interactive controls that produce invalid interaction patterns.

---

# Card Hover Effects

Before hand-writing transforms, shadows, and transitions, check whether the enabled ACSS Effects system provides the intended behavior.

Examples include ACSS hover-effect classes for:

- float
- sink
- grow
- shrink
- shadow
- glow
- fade
- slide

When writing custom motion, prefer ACSS easing presets where available.

Do not default to:

```css
transition: transform 0.25s ease;
```

for every generated card.

Respect reduced-motion behavior.

---

# Flexbox

Use Flexbox for one-dimensional arrangements.

## Horizontal

```css
.actions {
  ?flex-row;
}
```

## Vertical

```css
.content-stack {
  ?flex-column;
}
```

## Center all

```css
.hero__content {
  ?center-all;
}
```

Other documented centering Recipes include:

```css
?center-left
?center-right
?center-top
?center-bottom
```

Do not repeatedly hand-build their complete flex/alignment/text-align declarations when the Recipe expresses the intended behavior.

---

# Hero Patterns

Hero composition should use the same ACSS systems as the rest of the page.

---

## Centered Hero

Structure:

```text
section.hero
└── container
    └── hero__content
        ├── eyebrow
        ├── h1
        ├── supporting text
        └── action group
```

Use normal ACSS section spacing unless the design requires more.

For a larger hero rhythm:

```css
.hero {
  padding-block: var(--section-space-xl);
}
```

Centering authoring pattern:

```css
.hero__content {
  ?center-all;
  gap: var(--content-gap);
}
```

Action group:

```css
.hero__actions {
  ?flex-row;
  gap: var(--space-s);
  flex-wrap: wrap;
}
```

Do not use:

```text
8rem
24px
16px
```

as automatic defaults.

---

## Split Hero

Prefer an ACSS Grid structure.

Typical:

```css
grid-template-columns: var(--grid-2);
gap: var(--grid-gap);
```

or an intentional ratio:

```css
grid-template-columns: var(--grid-2-3);
```

Choose Auto Grid or Variable Grid when intrinsic stacking is more suitable.

Do not automatically assign:

```json
"_heightMin": "80vh"
```

Hero height should be content/design-driven.

---

## Content Grid Hero

Consider Content Grid for hero layouts with:

- content-width copy
- breakout visual media
- full-width backgrounds
- feature-width elements

This can eliminate unnecessary wrapper structures.

---

## Background Hero

Use ACSS background/overlay systems before hand-building raw RGBA overlay gradients.

Do not default to:

```json
"rgba(2,6,23,0.75)"
```

Use configured ACSS colors, surfaces, overlays, or contextual relationships.

If a one-off custom overlay is genuinely necessary, keep its colors connected to the ACSS color system.

---

# Dark / Inverted Sections

Do not manually set a dark background plus white typography on every child.

Use ACSS contextual backgrounds when the intended relationship is "dark section."

Example:

```text
.bg--dark
```

or:

```text
.bg--ultra-dark
```

When Automatic Color Relationships are enabled, these contextual backgrounds can manage foreground relationships for:

- headings
- body text
- links
- buttons
- icons
- focus indicators

For explicit color-scheme behavior use ACSS scheme controls such as:

```text
.scheme--dark
.scheme--light
```

Do not duplicate a separate dark-section color architecture in Bricks.

---

# Section Header Pattern

Use a reusable semantic component.

Suggested structure:

```text
.section-header
├── .section-header__eyebrow
├── .section-header__heading
└── .section-header__text
```

Centered authoring pattern:

```css
.section-header {
  ?center-top;
  gap: var(--content-gap);
  margin-inline: auto;
}
```

Use a readable content-driven inline size when needed.

Do not assign raw component colors when the surrounding contextual color system should control them.

Do not use hard-coded margin-bottom such as `56px` merely to separate the header from the following grid.

Prefer layout-level contextual spacing.

Example:

```css
.features__container {
  gap: var(--container-gap);
}
```

or another semantically correct contextual spacing relationship.

---

# Logo / Social Proof Grid

Prefer Auto Grid.

Authoring:

```css
.logo-grid {
  ?auto-grid;

  --column-count: 6;
  --min: 7.5rem;
}
```

Use:

```css
gap: var(--grid-gap);
```

if the expanded layout does not already provide the desired gap.

Do not manually write:

```css
repeat(auto-fit, minmax(120px, 1fr))
```

when ACSS Auto Grid provides the intended abstraction.

---

# Testimonials

Use:

- Card Framework for testimonial cards
- Auto Grid for automatically responsive equal-priority testimonials
- Flex Grid when orphan-row centering is important
- standard Grid when explicit placement/spanning matters

Do not build testimonial cards as arbitrary decorated blocks.

---

# Pricing

Pricing layouts usually combine:

- Auto Grid or standard Grid
- Card Framework
- contextual backgrounds
- Card Framework token overrides for featured tiers

Example featured card:

```css
.pricing-card--featured {
  --card-padding: var(--space-xl);
  --card-heading-size: var(--h2);
}
```

Do not create an entirely separate featured-card styling system if token remapping is sufficient.

---

# FAQ

Use the appropriate Bricks accessible accordion element.

Preserve:

```text
faqSchema: true
```

when FAQ schema is intentionally required and the Bricks element supports it.

Use contextual spacing for the surrounding section and list layout.

If dividers are needed between FAQ items, prefer ACSS Divider Recipes.

Example authoring:

```css
?divider-all;
```

Do not manually duplicate border colors/widths on every FAQ row.

---

# Divider Patterns

ACSS 4.x provides:

```css
?divider-top
?divider-bottom
?divider-all
```

Use these before writing a standalone divider system.

If a particular instance differs, remap divider tokens locally rather than rebuilding it.

When `?divider-all` manages spacing, avoid simultaneously adding an independent flex/grid gap that creates double spacing.

---

# CSS Columns and Masonry

For flowing text, lists, or masonry-like presentation:

```css
?columns;
```

Useful Recipe-local controls include:

```css
--col-count
--col-min-width
--col-rule-style
--col-rule-width
--col-rule-color
--col-gap
--row-gap
```

Masonry example:

```css
.gallery {
  ?columns;

  --col-count: 3;
  --col-gap: var(--grid-gap);
  --row-gap: var(--grid-gap);
}
```

For intrinsic stacking:

```css
.gallery {
  ?columns;

  --col-min-width: 18rem;
  --col-gap: var(--grid-gap);
  --row-gap: var(--grid-gap);
}
```

Do not use the old ACSS masonry utility classes.

Do not default to Bricks Masonry settings if the ACSS Columns system better matches the desired layout.

Use Bricks native masonry only when its behavior/features are specifically needed.

---

# Overlap and Layering

Separate **background overlap effects** from **physical element overlap**.

## Background / section overlap

ACSS provides:

```css
?overlap
?overlap-alt
```

Use these when the desired effect matches the ACSS overlap system.

Their locally customizable controls include concepts such as:

```css
--background
--foreground
--overlap-amount
--overlay
```

Do not rebuild that same pseudo-element technique manually.

---

## Physical content overlap

A card/image physically moving into an adjacent section may still require normal positioning or negative margin.

Do not use magic numbers such as:

```json
"_margin": { "top": "-80px" }
```

when the amount can stay connected to ACSS spacing.

Prefer a semantic custom class using ACSS values.

Example:

```css
.overlapping-card {
  margin-block-start: calc(var(--space-xl) * -1);
}
```

For overlaps derived directly from section spacing, calculate from the section token instead of guessing the amount.

---

# Absolute Decorations

Native positioning is appropriate for decorative objects when no ACSS framework solves the behavior.

Use:

- semantic wrapper class
- `position: relative` on the containing block
- `position: absolute` on the decoration
- logical inset properties when practical
- `pointer-events: none` for non-interactive decoration

Spacing/offset values should use ACSS values where they represent design-system spacing.

Pure geometric values are allowed when required by the artwork.

---

# Sticky Layouts

Use the ACSS Sticky system before manual sticky declarations.

Framework class:

```text
.sticky
```

Local offset control:

```css
--sticky-offset
```

Do not default to:

```json
"_position": "sticky",
"_top": "96px"
```

when the ACSS sticky system is available.

Example concept:

```css
.toc {
  --sticky-offset: var(--space-m);
}
```

The global sticky offset should generally be configured through ACSS rather than duplicated across components.

Still verify that no ancestor prevents sticky behavior through incompatible overflow/layout settings.

---

# Sticky Headers

Header behavior belongs to the header/template system, not arbitrary page-element settings.

Account for ACSS header/offset functionality when enabled.

Do not reproduce the same sticky-header offset manually throughout page sections.

---

# Horizontal Scroll / Scroll Snap

If ACSS has no dedicated framework for the specific horizontal-scroll behavior, native CSS or verified Bricks controls are appropriate.

Keep reusable spacing connected to ACSS.

Conceptual custom class:

```css
.horizontal-scroll {
  display: flex;
  overflow-x: auto;
  gap: var(--grid-gap);
  scroll-snap-type: x mandatory;
}

.horizontal-scroll > * {
  scroll-snap-align: start;
}
```

Child basis/inline size should be content-driven.

Do not introduce arbitrary repeated gaps.

For a real interactive carousel, use the appropriate Bricks slider/carousel element instead of faking one with scroll snap when controls, autoplay, pagination, or accessibility behavior are required.

---

# Image Behavior

When ACSS Auto Object Fit is enabled, images already use framework-controlled object-fit behavior.

Local controls include:

```css
--object-fit
--object-position
```

Example:

```css
.product-gallery {
  --object-fit: contain;
}
```

Do not repeat:

```css
object-fit: cover;
object-position: center;
```

across every generated image when the framework already owns it.

---

# Footer Layout

Recommended high-level structure:

```text
footer
└── container
    ├── footer__grid
    │   ├── brand group
    │   └── navigation groups
    └── footer__bottom
```

Prefer ACSS Grid variables for the primary layout.

Example:

```css
.footer__grid {
  display: grid;
  grid-template-columns: var(--grid-2-1);
  gap: var(--grid-gap);
}
```

For more complex four-column desktop layouts, choose the grid system based on actual content requirements rather than hard-coding:

```text
2fr 1fr 1fr 1fr
```

as a universal default.

Use `var(--content-gap)` inside link groups.

For the footer bottom divider, prefer:

```css
?divider-top;
```

rather than manually creating `_borderTop` values.

---

# Navigation / Link Groups

Use one-dimensional layout logic.

Vertical group:

```css
.footer__nav {
  ?flex-column;
  gap: var(--content-gap);
}
```

Horizontal action/navigation group:

```css
.header__actions {
  ?flex-row;
}
```

Use the site's button system for CTA buttons.

Do not hand-build button padding, radii, typography, and hover behavior inside header/footer layout recipes.

---

# Buttons in Layouts

Standard actions should use ACSS Button styling.

For a genuinely custom button:

```css
.btn--custom {
  ?btn;
}
```

The `.btn--` naming convention retains ACSS global button defaults.

Do not use layout recipes to manually recreate button padding, border, radius, type, transition, and hover systems.

---

# Background Relationships

For repeating visual contexts, prefer semantic ACSS background assignments.

Examples:

```text
.bg--light
.bg--ultra-light
.bg--dark
.bg--ultra-dark
```

When Automatic Color Relationships are active, allow the framework to manage foreground relationships.

Do not generate literal combinations such as:

```text
background #0b1120
heading #ffffff
text #cbd5e1
button #38bdf8
```

for every section.

That creates a competing color architecture.

---

# Content Width and Gutters

Respect the distinction between:

- content width
- content-width-safe behavior
- physical section gutter
- Content Grid gutter behavior

Do not add safe-width gutter behavior inside a parent that already supplies the site gutter.

Avoid double gutters.

The normal inner section container should not receive arbitrary inline padding merely to "make it safe."

---

# Responsive Strategy

Use this order:

1. ACSS fluid design-system values
2. intrinsic layout
3. Content Grid
4. Auto Grid / Variable Grid
5. Flex Grid
6. component container query
7. content-driven media query
8. Bricks device override

Do not start at step 8.

---

# Bricks Responsive Settings

The existence of Bricks keys such as:

```text
:tablet_portrait
:mobile_portrait
```

does not mean they should be generated automatically.

Use them only when:

- a real layout state change is required
- the selected ACSS layout system cannot solve it intrinsically
- custom CSS/container queries are not the better abstraction
- the output specifically needs Bricks-native responsive controls

Do not create identical boilerplate breakpoints across every grid.

---

# Structural Literal Values

ACSS-first does not mean every numeric value must become an ACSS variable.

Structural values can legitimately remain literal.

Examples:

```css
0
1
100%
auto
1fr
1 / -1
16 / 9
50%
```

Content-driven thresholds can also be literal when they represent the actual point where a component/layout fails.

Examples include:

- Auto Grid `--min`
- Card container-query width
- a custom media query required by content
- asset-specific geometry

The prohibition is against arbitrary **design-system values**, not all numbers.

---

# Magic-Number Rule

Review literal values used for:

- padding
- margin
- gap
- recurring widths
- recurring heights
- section spacing
- border radius
- animation timing
- repeated offsets
- colors

Before accepting one, ask:

1. Does an ACSS framework own this?
2. Does an ACSS Recipe expose a local control?
3. Does an ACSS contextual variable represent it?
4. Does an ACSS global variable represent it?
5. Is this genuinely a unique content/design requirement?

If the answer to 1–4 is yes, use ACSS.

---

# Common Anti-Patterns

## Bad — manual responsive grid

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "repeat(3, minmax(0, 1fr))",
  "_gridGap": "32px",
  "_gridTemplateColumns:tablet_portrait": "repeat(2, minmax(0, 1fr))",
  "_gridTemplateColumns:mobile_portrait": "1fr"
}
```

## Better — ACSS standard grid

```json
{
  "_display": "grid",
  "_gridTemplateColumns": "var(--grid-3)",
  "_gridGap": "var(--grid-gap)"
}
```

Then add a responsive state only when it is genuinely required.

## Better still — Auto Grid when the content allows it

Authoring:

```css
?auto-grid;

--column-count: 3;
--min: 18rem;
```

---

## Bad — generic card

```json
{
  "_background": { "color": { "hex": "#ffffff" } },
  "_padding": {
    "top": "32px",
    "right": "32px",
    "bottom": "32px",
    "left": "32px"
  },
  "_rowGap": "16px"
}
```

## Better

Create a semantic card class, target it in the ACSS Card Framework, and override only necessary Card Framework tokens.

---

## Bad — manual dark section

```text
dark background
+ white text
+ explicit heading colors
+ explicit link colors
+ explicit button colors
```

## Better

Use the appropriate ACSS contextual background and color relationships.

---

## Bad — magic sticky top

```json
"_position": "sticky",
"_top": "96px"
```

## Better

Use the ACSS Sticky system and its offset control.

---

## Bad — masonry via old utilities or arbitrary Bricks structure

Use:

```css
?columns;
```

when ACSS Columns is the correct solution.

---

# Page Composition Defaults

For a generic marketing/landing page request, a useful default content order is:

1. Header template
2. Hero
3. Social proof / logo strip
4. Problem or benefits section
5. Feature/service grid
6. Product, process, or media section
7. Testimonials
8. Pricing or offer section
9. FAQ
10. Final CTA
11. Footer template

This is a fallback composition, not a mandatory structure.

Adapt it to:

- page objective
- available content
- user journey
- conversion goal
- information hierarchy

Do not add sections merely to satisfy the default sequence.

---

# Composition-to-Framework Map

| Composition | Preferred ACSS approach |
|---|---|
| Normal page band | Standard section spacing |
| Wider/narrower section | `.section--{size}` or section token |
| Editorial/full-bleed layout | Content Grid |
| Feature grid | Grid / Auto Grid |
| Responsive card collection | Auto Grid |
| Orphan-centered card row | Flex Grid |
| Asymmetric columns | ACSS ratio Grid |
| Masonry | `?columns` |
| Card | Card Framework |
| Responsive card | Card Framework + `?card-container` |
| Vertical content stack | `?flex-column` + contextual gap |
| Horizontal actions | `?flex-row` |
| Centered hero content | `?center-all` |
| Custom button | `?btn` |
| Divided list/group | `?divider-*` |
| Background overlap | `?overlap` / `?overlap-alt` |
| Sticky sidebar | ACSS Sticky |
| Dark/light contextual band | contextual background + color relationships |
| Forced color scheme | `.scheme--dark` / `.scheme--light` |
| Custom breakpoint CSS | `?breakpoint-*` |

---

# Full-Page Generation Rules

When generating a complete Bricks page:

1. Choose standard sections versus Content Grid sections intentionally.
2. Do not apply custom section padding unless the section needs a variant.
3. Use contextual gaps.
4. Choose the correct grid system per section.
5. Use Card Framework for cards.
6. Use ACSS button behavior for actions.
7. Use contextual background/color relationships rather than literal color bundles.
8. Use framework Recipes where they solve a behavior.
9. Do not emit raw Recipe invocations into final paste JSON unless expansion is confirmed.
10. Avoid device-specific Bricks overrides unless justified.
11. Keep custom component classes semantic and reusable.
12. Keep literal design values exceptional rather than normal.

---

# Paste-Ready Deliverable Rule

When the user requests a complete page:

- page content may be delivered as one Bricks clipboard JSON payload
- header and footer templates may be separate payloads when template-level import is required
- reusable global classes must remain internally consistent
- ACSS framework requirements that cannot be encoded solely in the Bricks payload must be stated clearly outside the JSON unless the user requested JSON-only output

Examples of external project configuration include:

- adding card selectors to ACSS Card Options
- enabling an ACSS framework/module
- configuring contextual colors
- enabling Color Relationships
- enabling Auto Object Fit
- configuring Sticky defaults

Do not pretend a Bricks JSON payload can configure ACSS dashboard settings if it cannot.

---

# Final Layout Validation

Before finalizing any generated layout, verify:

## Sections

- top-level section spacing is not redundantly hard-coded
- gutters are not duplicated
- Content Grid and standard container architecture are not accidentally mixed
- section variants use ACSS

## Spacing

- card spacing uses card tokens where appropriate
- grid spacing uses grid gap
- content spacing uses content gap
- container grouping uses container gap
- general spacing variables are used only when no stronger context exists

## Grids

- correct ACSS grid system was selected
- Auto Grid is used when automatic stacking is appropriate
- Flex Grid is used only for its specific orphan-row behavior
- manual breakpoint boilerplate is absent
- unnecessary raw `repeat()` implementations are absent

## Cards

- Card Framework is used when available
- card selector targeting is accounted for
- BEM structure is correct
- card tokens are overridden instead of rebuilding framework properties
- icons use the required framework hook

## Responsive behavior

- intrinsic solutions were considered first
- container queries are used for reusable component responsiveness when appropriate
- media queries are content-driven
- Bricks device overrides are justified

## Colors

- contextual backgrounds are used where appropriate
- automatic color relationships are not bypassed unnecessarily
- raw repeated colors are absent

## Effects

- sticky uses ACSS when appropriate
- hover effects use ACSS when appropriate
- reduced motion remains respected
- magic transition/easing values are not repeated unnecessarily

## Recipes

- Recipe choice matches current ACSS 4.x documentation
- no deprecated `@recipe` syntax is used
- no raw `?recipe` remains in final JSON unless Recipe expansion is explicitly supported

## JSON

- all Bricks setting shapes come from verified references
- no undocumented Bricks fields were invented
- JSON parses successfully
- IDs and class references remain coherent

---

# Governing Principle

Do not generate a Bricks layout and then "ACSS-ify" it afterward.

Design the layout through Automatic.css from the start.

The model should think:

**What ACSS system owns this problem?**

before thinking:

**What CSS or Bricks settings can I write?**

The desired result is not merely Bricks JSON containing `var(--...)`.

The desired result is a Bricks layout whose architecture follows Automatic.css 4.x.