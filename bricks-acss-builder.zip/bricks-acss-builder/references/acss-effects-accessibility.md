# ACSS Effects and Accessibility Workflow

## Principle

Visual polish must not weaken keyboard access, focus visibility, motion preferences, or semantic interaction structure.

## Focus Styling

Keep ACSS focus styling enabled for normal builds.

Use the project focus settings globally.

If a local background makes the default focus color insufficient, override the local `--focus-color` on the container/component.

Do not remove outlines/focus indicators without an accessible replacement.

ACSS 4.x removed old `.focus--{color}` utility families; use the local focus variable where needed.

## Clickable Cards

For a card with a primary internal link that should make the entire card clickable:

- keep a real semantic link;
- use current `?clickable-parent` behavior on the link/heading element;
- ensure the parent is positioned as required;
- use current `?focus-parent` behavior on the parent when appropriate.

Do not wrap complex card content in a single giant anchor merely for convenience when the accessible parent technique is appropriate.

## Reduced Motion

Keep ACSS Reduce Motion support enabled for sites using effects/animation.

When a design requests animation:
- prefer ACSS Effects;
- ensure motion respects reduced-motion preferences;
- do not add critical information that is only understandable through motion.

## Easing and Transition

Use ACSS transition/easing settings and reusable easing slots for recurring motion.

Do not repeat arbitrary cubic-bezier/timing strings when an ACSS easing role should own them.

## Effects

Use ACSS native effects when the requested motion fits them.

Potential categories include:
- hover
- enter
- exit
- visible/on-scroll behavior
- transitions
- sticky behavior
- selection styling

Do not enable every effect module by default.

Enable/configure only the systems actually used.

## Selection Styling

If custom text selection styling is part of the visual system, configure it in ACSS rather than adding page-specific `::selection` rules.

## Motion vs Layout

Do not use animation/transforms to solve a layout problem that should be solved by grid/flex/container structure.

## Validation

Flag:
- focus styling disabled with no explicit alternative;
- effects enabled while reduced motion is disabled;
- clickable cards without keyboard focus treatment;
- old removed 3.x focus utility classes;
- repeated custom transition/easing definitions that ACSS could centralize.

## Sources

- https://docs.automaticcss.com/accessibility/focus-styling
- https://docs.automaticcss.com/recipes/accessibility-recipes
- https://docs.automaticcss.com/setup/whats-new-in-4
