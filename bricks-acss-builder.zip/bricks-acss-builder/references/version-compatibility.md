# Version Compatibility Policy

## Automatic.css

Target behavior baseline: Automatic.css 4.x, conservative enough for projects that remain on early 4.x behavior unless supplied project evidence proves newer features.

Do not use a newer ACSS feature merely because it exists in current documentation when the supplied target project does not prove it is available.

## Bricks

Use the **current official Bricks schema library** as the generic data-model authority:
- `https://academy.bricksbuilder.io/developer/schema/`
- `https://academy.bricksbuilder.io/downloads/bricks-schema.zip`

At the time this file was revised, Bricks documents schema version **2.3**. Verify the official source before making current-version claims.

Do not use the former bundled 2.3.6 element allowlist as generic authority.

## Compatibility Decision Rule

For project-specific state:
1. inspect supplied project/export data;
2. follow supplied project evidence where it conflicts with generic defaults;
3. use the official schema library for generic Bricks element/control/global/settings structures;
4. verify current Bricks documentation/changelog for behavior not represented by the schema;
5. avoid inventing fields;
6. state NOT VERIFIABLE when required evidence cannot be retrieved.

Custom/project elements may be proven through supplied project evidence even when absent from the generic Bricks library.

## Styling vs Schema

Keep concerns separate:
- Bricks/schema evidence determines data representation.
- ACSS/project configuration determines the styling system.

Version uncertainty in Bricks never justifies bypassing ACSS architecture.
