# ACSS Full-Settings Workflow

## Purpose

Use this workflow whenever a styled Bricks build starts from an Automatic.css settings export.

The complete ACSS settings export is the source document for the next complete ACSS import file.

Do not build a second design system and route it through ACSS. Configure ACSS itself.

## Required Inputs

For a final styled build, prefer:

1. complete current project ACSS settings JSON, or a compatible complete baseline export for a new site;
2. design/brand system or brand brief;
3. page/template requirements;
4. mockups, screenshots, Figma/reference designs, or token sets when available;
5. current Bricks export when project structure/schema preservation matters.

A current project export is authoritative evidence of current state. A baseline/example export is only a complete settings template unless the user explicitly declares it project-authoritative.

WS Forms Pro is the default form system for this skill.

## Output Order

For a new build or major redesign:

1. `acss-target.json` — complete replacement ACSS settings import
2. ACSS change report
3. Bricks page/template JSON generated against `acss-target.json`

Do not generate a partial ACSS import as the final settings artifact.

## Complete Replacement Rule

Start from the full source export.

Copy every key into the target.

Change only keys required by the target design, ACSS subsystem configuration, compatibility, or explicit cleanup.

Preserve unrelated technical settings.

Do not silently delete settings simply because the generator does not understand them.

When a supplied export contains unknown keys, preserve them unless the user explicitly requests removal or current ACSS documentation proves they are obsolete and removal is part of the requested migration.

## Native ACSS Before Custom CSS

For every reusable design decision, find the ACSS owner first.

Examples:

- brand colors → Palette
- foreground/background relationships → Color Assignments / Automatic Color Relationships
- dark/light scheme → Color Scheme
- global spacing scale → Standard Spacing
- section rhythm → Section Spacing
- normal container/content/grid gaps → Contextual + Automatic Spacing
- rich-text vertical rhythm → Smart Spacing
- headings/body type → Typography
- content width/gutter → Dimension / layout settings
- buttons → Buttons
- cards → Card Framework
- form design → Forms / WS Forms Pro
- icons → Icon Framework
- borders/radii → Borders
- dividers → Divider system
- recurring shadows → Shadow slots
- recurring surfaces → Surface slots
- recurring overlays → Custom Overlay slots
- recurring motion → Effects / easing slots
- layout repetition → Grid/Flex/Grid Recipes

Only after native ACSS ownership is exhausted should custom CSS be considered.

## "Use All ACSS Settings Possible"

Interpret this as:

> Treat ACSS systems as available design-system tools and use every relevant native subsystem that can own the target design more cleanly than Bricks-local styling.

Do not treat an `off` flag in a source/example export as a permanent restriction. When the target design needs that subsystem, enable and configure it in the target.

For new-site generation from a baseline/example export, assume supported ACSS design systems, utility systems, variables, classes, layout systems, effects, and component frameworks are available to be enabled as needed.

Do not turn unrelated administrative/developer features on merely to maximize toggle count. The goal is maximum appropriate ACSS ownership, not maximum switches.

A real current project export describes the starting state; explicit user requirements and the target design determine the target state.

## Brand/Design-System Translation

Before editing settings, derive the reusable design system from the supplied brand guide, design system, mockup, screenshot, Figma/reference design, or token source.

Then map those decisions into ACSS. Do not style Bricks first and retrofit ACSS later.

See `design-system-to-acss.md`.

## No New Parallel Global System

Do not create new global variables for values ACSS already owns.

Avoid new systems such as:

```css
:root {
  --site-space-1: ...;
  --site-space-2: ...;
  --site-h1: ...;
  --site-card-radius: ...;
  --site-shadow-raised: ...;
}
```

If a supplied legacy export already contains custom global tokens:

- preserve unrelated existing behavior by default;
- do not extend the custom system;
- for a clean/new build, migrate reusable design decisions into native ACSS settings when it can be done safely;
- do not remove existing custom CSS blindly.

Component-local variables are allowed for genuinely component-specific behavior.

## Design vs Technical Settings

Treat settings conceptually in two groups.

### Design-system settings

These may change freely to match the new build:

- palette
- shades/relationships
- typography
- spacing
- section spacing
- content width/gutter
- border/radius
- buttons
- cards
- forms
- icons
- shadows
- surfaces
- overlays
- effects/easing
- grid/layout behavior
- focus/selection styling

### Technical/project settings

Preserve unless the build requires a change:

- plugin/admin preferences
- integration flags unrelated to the design
- developer/debug settings
- unknown settings
- migration metadata
- project-specific operational controls

## ACSS Configuration Pass

Before Bricks generation, produce an internal ownership plan:

| Requirement | ACSS owner | Current state | Target state | Bricks consequence |
|---|---|---|---|---|
| 3-column service cards | Cards + Grid | inspect | configure | target `.service-card`, use ACSS grid behavior |
| orange CTA | Palette + Buttons | inspect | configure | use ACSS button class |
| dark hero | Color Assignments | inspect | configure | use contextual background behavior |
| contact form | Forms | inspect | configure | WS Forms Pro + ACSS Forms |
| recurring hero scrim | Custom Overlay | inspect | configure slot | apply overlay class |

Do not style Bricks until the ownership plan is resolved.

The target state may enable systems that are disabled in the current/baseline export. A source `off` value never justifies rebuilding the same reusable behavior locally in Bricks.

## Card Selector Synchronization

ACSS 4.x Card Framework requires explicit card targeting.

Whenever a new reusable card type is introduced:

1. add its wrapper selector to the ACSS Card Selectors setting;
2. keep the selector semantic, e.g. `.service-card`, `.team-card`, `.pricing-card`;
3. generate the Bricks wrapper with the same class;
4. use `--card-*` overrides for variants instead of rebuilding defaults.

## Button/Palette Synchronization

Do not rely on a button color group whose palette role is disabled.

When a required button group is needed:

1. ensure its palette role is enabled;
2. ensure the matching button group is enabled;
3. configure its colors/states;
4. then use the button class in Bricks.

## Forms — WS Forms Pro

Current ACSS 4.x Forms documentation supports WS Form.

For this skill, assume WS Forms Pro.

Before relying on ACSS form styling:

1. enable ACSS Forms;
2. enable Load Forms;
3. ensure WS Form Styler is enabled;
4. save WS Form settings when required so its generated system files/variables are current;
5. configure ACSS form settings globally;
6. use local `.form--light` / `.form--dark` only for explicit scheme overrides.

Do not rebuild the form design inside Bricks if ACSS Forms owns it.

## After Import

The user imports the complete target ACSS JSON.

If generated CSS is stale, regenerate ACSS stylesheets using the current supported ACSS workflow or CLI.

Current documented CLI command:

```bash
wp acss css regenerate
```

## Validation

Run:

```bash
python scripts/validate_acss_settings.py current-acss.json target-acss.json --strict
python scripts/diff_acss_settings.py current-acss.json target-acss.json
```

The target should:

- parse as JSON;
- remain a complete object;
- preserve all source keys unless an intentional migration says otherwise;
- not introduce new parallel global token systems;
- not enable button groups whose palette roles are disabled;
- keep accessibility/motion settings coherent;
- keep Card Framework selectors synchronized with generated card types;
- keep WS Forms Pro assumptions coherent when forms are used.

## Change Report

Report only meaningful changes.

Recommended categories:

- Palette / Color Assignments
- Typography
- Spacing / Sections
- Dimensions
- Buttons
- Cards
- Forms
- Icons
- Borders / Dividers
- Shadows
- Surfaces / Overlays
- Effects / Accessibility
- Layout / Grids
- Technical settings

For each changed setting include:

- key
- previous value
- target value
- reason

## Sources

- https://docs.automaticcss.com/
- https://docs.automaticcss.com/forms/form-styling-basics
- https://docs.automaticcss.com/cards/card-targeting
- https://docs.automaticcss.com/cards/card-styling
- https://docs.automaticcss.com/spacing/automatic-spacing
- https://docs.automaticcss.com/cli/settings
- https://docs.automaticcss.com/cli/css
