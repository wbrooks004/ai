# ACSS Subsystem Decision Map

## Purpose

Use this file before writing Bricks styling.

The primary question is not "which variable can I use?"

The primary question is:

> Which ACSS subsystem should own this reusable design decision?

Assume a supported ACSS subsystem can be enabled/configured when it is the correct owner. Do not bypass ACSS merely because that subsystem is `off` in the source or example export.

## Decision Table

| Design requirement | Preferred ACSS owner | Bricks output | Avoid |
|---|---|---|---|
| Brand palette | Colors / Palette | palette variables/classes | repeated literal colors |
| Light/dark foreground response | Color Assignments / Automatic Color Relationships | documented contextual background class/behavior | setting a background value and manually recoloring every child |
| Dark mode | Color Scheme | ACSS color-scheme behavior | custom duplicated dark token library |
| Body/heading typography | Typography | `--h*`, `--text-*`, inherited defaults | custom global clamp scale |
| Site spacing scale | Standard Spacing | spacing variables | custom global spacing scale |
| Section rhythm | Section Spacing | section behavior / section vars/classes | arbitrary per-section top/bottom padding |
| Container/content/grid rhythm | Contextual + Automatic Spacing | normal semantic structure | repeating gap declarations everywhere |
| Rich content rhythm | Smart Spacing | semantic content structure | manual margins on every rich-text child |
| Content width/gutter | Dimension / width + gutter settings | normal section/container structure | duplicated Bricks Theme Style widths |
| Standard cards | Card Framework | targeted semantic card wrapper | manually recreating card defaults |
| Card variation | Card Framework local `--card-*` overrides | modifier class | independent card styling system |
| Component-responsive card | `?card-container` behavior | expanded container-query CSS | arbitrary viewport breakpoint |
| Standard buttons | Buttons | ACSS button class | manual button reset/rebuild |
| Custom button | Button defaults + `?btn` | `.btn--custom` plus expanded Recipe | disconnected custom button |
| Forms | Forms + WS Forms Pro | WS Form element + ACSS styling | manual field/button theme in Bricks |
| Icons | Icon Framework | `data-icon` + semantic wrapper | repeated icon CSS |
| Global border/radius | Borders | ACSS border/radius variables | new radius scale |
| Repeated dividers | Divider system / Recipes | expanded divider behavior | removed 3.x divider utilities |
| Panel/card shadow | Box Shadow slot | ACSS shadow variable | repeated literal box-shadow |
| SVG/image silhouette shadow | Drop Shadow slot | ACSS drop-shadow variable | box-shadow on transparent shape |
| Repeated text shadow | Text Shadow slot | ACSS text-shadow variable | repeated text-shadow literals |
| Simple overlay | Basic Overlay | overlay class + local vars | hand-written pseudo-element |
| Reusable complex overlay | Custom Overlay slot | named overlay class | duplicated gradient pseudo-elements |
| Reusable surface | Surface slot | named surface behavior | new surface token library |
| Real image acting as background | `.is-bg` | real image element + ACSS behavior | unnecessary CSS background image |
| Repetitive grid | Auto/Variable/Grid system | ACSS grid behavior | device-first breakpoints |
| Centered uneven last row | Flex Grid | `?flex-grid` expansion | fragile nth-child hacks |
| Editorial wide/feature content | Content Grid | content-grid Recipe/behavior | custom one-off grid every article |
| Text columns | Columns | `?columns` | UI grid used for flowing text |
| Local fade into background | Fade Recipe/utility | expanded fade behavior | gradient matched manually to background |
| Clickable card | Accessibility Recipes | clickable-parent + focus-parent behavior | wrapping entire card in a link |
| Focus styling | Focus system | `--focus-color` local override if needed | removing visible focus |
| Reusable motion | Effects + easing | ACSS effects/variables | repeated timing/easing literals |
| Unique fluid one-off value | ACSS Custom SCSS `fluid()` if justified | resolved custom property/value | new global scale for one value |
| Third-party selector needs ACSS button/card/icon behavior | ACSS Custom SCSS mixin | compiled ACSS CSS | SCSS mixin inside Bricks CSS |

## Palette and Color Relationships

Use Palette for actual design roles.

Use Color Assignments to define how global text, headings, links, focus, buttons, backgrounds, and related foregrounds behave.

Use a documented contextual background class when the class itself is needed to trigger Automatic Color Relationships.

Do not assume:

```css
background: var(--bg-dark);
```

has the same behavior as applying the documented dark background relationship class.

The value and the framework behavior are different things.

## Spacing Ownership

Choose the most semantic spacing layer:

1. Automatic Spacing for ordinary framework structure
2. Contextual Spacing for container/content/grid relationship
3. Section Spacing for section rhythm
4. Standard Spacing for component-level padding/margin/gap
5. small `calc()` adjustment from an ACSS value for genuine tweeners
6. unique custom value only when the system cannot represent the design

Do not declare a component gap manually if enabled Automatic Spacing already supplies exactly the desired relationship.

## Cards

Treat a repeated content panel as a Card Framework candidate if it has multiple card-like concerns such as:

- padding
- internal gap
- border/radius
- shadow
- heading/text style
- icon/avatar
- media
- button/link styling

Add the wrapper selector to the Card Selectors ACSS setting before relying on Card Framework styling.

Prefer local overrides like:

```css
.pricing-card--featured {
  --card-shadow: var(--box-shadow-elevated);
  --card-heading-size: var(--h2);
}
```

over redeclaring the entire card.

## Buttons

Use the standard button system for ordinary CTAs.

A custom button should still use `.btn--...` naming so global button defaults apply.

Use `?btn` only for properties that make the button special.

Do not create BEM button styling from scratch when the standard ACSS button system can match the design.

## WS Forms Pro

Use ACSS Forms for WS Forms Pro.

Treat field appearance, spacing, labels, feedback, focus, tabs, progress, and standard form controls as ACSS-owned where the dashboard exposes them.

Only write custom Bricks/CSS styling for form behavior the ACSS/WS Form integration cannot express.

WS Form Styler must be enabled for current ACSS form styling.

## Borders and Dividers

Use:
- global border/radius settings for shared component geometry;
- Card Framework geometry for cards;
- Divider system for repeated separators;
- `?concentric-radius` when nested radius geometry needs the ACSS Recipe and Card Framework is not already solving it.

Do not combine `?divider-all` spacing blindly with flex/grid gap.

## Backgrounds, Surfaces, Overlays

Use:
- contextual background classes for relationship-aware section backgrounds;
- Surface slots for recurring surface treatments;
- Basic Overlay for simple overlay needs;
- Custom Overlay slots for recurring advanced overlays;
- `.is-bg` when a real image element should behave like a background.

If a visual treatment appears on more than one component/page, consider centralizing it in ACSS before writing component CSS.

## Shadows

Before adding a literal shadow, ask whether one of ACSS's reusable shadow slots should own it.

Prefer semantic slot names when the project has clear recurring roles such as:

- subtle
- raised
- floating
- modal
- media

Do not create a separate shadow variable system.

## Recipes

Recipes are preferred when ACSS intentionally removed a broad utility module and provides an on-demand expansion for BEM/custom classes.

Recipes are not runtime syntax. Resolve them before final Bricks JSON.

See `acss-recipes-4x.md`.

## Source Precedence

For project implementation decisions:

1. explicit project requirements and target design intent
2. supplied current project export/runtime as starting-state evidence
3. current 4.x feature page
4. current 4.x migration page for changed syntax/behavior
5. legacy `/3.0/` docs only as historical context

Use current official documentation to interpret generic semantics and migrations, not to silently replace verified project-specific settings or token spellings. If verified project state conflicts with current docs, report the contradiction and resolve it explicitly.

Never let a 3.x utility example override a verified 4.x Recipe workflow.

## Sources

- https://docs.automaticcss.com/
- https://docs.automaticcss.com/setup/whats-new-in-4
- https://docs.automaticcss.com/cards/card-styling
- https://docs.automaticcss.com/cards/card-targeting
- https://docs.automaticcss.com/buttons/button-styling
- https://docs.automaticcss.com/forms/form-styling-basics
- https://docs.automaticcss.com/spacing/automatic-spacing
- https://docs.automaticcss.com/overlays/custom-overlays
- https://docs.automaticcss.com/shadow-filters/box-shadows
