# ACSS 4.x Recipe Registry and JSON Policy

## Purpose

Use Recipes as an on-demand source of framework-authored CSS behavior for BEM/custom classes.

ACSS 4.x Recipes use `?`.

They are authoring-time expansion macros. They are not runtime CSS syntax.

## Hard Rules

- Never use old ACSS 3.x `@recipe` syntax in a 4.x build.
- Never leave raw `?recipe` strings in final Bricks paste/import JSON unless the destination will definitely expand them after import.
- Never guess the exact expanded CSS for a Recipe.
- Use current 4.x documentation when exact expansion matters.
- Emit normal runtime-valid CSS/settings into final Bricks JSON.

## Resolution Workflow

```text
Need non-token behavior
        ↓
Does ACSS have a relevant Recipe?
        ↓ yes
Verify current 4.x Recipe
        ↓
Resolve/expand the behavior
        ↓
Adjust exposed variables
        ↓
Emit ordinary CSS/settings into Bricks JSON
```

## High-Value Recipes

### Buttons

`?btn`

Use for a genuinely custom `.btn--custom` class.

Global ACSS button defaults should already apply because of `.btn--` naming.

Do not use it to rebuild standard Primary/Accent/etc. buttons.

Source:
https://docs.automaticcss.com/recipes/button-recipes

### Accessible clickable cards

`?clickable-parent`

Apply to the heading/link element whose link should cover the parent card.

Requirements include a relatively positioned parent and an actual link inside the heading/content element.

`?focus-parent`

Apply to the parent so keyboard focus is represented on the parent rather than only the internal link.

Use the pair for accessible clickable cards where appropriate.

Source:
https://docs.automaticcss.com/recipes/accessibility-recipes

### Card container queries

`?card-container`

Use with the ACSS Card Framework when card design should change based on the card's available inline size rather than viewport width.

Prefer changing `--card-*` custom properties inside the container query instead of redeclaring card properties individually.

Source:
https://docs.automaticcss.com/recipes/card-container-recipe

### Border radius

`?concentric-radius`

Use when nested geometry needs a concentric radius relationship and the Card Framework is not already handling it.

The Recipe uses a local padding variable as part of its radius relationship.

Source:
https://docs.automaticcss.com/recipes/border-radius-recipes

### Dividers

`?divider-top`

`?divider-bottom`

`?divider-all`

Use the global Divider system rather than removed 3.x divider utility classes.

`?divider-all` adds separator spacing programmatically; if the parent already uses flex/grid gap, resolve the spacing conflict intentionally.

Source:
https://docs.automaticcss.com/recipes/divider-recipes

### Flex layouts

`?flex-row`

`?flex-column`

`?center-all`

`?center-left`

`?center-right`

`?center-top`

`?center-bottom`

`?flex-grid`

Use for BEM/custom-class flex behavior after ACSS 4.x removed the old flexbox utility families.

`?flex-grid` is especially useful when an incomplete final row should remain visually balanced.

Source:
https://docs.automaticcss.com/flexbox/flex-recipes

### Standard grids

`?grid-1` through `?grid-12`

Common unbalanced versions include:

`?grid-1-2`

`?grid-1-3`

`?grid-2-1`

`?grid-2-3`

`?grid-3-1`

`?grid-3-2`

Use when a BEM class should receive the complete ACSS grid behavior rather than only a grid-template variable.

### Auto Grid

`?auto-grid`

Use for content-driven repeating layouts where column count and minimum item width should control intrinsic stacking.

### Variable Grid

`?variable-grid`

Use for responsive grid behavior driven by a minimum item width.

Source:
https://docs.automaticcss.com/recipes/grid-recipes

### Content Grid

`?content-grid`

Use for editorial/rich layouts with named content zones such as feature/full-width content.

Do not use it as a generic card grid.

Source:
https://docs.automaticcss.com/recipes/content-grid-recipe

### Text columns

`?columns`

Use for flowing rich text into responsive columns.

Do not use it for card/UI grid layout.

Source:
https://docs.automaticcss.com/recipes/column-recipes

### Gradient fades

`?fade-block`

`?fade-inline`

`?fade-top`

`?fade-right`

`?fade-bottom`

`?fade-left`

Use for content/media fade effects that should remain independent of the exact background color.

Current docs note that the Recipe trigger itself must be typed in an ACSS-aware editor to expand. Therefore generated JSON must contain the expanded result, not the trigger.

Source:
https://docs.automaticcss.com/recipes/gradient-fades

### Media queries

Max-width:

`?breakpoint-xs`

`?breakpoint-s`

`?breakpoint-m`

`?breakpoint-l`

`?breakpoint-xl`

`?breakpoint-xxl`

Min-width:

`?breakpoint-up-xs`

`?breakpoint-up-s`

`?breakpoint-up-m`

`?breakpoint-up-l`

`?breakpoint-up-xl`

`?breakpoint-up-xxl`

Use only after intrinsic layout/container-query options have been considered.

Important: ACSS 4.x removed framework dependence on fixed preset breakpoints, but media queries remain valid development tools.

Source:
https://docs.automaticcss.com/recipes/media-query-recipes

### Color Recipes

Pattern:

`?{color-name}-clr`

`?{color-name}-{shade}-clr`

Use when the expanded color function/partials are needed for a calculation.

Do not use a color Recipe merely to retrieve a normal palette value when `var(--primary)` or another normal ACSS color variable is enough.

Source:
https://docs.automaticcss.com/recipes/color-recipes

### Custom property

`?property`

Use for Houdini-style typed custom property declarations when an animatable/typed component property is genuinely required.

This is an advanced behavior, not a reason to create a parallel global token system.

Source:
https://docs.automaticcss.com/recipes/custom-property-recipes

## Conditional/Advanced Recipe Categories

Current 4.x documentation also contains Recipe categories for:

- Lists
- Overlap
- Query loops
- Text
- JavaScript
- Ipsum/demo content

Load the exact current page when one of these is needed.

Do not use Ipsum Recipes in production output.

Do not introduce JavaScript Recipe behavior unless actual script behavior is required by the component.

## Recipe vs Variable

Use a variable when the requirement is only a value.

Example:

```css
.service-card {
  padding: var(--space-m);
}
```

Use a Recipe when the requirement is a multi-declaration behavior/pattern that ACSS intentionally packages for custom classes.

## Recipe vs Utility

Use a documented ACSS utility/class when the class itself activates important framework behavior and the utility is still part of 4.x.

Use a Recipe when:
- the old utility family was removed;
- BEM/custom-class ownership is preferred;
- the behavior belongs directly to the semantic class.

## Recipe vs Mixin

Recipes:
- expand in supported builder CSS inputs and ACSS Custom SCSS;
- are appropriate sources for Bricks BEM CSS after expansion.

Mixins:
- are SCSS;
- belong in ACSS Custom SCSS;
- must not appear in Bricks builder CSS.

## Version Traps

Current ACSS 4.x migration guidance says Recipe syntax uses `?`.

Some legacy `/3.0/` pages or stale examples may still show `@`.

Do not follow `@` Recipe examples for a 4.x target.

## Sources

- https://docs.automaticcss.com/setup/whats-new-in-4
- https://docs.automaticcss.com/recipes/button-recipes
- https://docs.automaticcss.com/recipes/accessibility-recipes
- https://docs.automaticcss.com/recipes/card-container-recipe
- https://docs.automaticcss.com/recipes/border-radius-recipes
- https://docs.automaticcss.com/recipes/color-recipes
- https://docs.automaticcss.com/recipes/column-recipes
- https://docs.automaticcss.com/recipes/content-grid-recipe
- https://docs.automaticcss.com/recipes/custom-property-recipes
- https://docs.automaticcss.com/recipes/divider-recipes
- https://docs.automaticcss.com/flexbox/flex-recipes
- https://docs.automaticcss.com/recipes/gradient-fades
- https://docs.automaticcss.com/recipes/grid-recipes
- https://docs.automaticcss.com/recipes/media-query-recipes
