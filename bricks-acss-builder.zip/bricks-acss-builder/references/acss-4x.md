# Automatic.css 4.x — Bricks Styling Reference

## Purpose

This is the compact ACSS runtime reference for the skill.

For subsystem ownership and workflow, read:
- `acss-settings-workflow.md`
- `acss-subsystem-decision-map.md`

For Recipes, read:
- `acss-recipes-4x.md`

Do not treat this file as an exhaustive API catalogue.

## Core 4.x Direction

ACSS 4.x is variable-first and BEM/custom-class-first.

Most legacy utility modules were removed.

Important utility classes remain where the class itself provides framework behavior.

Recipes use `?` syntax in 4.x.

Preset breakpoints are no longer a dependency of the ACSS framework, although normal media queries and container queries remain valid CSS tools.

ACSS 4.x is not backward-compatible with ACSS 3.x conventions. Do not silently mix them.

## Documentation Authority

Separate project-state authority from generic product documentation.

For **project implementation state**, prefer:
1. explicit project requirements;
2. supplied current project export/runtime;
3. current 4.x feature documentation;
4. current 4.x migration/What's New page for changed syntax;
5. legacy `/3.0/` pages only as historical context.

For **generic ACSS semantics, deprecations, and migrations**, current official 4.x documentation is authoritative unless verified project evidence establishes that the site intentionally remains on different behavior.

If current documentation conflicts with verified project state, do not silently overwrite the project. Report the contradiction, preserve the verified project representation unless migration is requested, and verify current authoritative docs when possible.

Example of current-doc inconsistency: the 4.x migration page describes the XXL → 2XL naming change while current spacing documentation still contains `xxl` examples. Therefore do not rename or invent a 2XL/XXL token blindly; use what the target project actually exposes.

## Bricks Integration

Standard ACSS/Bricks mappings include:

- HTML/root font size → `var(--root-font-size)`
- content/container width → `var(--content-width)`

Keep Bricks Theme Styles minimal when ACSS owns the design system.

Do not duplicate ACSS typography, widths, spacing, button defaults, or other global values in Bricks Theme Styles unless a verified project requirement needs it.

## Core Layout/Dimension Variables

Common baseline:

`var(--root-font-size)`

`var(--content-width)`

`var(--gutter)`

Verify additional dimension variables against the target project/current docs.

## Standard Spacing

Standard spacing follows:

`var(--space-{size})`

Common 4.x project sizes include:

- xs
- s
- m
- l
- xl
- project/current-version large size token

Do not guess the large-size spelling when project/docs conflict.

Example:

```css
.service-card {
  padding: var(--space-m);
}
```

Do not create `--pad-m`, `--site-space-m`, or a parallel scale.

## Contextual Spacing

Use:

`var(--container-gap)`

`var(--content-gap)`

`var(--grid-gap)`

when the spacing has that contextual role.

If Automatic Spacing already applies the correct contextual gap, do not redeclare it just to make the class look explicit.

## Section Spacing

Section spacing follows:

`var(--section-space-{size})`

Top-level sections can receive default ACSS section spacing automatically.

Use a section spacing class/variable for deliberate rhythm changes.

Use:

`var(--gutter)`

for the site's inline gutter when appropriate.

## Bridge Spacing

Current ACSS spacing documentation includes bridge variables that fluidly transition between a larger desktop spacing role and a smaller mobile role.

These can avoid unnecessary media queries.

Verify exact token names against the current target ACSS runtime before using them.

## Typography

Heading sizes:

`var(--h1)` through `var(--h6)`

Text sizes use:

`var(--text-{size})`

Common useful project variables can include:

`var(--text-line-height)`

`var(--text-font-weight)`

Use additional typography variables only when verified in the target project/current docs.

Semantic HTML heading level and visual size are separate decisions.

## Grid

Standard grid variables commonly include:

`var(--grid-1)` through `var(--grid-12)`

Common unbalanced grids include:

`var(--grid-1-2)`

`var(--grid-1-3)`

`var(--grid-2-1)`

`var(--grid-2-3)`

`var(--grid-3-1)`

`var(--grid-3-2)`

Auto Grid variables can also exist, but the full Auto/Variable Grid Recipe behavior can provide more control than using only a template variable.

Use `acss-layout-decision-tree.md`.

## Border and Radius

Common global primitives:

`var(--border)`

`var(--radius)`

Use specialized radius/border variables only when verified.

For cards, let Card Framework own card border/radius behavior.

For dividers, use the Divider system instead of treating every separator as a generic border.

## Color Roles

Main palette roles can include:

- Primary
- Secondary
- Tertiary
- Accent
- Base
- Neutral

Semantic status roles include:

- Success
- Warning
- Info
- Danger

Only rely on a role when it is enabled/configured in the target ACSS settings.

Base variables follow role names, such as:

`var(--primary)`

`var(--accent)`

`var(--base)`

Generated shade variables depend on enabled/current project configuration.

Do not invent a shade token.

System values include:

`var(--white)`

`var(--black)`

Use palette configuration for brand values instead of repeating literal colors in Bricks classes.

## Automatic Color Relationships

A color variable supplies a value.

A documented ACSS contextual background class may also activate framework relationships for headings, text, links, buttons, icons, focus, and related foreground behavior.

When relationship behavior is required, use the documented behavioral class rather than only setting a background value.

## Buttons

Use the ACSS Button subsystem first.

Standard buttons should use the matching ACSS button class.

Custom buttons should retain `.btn--...` naming so global button defaults apply.

Current custom-button variables should be verified from the target settings/docs.

Use `?btn` as an authoring source for truly custom buttons; do not leave the Recipe trigger in final JSON.

## Cards

Use ACSS Card Framework for reusable cards.

Card selectors must be explicitly configured in ACSS 4.x.

Useful card variables include:

- `--card-padding`
- `--card-gap`
- `--card-radius`
- `--card-border-*`
- `--card-background`
- `--card-heading-*`
- `--card-text-*`
- `--card-link-*`
- `--card-button-font-size`
- `--card-icon-*`
- `--card-avatar-*`
- `--card-media-*`
- `--card-shadow`

Use local card variables for variants instead of redeclaring all default card styles.

## Forms

For this skill, the default form system is WS Forms Pro.

Current ACSS 4.x form styling documentation lists WS Form support.

Requirements include:
- ACSS Forms enabled;
- WS Form Styler enabled;
- ACSS form settings configured;
- WS Form settings saved/current.

Forms can follow ACSS color-scheme behavior.

Use `.form--light` / `.form--dark` only for explicit local overrides.

## Icons

Use ACSS Icon Framework when recurring icon styling is needed.

Use `data-icon` for icons that should participate in Card/Icon Framework styling.

Do not manually rebuild global icon styling when ACSS owns it.

## Shadows

ACSS 4.x provides configurable box-shadow slots and related shadow systems.

Use configured shadow variables.

Do not use removed 3.x box-shadow utility classes.

Prefer named semantic slots when the target project names them.

## Overlays and Surfaces

Use:
- Basic Overlay for simple overlays;
- Custom Overlay slots for recurring complex overlays;
- Surface slots for recurring surface treatments;
- `.is-bg` for real image elements acting visually as backgrounds where appropriate.

Do not duplicate complex overlay pseudo-element code throughout components when ACSS can centralize it.

## Recipes

Recipe syntax begins with `?`.

High-value examples include:

- `?btn`
- `?clickable-parent`
- `?focus-parent`
- `?card-container`
- `?concentric-radius`
- `?divider-top`
- `?divider-bottom`
- `?divider-all`
- `?flex-row`
- `?flex-column`
- `?center-*`
- `?flex-grid`
- `?grid-*`
- `?auto-grid`
- `?variable-grid`
- `?content-grid`
- `?columns`
- `?fade-*`
- `?breakpoint-*`

See `acss-recipes-4x.md`.

## Mixins and Functions

Mixins/functions are for ACSS Custom SCSS/dashboard contexts.

Do not put SCSS-only constructs into Bricks builder CSS.

See `acss-mixins-functions-policy.md`.

## Responsive Strategy

Default order:

1. fluid ACSS values
2. intrinsic CSS
3. Automatic/Contextual Spacing
4. ACSS Grid/Flex systems
5. Auto/Variable Grid
6. container query for component behavior
7. media query only when genuinely necessary

Do not produce device-breakpoint boilerplate.

## Raw Values

Literal values are allowed when they are structural rather than a competing design token.

Examples:

- `0`
- `1`
- `100%`
- `auto`
- `none`
- `inherit`
- `currentColor`
- `1fr`
- layout keywords
- aspect ratios
- opacity
- z-index
- transform values
- content-driven query thresholds
- asset-dependent dimensions

ACSS-first does not mean every number becomes a token.

It means reusable design-system decisions are owned by ACSS.

## Primary Sources

- https://docs.automaticcss.com/
- https://docs.automaticcss.com/setup/whats-new-in-4
- https://docs.automaticcss.com/spacing/spacing-variables
- https://docs.automaticcss.com/spacing/automatic-spacing
- https://docs.automaticcss.com/cards/card-targeting
- https://docs.automaticcss.com/cards/card-styling
- https://docs.automaticcss.com/forms/form-styling-basics
- https://docs.automaticcss.com/recipes
