# ACSS 4.x Policy for Bricks JSON

## Purpose

Define how ACSS-owned design decisions appear in raw Bricks paste/import JSON.

Bricks JSON shape and ACSS design ownership are separate:

- Bricks references determine valid data shape.
- ACSS determines reusable visual systems and runtime behavior.

Never let a legacy Bricks pattern override current ACSS policy.

## Precondition for Styled JSON

For a new styled build, generate/approve the complete target ACSS settings JSON first.

Bricks JSON must target that ACSS configuration.

Verify that the ACSS mechanism exists in the applicable version and ensure it is enabled/configured in the target settings.

Do not treat a source/example `off` value as a reason to avoid the mechanism. Enable the appropriate subsystem in the target when the design requires it.

## Semantic Class + ACSS Behavior

Use semantic Bricks global/custom classes for component identity.

Examples:

- `service-card`
- `service-card__media`
- `service-card__heading`
- `service-card--featured`

Attach documented ACSS behavioral classes in `_cssClasses` when the class itself activates framework behavior.

Examples include:
- standard ACSS button classes;
- contextual background relationship classes;
- overlay/surface classes;
- other current 4.x behavior classes verified for the target settings.

Do not replace semantic component identity with utility-class stacking.

## Native Subsystem Before Bricks Styling

Before adding Bricks style settings, check whether ACSS can own the behavior. If the correct subsystem is not yet enabled/configured in the source, configure it in the target before styling Bricks.

Examples:

- Card Framework already owns card padding/gap/radius/background/shadow → do not redeclare them on every card class.
- Automatic Spacing already owns normal container/content/grid gaps → do not duplicate them.
- Button system owns standard buttons → use the button class rather than rebuilding the button.
- WS Forms Pro + ACSS Forms own fields/form controls → avoid a second Bricks form theme.
- Custom Overlay slot owns a recurring scrim → apply the overlay class rather than duplicating pseudo-element CSS.

## CSS Variables in Bricks Values

When a Bricks control accepts normal CSS values and the design decision belongs to ACSS, use a verified target ACSS variable.

Examples:

- `var(--content-gap)`
- `var(--grid-gap)`
- `var(--space-m)`
- `var(--h2)`
- `var(--radius)`
- `var(--primary)`

Do not replace these with hard-coded equivalents.

## Card Framework in JSON

When a generated element is a Card Framework target:

- wrapper class must match a selector added to target ACSS Card Selectors;
- do not duplicate normal card defaults;
- use modifier classes with `--card-*` overrides for meaningful variants;
- attach `data-icon` to card icons when ACSS Card/Icon Framework styling is expected;
- use expanded `?card-container` behavior for card container-query variants when required.

The ACSS settings update and Bricks JSON must stay synchronized.

## Buttons in JSON

For ordinary buttons, attach the appropriate current ACSS button class in `_cssClasses`.

Do not create Bricks global classes that manually duplicate ACSS button padding, typography, border, radius, and transition unless the button is truly custom.

For a custom button:
- keep `.btn--...` naming;
- use verified expanded `?btn` behavior;
- emit only runtime-valid CSS.

## WS Forms Pro in JSON

Assume WS Forms Pro unless told otherwise.

Do not restyle standard fields globally in Bricks when ACSS Forms owns the form system.

Use Bricks/WS Form structure and identifiers correctly, then let ACSS Forms style it.

Use `.form--light` or `.form--dark` only for intentional local scheme overrides.

## Background Relationship Behavior

A background variable is not automatically equivalent to an ACSS contextual background class.

If Automatic Color Relationships are intended, attach the documented contextual class in `_cssClasses`.

Use the semantic Bricks class alongside it.

## Overlays/Surfaces

For a configured ACSS Surface or Overlay slot:

- attach the generated/named ACSS class;
- use local documented overlay/surface variables only for instance-specific adjustments;
- do not reproduce the full effect as custom pseudo-element CSS.

## Bricks Color Objects

Do not fabricate:

- palette IDs;
- color object IDs;
- undocumented object fields.

If a project export demonstrates a structured color representation, preserve that shape.

When a field accepts a CSS value, a verified ACSS variable is preferable.

If the structured representation is unknown, use semantic class/custom CSS with an ACSS variable rather than inventing a Bricks object.

## Recipes

Raw Recipe triggers are forbidden in final Bricks JSON by default.

Forbidden examples:

- `?btn`
- `?flex-grid`
- `?divider-all`
- old `@btn`
- old `@flex-grid`

Use the Recipe as a design/authoring source, resolve its current 4.x expansion, then store ordinary runtime-valid CSS/settings.

## Mixins and Functions

SCSS-only constructs are forbidden in Bricks CSS.

Examples:

- `@include btn(primary);`
- SCSS `$variables`
- ACSS SCSS-only functions

Those belong in ACSS Custom SCSS, not `_cssCustom`.

## Sections and Spacing

Prefer normal semantic ACSS structure:

- top-level section
- inner content wrapper
- normal content/grid children

Let enabled Automatic/Contextual Spacing own routine relationships.

Do not add redundant manual padding/gaps just because a pattern example has them.

Use deliberate section spacing only when the section's rhythm differs from the target default.

## Responsive Settings

Start with intrinsic/fluid ACSS behavior.

Only add a Bricks responsive setting when:
- Auto/Variable Grid is not appropriate;
- Flex Grid is not appropriate;
- a container query is not the correct signal;
- an actual viewport-related state change remains necessary.

Do not auto-create `tablet_portrait` / `mobile_portrait` values.

## Hard-Coded Colors

Literal reusable design colors are errors unless explicitly justified.

Brand colors belong in target ACSS palette/configuration.

Avoid repeated:
- hex;
- rgb/rgba;
- hsl/hsla;
- oklch;
- literal white/black.

## Hard-Coded Dimensions

Review literal dimensions on design-token-sensitive properties such as:

- reusable padding/margin/gap;
- section spacing;
- typography;
- recurring radius/border width;
- content width/gutter;
- recurring component sizes.

Structural numbers remain valid when they are not a competing design token.

## Custom Properties

Do not create new global design-system tokens that duplicate ACSS.

Component-local custom properties are acceptable for truly component-specific behavior.

Before introducing one, verify that:
- no ACSS subsystem already owns the role;
- it is not a hidden replacement spacing/color/type/radius scale;
- its scope is as local as practical.

## Legacy Examples

`patterns/legacy/` is structure-only.

When using legacy structure:

1. preserve JSON shape/nesting;
2. discard legacy styling;
3. rebuild against target ACSS subsystems;
4. remove obsolete responsive assumptions;
5. validate.

## Dashboard-Control Gate

For every significant repeated style, confirm that a future global design edit would be made at the intended ACSS/global owner and would propagate to the Bricks elements.

A visually accurate page fails the architecture when reusable colors, type, spacing, radii, shadows, buttons, card defaults, form defaults, widths, or layout values are needlessly duplicated at element level.

## Final JSON Gate

Confirm:

- JSON parses;
- element IDs are unique;
- parent/child relationships are reciprocal;
- class references resolve;
- ACSS behavioral classes are attached through valid Bricks class fields;
- Card selectors/settings and Bricks card classes agree;
- no raw Recipe trigger remains;
- no SCSS-only construct remains;
- no unintended literal design colors remain;
- no new parallel design-system tokens were introduced;
- reusable styles that ACSS should own remain dashboard-controlled;
- responsive overrides are justified;
- no undocumented Bricks schema was invented.
