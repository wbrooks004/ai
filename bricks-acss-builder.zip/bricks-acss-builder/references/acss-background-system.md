# ACSS Background, Surface, Overlay, Shadow, and Relationship System

## Purpose

Use this file whenever a design contains recurring backgrounds, context-sensitive foreground colors, hero scrims, textures, surfaces, or shadows.

## Automatic Color Relationships

A value and a behavior are not the same thing.

Setting a background value through a CSS variable does not automatically mean ACSS will apply class-triggered foreground relationships.

When a documented ACSS contextual background class is required to activate relationships, apply that class alongside the semantic BEM class.

Use BEM for component identity and ACSS behavioral classes for ACSS behavior.

Do not manually recolor every heading/link/button/icon if ACSS relationships can own the context.

## Color Assignments

Configure global assignments before page styling:

- body/background
- heading/text roles
- link roles
- focus color
- button relationship behavior
- light/dark contextual behavior

Avoid making each page independently decide the same foreground relationships.

## Color Scheme

For true light/dark builds, use ACSS 4.x color-scheme workflow and native light/dark-aware settings.

Do not create a second manually duplicated dark-mode palette unless the requirement cannot be modeled in ACSS.

## Contextual Backgrounds

Prefer contextual backgrounds when the design intent is semantic:

- light context
- ultra-light context
- dark context
- ultra-dark context

Use the current project/documented classes rather than inventing names.

## `.is-bg`

Use `.is-bg` when a real media/image element should behave visually as a background while retaining benefits of an actual image element, such as responsive image behavior and semantics.

Prefer this over converting every hero image into a CSS `background-image`.

## Basic Overlay

Use ACSS Basic Overlay for simple solid overlays.

It centralizes stacking behavior and exposes local overlay controls.

Do not hand-write the same `::before`/`::after` positioning stack for every hero.

## Custom Overlays

ACSS 4.x provides reusable Custom Overlay slots.

Use them for recurring effects involving:

- gradients
- images
- background positioning/repeat/size
- backdrop blur
- blend modes
- opacity
- radius
- inset
- animation

Promote a repeated hero/media overlay into an ACSS slot before writing duplicated component CSS.

Prefer semantic overlay names when the project establishes clear roles.

Examples:
- dark-gradient
- hero-scrim
- glass
- texture
- spotlight

Do not create a second overlay token library.

## Surfaces

Use ACSS Surface slots for recurring surface treatments.

Treat a recurring page/panel/sunken/raised surface as a design-system decision rather than a one-off background rule.

Do not confuse Surface identity with Card Framework identity; a card may use a surface, but the card's component defaults still belong to Card Framework.

## Box Shadows

ACSS 4.x provides five configurable box-shadow slots.

Use these for regular boxes/panels/cards/modals.

Prefer semantic names when helpful.

Use variables such as the current configured `--box-shadow-*` names rather than repeating literal shadow strings.

ACSS 4.x removed old box-shadow utility classes; use variables.

## Drop Shadows

Use drop-shadow presets when the shadow should follow a transparent/irregular visual silhouette, such as:

- SVG
- transparent PNG
- irregular icon/media

Do not automatically substitute box-shadow.

## Text Shadows

Use ACSS text-shadow slots for recurring text effects.

Avoid repeated literal text-shadow definitions.

## Local Overrides

When an ACSS overlay/surface/shadow exposes local properties, override only the needed local variable rather than redefining the whole behavior.

## Promotion Rule

When a visual treatment appears more than once, ask:

1. Is there an ACSS subsystem for it?
2. Can it occupy a named reusable slot?
3. Can all instances use that slot with small local overrides?

If yes, configure ACSS first.

## Validator Expectations

Warn when:

- identical literal box shadows repeat;
- repeated complex pseudo-element overlays appear;
- a relationship-aware context is manually recolored child-by-child;
- old shadow utility classes are used in ACSS 4.x;
- a new global custom shadow/overlay/surface token system is introduced.

## Sources

- https://docs.automaticcss.com/overlays/overlay-classes
- https://docs.automaticcss.com/overlays/custom-overlays
- https://docs.automaticcss.com/shadow-filters/box-shadows
- https://docs.automaticcss.com/setup/whats-new-in-4
