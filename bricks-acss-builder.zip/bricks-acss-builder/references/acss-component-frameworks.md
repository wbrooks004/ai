# ACSS Component Frameworks — Bricks Workflow

## Purpose

Use this reference when generating Cards, Buttons, Icons, Borders/Dividers, or WS Forms Pro output.

## Cards

### Use Card Framework first

A reusable card should normally be owned by the ACSS Card Framework.

ACSS 4.x requires explicit card targeting.

When generating a card type:

1. create a semantic wrapper such as `.service-card`;
2. add that selector to ACSS Card Selectors;
3. use card BEM conventions where useful;
4. let ACSS apply card defaults;
5. use local `--card-*` overrides for variants;
6. use `?card-container` behavior when card responsiveness depends on its container.

Do not manually apply the complete default card style if Card Framework can own it.

### Useful card variables

Current Card Framework exposes variables including:

- `--card-padding`
- `--card-gap`
- `--card-radius`
- `--card-min-radius`
- `--card-border-width`
- `--card-border-style`
- `--card-border-color`
- `--card-background`
- `--card-heading-size`
- `--card-heading-color`
- `--card-text-size`
- `--card-text-color`
- `--card-link-color`
- `--card-link-color-hover`
- `--card-button-font-size`
- `--card-icon-size`
- `--card-icon-color`
- `--card-avatar-size`
- `--card-avatar-radius`
- `--card-media-radius`
- `--card-media-aspect-ratio`
- `--card-shadow`

Use only variables needed for the variant.

### BEM child expectations

Card Framework understands card-oriented structure such as:

- `__media`
- `__avatar`
- headings
- `[data-icon]`

Do not target inner elements in the ACSS Card Selectors field; target the wrapper.

### Icons in cards

Card Framework icon styling requires `[data-icon]`.

If a Bricks icon inside a card should receive ACSS card/icon behavior, attach the data attribute according to the verified Bricks attribute schema.

## Buttons

### Standard buttons

Configure global ACSS Button styling first.

Use standard ACSS button classes when the design matches them.

Do not recreate:
- padding
- typography
- border
- radius
- transition
- basic hover states

on every BEM button class.

### Custom buttons

Use `.btn--custom-name` so global ACSS button defaults apply.

Use verified `?btn` expanded behavior for the custom aspects.

### Color relationships

Buttons may react to Automatic Color Relationships.

Use `.unrelate` only when a button must intentionally ignore those contextual relationships.

### Palette dependency

Do not use a color-specific button family when its palette role is disabled.

Synchronize palette role + button group in the ACSS target settings first.

## Forms — WS Forms Pro

### Assumption

This skill's default form platform is WS Forms Pro.

Current ACSS 4.x comprehensive form styling documentation lists WS Form compatibility.

### Requirements

Before generating a styled form:

- ACSS Forms enabled
- Load Forms enabled
- WS Form Styler enabled
- WS Form settings saved/current
- ACSS form design configured

ACSS currently relies on variables exposed by WS Form Styler.

### Styling strategy

Use the ACSS dashboard to own:

- form structural spacing
- field spacing/padding
- field borders/radius
- label styling
- help/error styling
- focus/invalid states
- field backgrounds/foregrounds
- checkbox/radio styling
- select/result styling
- progress/tabs where exposed
- form button styles
- light/dark adaptation

Avoid recreating the complete form theme in Bricks custom CSS.

### Color scheme

ACSS Forms can adapt to site color-scheme behavior.

Use `.form--light` or `.form--dark` only when an explicit local override is needed.

## Icons

Use the Icon Framework for recurring icon styling.

Prefer `data-icon` when the icon should participate in ACSS Icon/Card Framework behavior.

Centralize:
- icon color
- hover color
- size
- boxed/naked behavior
- padding
- border/radius
- background
- shadow

in ACSS where possible.

Use an Icon mixin only in ACSS Custom SCSS, not Bricks CSS.

## Borders

Configure global border variables in ACSS before component styling.

Prefer:
- `var(--border)`
- ACSS radius system
- Card Framework border/radius controls for cards

Do not create a new site-wide border/radius scale.

## Dividers

Use ACSS Divider variables/Recipes.

ACSS 4.x removed old divider utility classes.

Use:
- `?divider-top`
- `?divider-bottom`
- `?divider-all`

as Recipe sources for custom classes.

When `?divider-all` behavior is used on flex/grid parents, resolve any existing `gap` because the divider behavior manages spacing programmatically.

## Sources

- https://docs.automaticcss.com/cards/card-targeting
- https://docs.automaticcss.com/cards/card-styling
- https://docs.automaticcss.com/recipes/card-container-recipe
- https://docs.automaticcss.com/buttons/button-styling
- https://docs.automaticcss.com/recipes/button-recipes
- https://docs.automaticcss.com/forms/form-styling-basics
- https://docs.automaticcss.com/icons/icon-framework
- https://docs.automaticcss.com/borders-dividers/global-divider-system
- https://docs.automaticcss.com/recipes/divider-recipes
