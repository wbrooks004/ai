# ACSS 4.x Bricks Styling Examples

## Purpose

These examples demonstrate ACSS subsystem ownership, not merely token substitution.

The best ACSS solution often contains *less* component CSS because ACSS already owns the repeated behavior.

## Example 1 — Card Framework, not manual card rebuild

### Avoid

```css
.service-card {
  padding: var(--space-l);
  gap: var(--content-gap);
  background: var(--white);
  border: var(--border);
  border-radius: var(--radius);
  box-shadow: var(--box-shadow-1);
}
```

This uses ACSS values but manually rebuilds a system ACSS Card Framework can own.

### Prefer

Configure `.service-card` in ACSS Card Selectors.

Use target Card Framework settings for default padding, gap, radius, border, background, shadow, text, links, icons, media, and buttons.

Then a variant may need only:

```css
.service-card--featured {
  --card-shadow: var(--box-shadow-elevated);
  --card-heading-size: var(--h2);
}
```

Use only configured shadow names that exist in the target ACSS settings.

## Example 2 — ACSS button class in Bricks

For a standard primary CTA, attach the semantic component class plus ACSS behavior class.

Conceptual Bricks settings:

```json
{
  "_cssGlobalClasses": ["semantic-class-id"],
  "_cssClasses": "btn--primary"
}
```

Do not manually duplicate button padding, border, radius, font weight, and hover colors.

## Example 3 — Contextual background relationship

If a dark section should trigger ACSS foreground relationships:

```json
{
  "_cssGlobalClasses": ["hero-class-id"],
  "_cssClasses": "bg--dark"
}
```

Do not replace this with only:

```css
.hero {
  background: var(--bg-dark);
}
```

when automatic heading/text/link/button/icon/focus relationships are part of the intended behavior.

## Example 4 — Automatic Spacing

If the target ACSS settings enable Automatic Spacing and a normal section/container structure is used, avoid adding identical `row-gap` rules to every wrapper merely to be explicit.

Use semantic structure and let ACSS supply the contextual defaults.

Override only when the component intentionally differs.

## Example 5 — Auto/Variable Grid

For repeated cards, prefer intrinsic grid behavior when the design can be driven by content width.

Use current ACSS Auto/Variable Grid behavior or a verified expanded Recipe.

Do not automatically generate:

```json
"_gridTemplateColumns:tablet_portrait": "...",
"_gridTemplateColumns:mobile_portrait": "..."
```

for every grid.

## Example 6 — Card container query

If a card changes layout based on its own width, use verified expanded `?card-container` behavior.

Inside the container query, prefer changing card variables:

```css
.service-card {
  /* expanded card-container behavior establishes the query context */

  /* in the resolved query */
  --card-heading-size: var(--h2);
  --card-media-aspect-ratio: 4 / 3;
}
```

Do not use a page-wide viewport breakpoint for a component-width problem.

## Example 7 — WS Forms Pro

Do not create a second form theme in Bricks.

Configure:
- ACSS Forms
- WS Form Styler
- field/label/error/focus styling in ACSS

Then place the WS Form in Bricks.

Use `.form--light` or `.form--dark` only for explicit local scheme overrides.

## Example 8 — Reusable custom overlay

If multiple hero/media sections use the same gradient scrim:

1. configure a named ACSS Custom Overlay slot;
2. apply the generated overlay class to each component;
3. use local overlay variables only for instance-specific changes.

Do not duplicate the full `::before` gradient/positioning CSS on every hero.

## Example 9 — Shadows

For recurring elevation:

```css
.modal {
  box-shadow: var(--box-shadow-modal);
}
```

is appropriate only if the target ACSS settings actually define the semantic `modal` shadow name.

Otherwise use the verified configured slot name/number.

Do not invent shadow variable names.

## Example 10 — Accessible clickable card

Use a real internal link.

Resolve current:
- `?clickable-parent`
- `?focus-parent`

behavior into runtime CSS.

Do not leave Recipe triggers in final JSON.

Do not wrap a complex card in a giant anchor solely to make it clickable when the accessible parent pattern is appropriate.

## Example 11 — Icon Framework

When an icon should receive ACSS Card/Icon Framework styling, attach `data-icon` using the verified Bricks attribute shape.

Do not manually repeat size/color/box styling across every icon.

## Example 12 — Divider Recipe

For repeated separators between direct children, resolve `?divider-all`.

Do not keep an existing flex/grid `gap` without checking how the Recipe manages spacing.

## Example 13 — Unique one-off CSS

A unique structural value is allowed.

```css
.hero-art {
  aspect-ratio: 4 / 3;
  object-fit: cover;
}
```

Do not manufacture an ACSS token just to avoid a literal structural value.

## Example 14 — Local component variable

A component-local property is acceptable when ACSS has no global role for it.

```css
.logo-cloud {
  --logo-max-height: 2.5rem;
}

.logo-cloud img {
  max-height: var(--logo-max-height);
}
```

Do not promote this to a global design system unless it genuinely becomes a site-wide reusable primitive.

## Example 15 — Recipes vs Mixins

Bricks BEM CSS:
- use verified expanded Recipe behavior;
- final output is ordinary CSS.

ACSS Custom SCSS:
- Recipes may expand there;
- mixins/functions may be used there.

Never put:

```scss
@include btn(primary);
```

inside Bricks `_cssCustom`.

## Final Pattern

The strongest ACSS output usually has:

- native ACSS settings owning the design system;
- semantic Bricks/BEM classes owning component identity;
- ACSS behavioral classes/attributes activating framework behavior;
- Recipe expansions handling on-demand patterns;
- very little custom CSS;
- almost no repeated raw design values.
