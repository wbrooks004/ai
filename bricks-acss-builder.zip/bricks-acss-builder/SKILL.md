---
name: bricks-acss-builder
description: Translate brand systems, design systems, mockups, screenshots, Figma/reference designs, and project requirements into complete Automatic.css 4.x settings and maintainable Bricks Builder sections, pages, templates, and components. Use for design-to-Bricks builds, mockup-to-Bricks conversion, complete ACSS configuration, ACSS-first styling, Bricks JSON generation/repair, WS Forms Pro integration, schema validation, import reconciliation, and audits where global styling must remain controllable from the ACSS dashboard.
---

# Bricks + Automatic.css Builder

## Mission

Translate project design evidence into a complete Automatic.css design system, then construct Bricks sections, pages, templates, and components that consume that system.

Automatic.css is the primary design-system authority. Reusable visual decisions should be editable from the ACSS dashboard and propagate through Bricks instead of being duplicated as element-level values.

Match supplied mockups and reference designs closely, but normalize repeated visual decisions into the project design system instead of reproducing accidental pixel differences as unrelated literals.

Do not create a parallel project-wide token/component styling system when ACSS can reasonably own the decision.

## Authority

Use this order when sources conflict:

1. explicit current user requirements;
2. supplied project/design-system requirements;
3. supplied current project ACSS export/configuration;
4. supplied current Bricks/project export/configuration;
5. current official Bricks schema library for generic Bricks data semantics;
6. current `SKILL.md`;
7. specialized bundled references;
8. current official ACSS documentation;
9. current official Bricks documentation outside the schema library;
10. generic best practice.

A current project ACSS export proves current state, but it is not immutable when the task is to redesign or configure ACSS. The requested target design may require enabling, disabling, or reconfiguring ACSS subsystems.

Example exports, fixtures, patterns, and exports from other sites demonstrate structure only. Never let their enabled/disabled states or brand values constrain a different project.

Project evidence overrides generic defaults for project-specific state. Official Bricks schema controls generic Bricks JSON structure; it does not override supplied project-specific custom elements or state.

Report material contradictions. Do not silently merge incompatible evidence.

## Required Reference Routing

Load only what the current stage needs.

For any design/brand/mockup-driven build:
- read `references/design-system-to-acss.md`;
- read `references/acss-subsystem-decision-map.md`.

For any Bricks JSON generation or structural validation:
- read `references/bricks-schema-library.md`;
- read `references/json-formats.md` for clipboard/template/postmeta format;
- read the topic reference for the feature being generated.

For Bricks import/export, reusable classes, components, or dependencies:
- read `references/bricks-import-reconciliation.md`;
- read `references/components-classes.md`.

Read `references/acss-settings-workflow.md` whenever ACSS settings will be inspected, changed, generated, or validated.

Read `references/acss-4x.md` when selecting/verifying ACSS tokens, framework behavior, or version-sensitive semantics.

For exact ACSS tokens/classes/Recipes:
1. search `references/automatic-css/indexes/token-index.csv`;
2. read the topic file named by the matching row;
3. verify the mechanism exists in the applicable ACSS version;
4. ensure the required subsystem is enabled/configured in the target ACSS settings.

Do not reject a suitable ACSS mechanism merely because it is disabled in the source export when the requested target design should enable it.

Use specialized references directly:
- Recipes → `references/acss-recipes-4x.md`
- Cards/buttons/forms/icons → `references/acss-component-frameworks.md`
- Backgrounds/surfaces/overlays → `references/acss-background-system.md`
- Responsive/layout → `references/acss-layout-decision-tree.md`
- Effects/accessibility → `references/acss-effects-accessibility.md`
- SCSS/mixins/functions → `references/acss-mixins-functions-policy.md`
- ACSS JSON policy → `references/acss-json-policy.md`
- Version questions → `references/version-compatibility.md`

## Phase 0 — Establish Evidence and Baseline

Identify the available project evidence:

- brand guide or design-system documentation;
- design tokens;
- Figma/reference design;
- screenshots/mockups;
- current ACSS settings export;
- compatible complete ACSS baseline/example export;
- current Bricks/project export;
- existing global classes/components;
- explicit page/template requirements.

For an existing site, start from the complete current ACSS export when supplied.

For a new site without a current export, use a complete compatible ACSS baseline/export only as a structural settings template. Replace its brand/design values and change subsystem states as required by the new project. Never inherit another site's design identity or disabled-feature assumptions by accident.

Inspect supplied Bricks/project exports before introducing version-sensitive structures, custom element names, global classes, components, variables, pseudo-classes, or theme-state assumptions.

If project evidence is unavailable, distinguish generic-valid behavior from project-verified behavior.

## Phase 1 — Derive the Project Design System

Before styling Bricks, convert the supplied design evidence into reusable design decisions.

Identify, when applicable:

- brand and semantic color roles;
- foreground/background relationships;
- body and heading typography;
- type scale and text roles;
- spacing rhythm and section rhythm;
- content widths and gutters;
- grids, columns, and layout behavior;
- radii, borders, dividers, and shadows;
- buttons and interaction states;
- forms;
- cards;
- icons;
- surfaces and overlays;
- motion/easing;
- responsive behavior;
- recurring component variants.

Treat a repeated visual pattern as a design-system candidate even when the mockup does not label it as a token.

Do not convert every measured mockup value into a separate literal. Normalize visually equivalent values into a coherent reusable system unless the difference is clearly intentional.

Use `references/design-system-to-acss.md` for mapping and fidelity rules.

## Phase 2 — Configure ACSS Completely

For a new styled build or major redesign:

1. parse the complete source/baseline ACSS settings object;
2. map the derived design system to native ACSS subsystems;
3. enable and configure every relevant ACSS subsystem needed by the design;
4. populate the design-facing ACSS settings rather than leaving unrelated defaults in control;
5. preserve unrelated technical/project settings;
6. create the complete target ACSS settings JSON;
7. validate source/baseline versus target;
8. generate styled Bricks only against the target.

The source export is a starting point. If an appropriate ACSS subsystem is off but the target design needs it, enable and configure it in the target instead of bypassing ACSS in Bricks.

Do not return a partial ACSS patch when the requested deliverable is an importable replacement configuration.

## ACSS Ownership Rule

Choose the highest appropriate target-project owner:

1. native ACSS dashboard subsystem;
2. ACSS contextual/runtime behavior;
3. verified ACSS variable;
4. verified Recipe behavior;
5. documented ACSS behavior class/attribute;
6. semantic Bricks global/BEM class whose visual values come from ACSS;
7. component-local CSS using ACSS-controlled values;
8. unique literal value only when the preceding layers do not appropriately own the requirement.

Use ACSS for every styling/layout concern it can reasonably own: colors, typography, spacing, widths, gutters, grids, flex/layout, radii, borders, dividers, shadows, buttons, forms, cards, icons, contextual relationships, transitions/effects, surfaces, overlays, and responsive behavior.

Literal CSS is not automatically wrong. Reject it when it bypasses a reusable ACSS-controlled decision. Accept genuine one-off structural or decorative values when no reusable owner is appropriate.

Project-specific custom properties are allowed when the project genuinely needs a reusable token ACSS cannot model directly. Wire them into ACSS/component architecture and keep them as limited as practical.

## Dashboard Control Rule

For every significant repeated style, ask:

> If the client changes this globally later, where should they change it?

If the correct owner is the ACSS dashboard, Bricks must inherit or reference that ACSS-controlled value rather than duplicate the literal locally.

A generated page can visually match a mockup and still fail this Skill if its reusable design decisions are scattered through Bricks instead of controlled from ACSS.

## Bricks Composition and Class Architecture

Construct the requested sections, pages, templates, and components to match the supplied design and content hierarchy.

Use semantic Bricks elements and the shallowest hierarchy that satisfies layout and behavior.

A semantic global/BEM class identifies a reusable component. ACSS behavior classes may be attached alongside it. Component classes should consume ACSS variables/framework values rather than rebuild the design system.

Avoid duplicating reusable styling as element overrides.

Do not use Bricks Theme Styles to create a competing design system when ACSS owns the same roles.

For components, classes, variables, pseudo-classes, and import behavior, follow `references/components-classes.md` and `references/bricks-import-reconciliation.md`.

## Mockup Fidelity Rule

Match the intentional composition, hierarchy, proportions, alignment, rhythm, component variants, responsive behavior, and visual character of the reference design.

When several visually equivalent instances differ by a few measured pixels, prefer one coherent ACSS token/system value unless evidence shows the difference is intentional.

Preserve genuine local exceptions when they are part of the design, but keep their scope local.

Do not sacrifice ACSS ownership merely to reproduce accidental measurement noise.

## Bricks Schema Rule

Use the current official Bricks schema library whenever it is available.

Validation layers are distinct:

1. JSON parse validity;
2. official Bricks schema-library validity;
3. parent/child tree integrity;
4. global class/component/dependency integrity;
5. supplied project-specific Bricks evidence;
6. ACSS configuration dependencies;
7. ACSS implementation/dashboard-control policy;
8. explicit requirement traceability.

A pass at one layer never overrides failure at another.

When the official schema bundle cannot be retrieved or supplied, continue with project evidence and deterministic generic checks, but mark element-specific/schema-specific conclusions NOT VERIFIABLE rather than inventing keys.

A schema-less validator run is structural-only validation and must never be described as full Bricks schema validation.

## Bricks JSON Rules

Preserve the exact destination format: clipboard, template export, content area, or project-specific structure.

Use flat content arrays when the Bricks format requires them; encode hierarchy through `parent` and `children`.

Maintain reciprocal parent/child references, unique element IDs, valid global-class references, and required dependencies.

Do not invent settings keys from their names. Verify them against the official Bricks schema library or supplied project evidence.

Do not leave raw ACSS Recipe syntax or SCSS-only constructs in runtime Bricks JSON.

## Import Reconciliation

Treat artifact validity and destination reconciliation separately.

Before claiming an artifact is safely importable:
- validate the artifact internally;
- identify referenced global classes, variables, components, pseudo-classes, templates, and other dependencies;
- use current Bricks import behavior to account for conflicts/mapping when relevant;
- report unresolved destination collisions or missing dependencies.

See `references/bricks-import-reconciliation.md`.

## Responsive Strategy

Prefer ACSS fluid, intrinsic, contextual, grid, and container behavior before breakpoint-specific Bricks overrides.

Add explicit breakpoint settings only when the requirement genuinely changes at that breakpoint. Do not generate tablet/mobile boilerplate automatically.

Use `references/acss-layout-decision-tree.md` for implementation choices.

## Pattern Policy

`patterns/acss/` contains active styling examples. Read `patterns/acss/ACSS-REQUIREMENTS.md` before adapting them.

`patterns/legacy/` is structural evidence only. Do not copy its styling architecture into new ACSS work.

Examples never define another project's brand, feature enablement, or target configuration.

## Deterministic Validation

Run applicable validators before delivery:

```bash
python scripts/analyze_acss_settings.py current-acss.json --ws-forms-pro
python scripts/validate_acss_settings.py current-acss.json target-acss.json --strict
python scripts/diff_acss_settings.py current-acss.json target-acss.json
python scripts/validate_acss_bricks.py --strict --acss-settings target-acss.json --bricks-schema-library path/to/bricks-schema.zip output.json
python tests/run_regression_tests.py
```

When network access is available, refresh the Bricks-supplied schema library with:

```bash
python scripts/sync_bricks_schema.py
```

If full Bricks schema evidence is intentionally unavailable, use `--allow-unverified-schema` only for a clearly labeled structural-only check. Never present that result as schema verification.

For custom/project elements absent from the official library, supply explicit project evidence with `--bricks-element-registry`. This extends project evidence; it does not replace official built-in schemas.

Resolve errors. Review warnings. Automated validation does not replace the final quality gate.

## Final Quality Gate

Before delivery verify:

- every explicit user requirement is traceable;
- the target ACSS configuration is complete when required;
- the target reflects the supplied brand/design system rather than unrelated baseline defaults;
- every ACSS subsystem used by Bricks is enabled/configured in the target;
- relevant ACSS systems were enabled rather than bypassed because they were off in the source;
- significant repeated styles have an intentional global owner;
- styles that should be dashboard-controlled actually inherit/reference ACSS;
- mockup fidelity is preserved without unnecessary token fragmentation;
- Bricks JSON uses the official schema library where available;
- hierarchy and dependencies are internally valid;
- import dependencies/conflicts are addressed when relevant;
- active examples did not leak legacy styling;
- no unsupported compatibility claim is made.

If evidence is insufficient, say NOT VERIFIABLE.

## Output Standard

Return the requested complete ACSS target configuration, Bricks section/page/template/component artifact, and concise validation notes as applicable.

Do not claim ACSS, dashboard-control, Bricks-schema, or import compliance beyond the evidence actually validated.
