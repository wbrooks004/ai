# CLAUDE.md

This repository is the complete **Bricks Builder + Automatic.css 4.x** skill.

For every Bricks task, start with `SKILL.md`.

## Non-negotiable architecture

Automatic.css is the design-system authority.

Translate supplied brand systems, design systems, Figma/reference designs, screenshots, and mockups into a complete ACSS target configuration before styling Bricks.

Do not create a project-wide custom color/spacing/type/radius/shadow/button/card system and then feed it into ACSS.

For a new styled build:

1. read the complete current ACSS settings export, or use a compatible complete baseline for a new site;
2. derive reusable design decisions from the design evidence;
3. map them to native ACSS subsystems;
4. enable/configure required ACSS systems even if they were off in the source/baseline;
5. produce the complete target ACSS settings JSON first;
6. validate it;
7. generate Bricks sections/pages/templates/components against that target;
8. validate Bricks structure, ACSS dependencies, and dashboard control.

Example exports never constrain another project's brand or feature enablement.

## Forms

Default form platform: **WS Forms Pro**.

Use the current ACSS 4.x Forms workflow and require WS Form Styler for ACSS form styling. Do not use Bricks native Form examples as the default.

## Styling priority

Prefer, in order:

1. native ACSS dashboard subsystem, enabling/configuring it in the target when appropriate;
2. ACSS contextual/runtime behavior;
3. ACSS standard variable;
4. verified ACSS Recipe behavior;
5. documented ACSS behavior class/attribute;
6. semantic BEM/global class using ACSS;
7. component CSS using ACSS;
8. unique raw value only when ACSS has no suitable owner.

A BEM class identifies the component. An ACSS behavior class may be attached alongside it.

## Important references

- `references/design-system-to-acss.md`
- `references/acss-settings-workflow.md`
- `references/acss-subsystem-decision-map.md`
- `references/acss-4x.md`
- `references/acss-recipes-4x.md`
- `references/acss-component-frameworks.md`
- `references/acss-background-system.md`
- `references/acss-layout-decision-tree.md`
- `references/acss-effects-accessibility.md`
- `references/acss-mixins-functions-policy.md`
- `references/acss-json-policy.md`
- `references/bricks-schema-library.md`
- `references/bricks-import-reconciliation.md`
- `references/version-compatibility.md`

For exact ACSS token/class/Recipe questions, search `references/automatic-css/indexes/token-index.csv` and then read the topic file named by the matching row. For Bricks schema/topic questions, load the specific relevant reference only when needed. Generic bundled documentation does not prove an optional subsystem is enabled in the target project.

## Patterns

- `patterns/acss/` = active styling examples
- `patterns/legacy/` = structure only

Read `patterns/acss/ACSS-REQUIREMENTS.md` before copying an active pattern.

Active patterns intentionally demonstrate:

- Card Framework ownership;
- native ACSS buttons;
- contextual background relationships;
- ACSS section/header rhythm;
- WS Forms Pro placeholders;
- no raw Recipe strings;
- no automatic device-breakpoint boilerplate.

## Recipes vs SCSS

ACSS 4.x Recipes use `?` and expand at authoring time.

Final Bricks JSON must contain runtime-valid CSS—not raw Recipe triggers.

ACSS mixins/functions belong in ACSS Custom SCSS, not Bricks `_cssCustom`.

## Validation

Run:

```bash
python scripts/validate_acss_bricks.py --strict .
```

For a project:

```bash
python scripts/analyze_acss_settings.py current-acss.json --ws-forms-pro
python scripts/validate_acss_settings.py current-acss.json target-acss.json --strict
python scripts/diff_acss_settings.py current-acss.json target-acss.json
python scripts/sync_bricks_schema.py
python scripts/validate_acss_bricks.py --strict --acss-settings target-acss.json --bricks-schema-library references/data/bricks-schema.zip output.json
# Add --bricks-element-registry only for project/custom element evidence absent from the official library.
python tests/run_regression_tests.py
```

Resolve errors. Review every warning. The regression suite must also pass before packaging a skill update.

## Version discipline

Use the current official Bricks schema library as generic Bricks JSON authority. Do not use a historical hand-maintained element allowlist. Supplied project exports/configuration remain authoritative for project-specific custom data and state.

If the official library or required project evidence is unavailable, mark affected schema claims NOT VERIFIABLE rather than inventing keys.

## Updating the skill

When delivering an update, package and return the entire skill as a complete replacement archive. Never distribute only changed fragments.
