#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from acss_common import (
    DESIGN_TOKEN_NAME_RE,
    PALETTE_ROLES,
    extract_custom_properties,
    load_json_object,
    option_on,
)


@dataclass
class Issue:
    severity: str
    location: str
    message: str

    def render(self) -> str:
        where = f" [{self.location}]" if self.location else ""
        return f"{self.severity}{where}: {self.message}"


def validate(base: dict[str, Any], target: dict[str, Any], allow_key_changes: bool) -> list[Issue]:
    issues: list[Issue] = []

    base_keys = set(base)
    target_keys = set(target)

    missing = sorted(base_keys - target_keys)
    extra = sorted(target_keys - base_keys)

    if missing and not allow_key_changes:
        for key in missing:
            issues.append(
                Issue(
                    "ERROR",
                    key,
                    "Target settings omit a key from the complete source export.",
                )
            )
    elif missing:
        for key in missing:
            issues.append(
                Issue("WARN", key, "Target settings omit a source key.")
            )

    if extra and not allow_key_changes:
        for key in extra:
            issues.append(
                Issue(
                    "WARN",
                    key,
                    "Target settings add a key not present in the source export; verify version/schema.",
                )
            )

    base_css = base.get("custom-global-css", "") or ""
    target_css = target.get("custom-global-css", "") or ""

    base_props = extract_custom_properties(base_css)
    target_props = extract_custom_properties(target_css)
    new_props = sorted(target_props - base_props)

    for prop in new_props:
        if DESIGN_TOKEN_NAME_RE.fullmatch(prop):
            issues.append(
                Issue(
                    "WARN",
                    "custom-global-css",
                    f"New global design-like custom property {prop!r}; verify ACSS cannot own this value natively.",
                )
            )

    # Flag likely new global token scales even if regex is embedded in a longer name.
    for prop in new_props:
        if DESIGN_TOKEN_NAME_RE.search(prop) and not any(
            issue.location == "custom-global-css" and prop in issue.message
            for issue in issues
        ):
            issues.append(
                Issue(
                    "WARN",
                    "custom-global-css",
                    f"New global custom property {prop!r} looks design-system-related; justify it.",
                )
            )

    for role in PALETTE_ROLES:
        color_enabled = option_on(target.get(f"option-{role}-clr"))
        button_enabled = option_on(target.get(f"option-{role}-btn"))
        if button_enabled and not color_enabled:
            issues.append(
                Issue(
                    "WARN",
                    f"option-{role}-btn",
                    f"{role} button group is enabled while {role} palette role is disabled.",
                )
            )

    if option_on(target.get("option-forms")):
        if not option_on(target.get("option-style-forms-automatically")):
            issues.append(
                Issue(
                    "WARN",
                    "option-style-forms-automatically",
                    "ACSS Forms are enabled but automatic form styling is disabled.",
                )
            )

    if not option_on(target.get("option-focus-styles")):
        issues.append(
            Issue(
                "WARN",
                "option-focus-styles",
                "ACSS focus styling is disabled; verify an accessible alternative.",
            )
        )

    effect_prefixes = (
        "option-enter-",
        "option-exit-",
        "option-visible-",
        "option-hover-",
    )
    effects_enabled = any(
        option_on(value)
        for key, value in target.items()
        if key.startswith(effect_prefixes)
    )
    if effects_enabled and not option_on(target.get("option-reduce-motion")):
        issues.append(
            Issue(
                "ERROR",
                "option-reduce-motion",
                "Motion/effects are enabled while ACSS Reduce Motion is disabled.",
            )
        )

    # Detect new raw Recipe triggers in settings text. An imported JSON file will
    # not receive a user typing event to expand these.
    recipe_re = re.compile(r"(?<![\w-])\?[a-z][a-z0-9-]*", re.I)
    legacy_recipe_re = re.compile(r"(?<![\w-])@(btn|flex-grid|divider-[a-z-]+|grid-[a-z0-9-]+)\b", re.I)

    for key, value in target.items():
        if not isinstance(value, str):
            continue
        if recipe_re.search(value):
            issues.append(
                Issue(
                    "ERROR",
                    key,
                    "Raw ACSS Recipe trigger found in settings JSON; expand it before import.",
                )
            )
        if legacy_recipe_re.search(value):
            issues.append(
                Issue(
                    "ERROR",
                    key,
                    "Legacy ACSS 3.x Recipe syntax found in target settings.",
                )
            )

    return issues


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate a complete target ACSS settings JSON against its source export."
    )
    parser.add_argument("source", help="Complete current/source ACSS settings JSON.")
    parser.add_argument("target", help="Complete target ACSS settings JSON.")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as failure.",
    )
    parser.add_argument(
        "--allow-key-changes",
        action="store_true",
        help="Allow missing/extra keys for an intentional version migration.",
    )
    args = parser.parse_args()

    try:
        source = load_json_object(args.source)
        target = load_json_object(args.target)
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 1

    issues = validate(source, target, args.allow_key_changes)

    errors = [i for i in issues if i.severity == "ERROR"]
    warnings = [i for i in issues if i.severity == "WARN"]

    for issue in issues:
        print(issue.render())

    print(
        f"\nACSS settings validation: {len(errors)} error(s), "
        f"{len(warnings)} warning(s)."
    )

    if errors:
        return 1
    if args.strict and warnings:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
