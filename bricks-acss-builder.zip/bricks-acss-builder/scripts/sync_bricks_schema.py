#!/usr/bin/env python3
"""Download the official Bricks schema bundle used by the validators."""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, urllib.request

URL = "https://academy.bricksbuilder.io/downloads/bricks-schema.zip"

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=URL)
    parser.add_argument("--output", default=None)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    out = Path(args.output) if args.output else root / "references" / "data" / "bricks-schema.zip"
    out.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(args.url, timeout=60) as response:
        data = response.read()
    if not data.startswith(b"PK"):
        raise SystemExit("Downloaded file is not a ZIP archive.")
    out.write_bytes(data)
    print(f"Saved {out} ({len(data)} bytes)")
    print("sha256:", hashlib.sha256(data).hexdigest())
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
