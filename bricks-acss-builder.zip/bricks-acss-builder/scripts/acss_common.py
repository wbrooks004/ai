#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

VAR_REF_RE = re.compile(r"var\(\s*(--[A-Za-z0-9_-]+)")
VAR_DECL_RE = re.compile(r"(?m)(--[A-Za-z0-9_-]+)\s*:")

PALETTE_ROLES = (
    "primary",
    "secondary",
    "tertiary",
    "accent",
    "base",
    "neutral",
    "success",
    "warning",
    "info",
    "danger",
)

DESIGN_TOKEN_NAME_RE = re.compile(
    r"--[A-Za-z0-9_-]*(?:"
    r"space|spacing|gap|gutter|section|"
    r"font|text|heading|type|"
    r"color|colour|primary|secondary|accent|neutral|base|"
    r"radius|border|shadow|"
    r"width|container|content|grid|"
    r"button|btn|card|surface|overlay"
    r")[A-Za-z0-9_-]*",
    re.I,
)


def load_json_object(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a top-level JSON object.")
    return data


def option_on(value: Any) -> bool:
    if value is True:
        return True
    if value is False or value is None:
        return False
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"on", "true", "1", "yes", "enabled"}
    return False


def extract_custom_properties(css: str) -> set[str]:
    if not isinstance(css, str):
        return set()
    return set(VAR_DECL_RE.findall(css))


def extract_var_references(value: Any) -> set[str]:
    refs: set[str] = set()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for item in node.values():
                walk(item)
        elif isinstance(node, list):
            for item in node:
                walk(item)
        elif isinstance(node, str):
            refs.update(VAR_REF_RE.findall(node))

    walk(value)
    return refs


def category_for_key(key: str) -> str:
    k = key.lower()

    if k.startswith(("color-", "primary-", "secondary-", "tertiary-", "accent-", "base-", "neutral-", "success-", "warning-", "info-", "danger-")):
        return "Palette / Color"
    if k.startswith(("bg-", "body-", "selection-", "website-color-scheme", "auto-color-scheme")):
        return "Color Assignments / Scheme"
    if k.startswith(("h1-", "h2-", "h3-", "h4-", "h5-", "h6-", "heading-", "text-", "base-text", "base-heading", "font-")):
        return "Typography"
    if any(part in k for part in ("space", "gutter", "paragraph-spacing", "flow-spacing")):
        return "Spacing / Sections"
    if k.startswith(("vp-", "content-", "body-max-width", "header-height", "scroll-margin", "sticky-offset")):
        return "Dimensions / Layout"
    if k.startswith(("btn-", "option-buttons", "option-primary-btn", "option-secondary-btn", "option-tertiary-btn", "option-accent-btn", "option-base-btn", "option-neutral-btn", "option-success-btn", "option-warning-btn", "option-info-btn", "option-danger-btn")):
        return "Buttons"
    if k.startswith(("card-", "option-cards", "primary-card")):
        return "Cards"
    if k.startswith(("f-", "option-forms", "option-style-forms", "option-load-form")):
        return "Forms"
    if k.startswith(("icon-", "option-icons")):
        return "Icons"
    if k.startswith(("border-", "divider-", "radius-", "option-border", "option-divider", "option-radius")):
        return "Borders / Dividers"
    if k.startswith(("box-shadow-", "drop-shadow-", "text-shadow-", "option-box-shadow", "option-drop-shadow", "option-text-shadow")):
        return "Shadows"
    if k.startswith(("surface-", "overlay-", "basic-overlay", "custom-overlay", "option-basic-overlays")):
        return "Surfaces / Overlays"
    if k.startswith(("ease-", "transition-", "hover-", "enter-", "exit-", "visible-", "scroll-animation", "option-hover", "option-enter", "option-exit", "option-visible", "option-easing", "option-reduce-motion", "focus-")):
        return "Effects / Accessibility"
    if "grid" in k or "column" in k or k.startswith("option-width"):
        return "Grid / Flex / Width"
    if k.startswith("option-"):
        return "Feature Options"
    if k in {"custom-global-css", "custom-scss", "custom-css"}:
        return "Custom CSS / SCSS"
    return "Other / Technical"
