#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    from acss_common import PALETTE_ROLES, extract_custom_properties, load_json_object, option_on
except ImportError:
    PALETTE_ROLES = (
        "primary", "secondary", "tertiary", "accent", "base",
        "neutral", "success", "warning", "info", "danger",
    )

    def option_on(value: Any) -> bool:
        if value is True:
            return True
        if isinstance(value, str):
            return value.strip().lower() in {"on", "true", "1", "yes", "enabled"}
        return bool(value)

    def load_json_object(path: str | Path) -> dict[str, Any]:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Expected top-level JSON object.")
        return data

    def extract_custom_properties(css: str) -> set[str]:
        return set(re.findall(r"(?m)(--[A-Za-z0-9_-]+)\s*:", css or ""))


COLOR_RE = re.compile(
    r"(?i)"
    r"(?<![\w-])#(?:[0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})(?![\w-])"
    r"|"
    r"\b(?:rgb|rgba|hsl|hsla|oklch|lab|lch)\s*\("
)

DIMENSION_RE = re.compile(
    r"(?i)(?<![\w.-])-?\d*\.?\d+(?:px|rem|em|vw|vh|vmin|vmax|ch|ex)\b"
)

RAW_RECIPE_RE = re.compile(r"(?<![\w-])\?[a-z][a-z0-9-]*", re.I)

LEGACY_RECIPE_RE = re.compile(
    r"(?<![\w-])@(?:"
    r"btn|flex-[a-z0-9-]+|grid-[a-z0-9-]+|divider-[a-z0-9-]+|"
    r"columns|content-grid|clickable-parent|focus-parent|card-container|"
    r"concentric-radius|fade-[a-z0-9-]+"
    r")\b",
    re.I,
)

SCSS_INCLUDE_RE = re.compile(r"@include\s+[A-Za-z0-9_-]+\s*(?:\(|;)", re.I)
SCSS_VARIABLE_RE = re.compile(r"(?m)^\s*\$[A-Za-z0-9_-]+\s*:")
SCSS_FLUID_RE = re.compile(r"(?<![-\w])fluid\s*\(", re.I)

REFERENCE_RE = re.compile(
    r"(?<!https://)(references/[A-Za-z0-9_./-]+\.(?:md|txt|json))"
)

TOKEN_SENSITIVE_KEY_PARTS = (
    "margin",
    "padding",
    "gap",
    "spacing",
    "font",
    "radius",
    "border",
    "width",
    "height",
    "size",
    "color",
    "background",
    "shadow",
)

RESPONSIVE_KEY_PARTS = (
    "tablet_portrait",
    "mobile_portrait",
    "tabletportrait",
    "mobileportrait",
)

VAR_REF_RE = re.compile(r"var\(\s*(--[A-Za-z0-9_-]+)", re.I)
ROOT_VAR_DECL_RE = re.compile(r":root\s*\{[^}]*--[A-Za-z0-9_-]+\s*:", re.I | re.S)


@dataclass
class Issue:
    severity: str
    file: Path
    location: str
    message: str

    def render(self, root: Path) -> str:
        try:
            rel = self.file.relative_to(root)
        except ValueError:
            rel = self.file

        suffix = f" [{self.location}]" if self.location else ""
        return f"{self.severity}: {rel}{suffix}: {self.message}"


@dataclass
class AcssContext:
    settings: dict[str, Any]
    card_selectors: set[str]
    enabled_palette_roles: set[str]
    custom_properties: set[str]
    documented_variables: set[str]


# Optional ACSS subsystems whose variables must be proven enabled by the target
# settings in project-aware validation. Generic documentation is not enough.
OPTIONAL_VARIABLE_SUBSYSTEMS: tuple[tuple[re.Pattern[str], tuple[str, ...], str], ...] = (
    (re.compile(r"^--card-", re.I), ("option-cards",), "Cards"),
    (re.compile(r"^--btn-", re.I), ("option-buttons",), "Buttons"),
    (re.compile(r"^--f-", re.I), ("option-forms",), "Forms"),
    (re.compile(r"^--icon-", re.I), ("option-icons",), "Icons"),
    (re.compile(r"^--box-shadow-", re.I), ("option-box-shadow-variables",), "Box Shadows"),
    (re.compile(r"^--drop-shadow-", re.I), ("option-drop-shadow-variables",), "Drop Shadows"),
    (re.compile(r"^--text-shadow-", re.I), ("option-text-shadow-variables",), "Text Shadows"),
)


def load_documented_acss_variables(root: Path) -> set[str]:
    """Load variables documented by the bundled ACSS knowledge package.

    These are generic documentation evidence only. In project-aware mode,
    optional subsystem variables still require target-project enablement.
    """
    index = root / "references" / "automatic-css" / "indexes" / "token-index.csv"
    known: set[str] = set()
    if not index.exists():
        return known

    with index.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("type") != "variable":
                continue
            token = (row.get("token") or "").strip()
            # Skip documentation placeholders such as --space-{size}.
            if token.startswith("--") and "{" not in token and "}" not in token:
                known.add(token)
    return known


def variable_subsystem_requirement(var_name: str) -> tuple[tuple[str, ...], str] | None:
    for pattern, option_keys, label in OPTIONAL_VARIABLE_SUBSYSTEMS:
        if pattern.search(var_name):
            return option_keys, label
    return None


def variable_is_project_verified(var_name: str, acss: AcssContext) -> tuple[bool, str | None]:
    if var_name in acss.custom_properties:
        return True, None
    if var_name not in acss.documented_variables:
        return False, None

    requirement = variable_subsystem_requirement(var_name)
    if requirement is None:
        # Core documented variables are treated as ACSS primitives. Optional
        # subsystem variables are handled above and require project evidence.
        return True, None

    option_keys, label = requirement
    if any(option_on(acss.settings.get(key)) for key in option_keys):
        return True, None
    return False, label


def build_acss_context(settings: dict[str, Any], root: Path) -> AcssContext:
    selectors_raw = str(settings.get("card-selectors", "") or "")
    card_selectors = set(re.findall(r"\.([A-Za-z0-9_-]+)", selectors_raw))

    enabled_palette_roles = {
        role
        for role in PALETTE_ROLES
        if option_on(settings.get(f"option-{role}-clr"))
    }

    custom_properties = extract_custom_properties(
        str(settings.get("custom-global-css", "") or "")
    )

    documented_variables = load_documented_acss_variables(root)

    return AcssContext(
        settings=settings,
        card_selectors=card_selectors,
        enabled_palette_roles=enabled_palette_roles,
        custom_properties=custom_properties,
        documented_variables=documented_variables,
    )


@dataclass
class BricksSchemaLibrary:
    """Resolved Bricks element schemas keyed by metadata.name."""

    elements: dict[str, dict[str, Any]]
    source: str

    @property
    def names(self) -> set[str]:
        return set(self.elements)


def load_bricks_element_registry_file(path: Path) -> set[str]:
    """Load project/custom element evidence only.

    This registry is not a replacement for the official Bricks schema library.
    """
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        values = data.get("elements", [])
    elif isinstance(data, list):
        values = data
    else:
        raise ValueError(f"{path} must be a JSON list or an object with an 'elements' list.")
    if not isinstance(values, list):
        raise ValueError(f"{path} 'elements' must be a list.")
    return {str(v) for v in values if isinstance(v, str) and v}


def _maybe_add_bricks_schema(
    schemas: dict[str, dict[str, Any]], data: Any
) -> None:
    if not isinstance(data, dict):
        return
    metadata = data.get("metadata")
    if not isinstance(metadata, dict):
        return
    name = metadata.get("name")
    settings = data.get("settings")
    if isinstance(name, str) and name and isinstance(settings, dict):
        schemas[name] = data


def load_bricks_schema_library(path: str | Path | None) -> BricksSchemaLibrary | None:
    """Load the official Bricks schema zip or extracted directory.

    The Bricks bundle contains resolved element schemas with metadata.name and
    a settings map whose entries expose valueSchema.
    """
    if not path:
        return None
    source = Path(path)
    schemas: dict[str, dict[str, Any]] = {}

    if source.is_dir():
        for child in source.rglob("*.json"):
            try:
                _maybe_add_bricks_schema(
                    schemas, json.loads(child.read_text(encoding="utf-8"))
                )
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
    elif source.is_file() and source.suffix.lower() == ".zip":
        with zipfile.ZipFile(source) as archive:
            for name in archive.namelist():
                if not name.lower().endswith(".json"):
                    continue
                try:
                    with archive.open(name) as handle:
                        data = json.loads(handle.read().decode("utf-8"))
                    _maybe_add_bricks_schema(schemas, data)
                except (KeyError, json.JSONDecodeError, UnicodeDecodeError):
                    continue
    else:
        raise ValueError(
            f"{source} must be an extracted Bricks schema directory or bricks-schema.zip."
        )

    if not schemas:
        raise ValueError(
            f"{source} did not contain resolved Bricks element schemas with metadata.name/settings."
        )
    return BricksSchemaLibrary(elements=schemas, source=str(source))


def _setting_base_key(key: str) -> str:
    # Bricks responsive/state suffixes use colon syntax.
    return key.split(":", 1)[0]


BRICKS_META_SETTING_KEYS = {
    "_cssGlobalClasses",
    "_conditions",
    "_interactions",
    "_hideElementBuilder",
    "_hideElementFrontend",
    "_attributes",
}


def validate_value_against_schema(
    value: Any, schema: dict[str, Any]
) -> str | None:
    """Return a compact error string for valueSchema failures when possible."""
    try:
        import jsonschema
    except ImportError:
        return None
    try:
        jsonschema.Draft202012Validator(schema).validate(value)
    except Exception as exc:
        message = getattr(exc, "message", str(exc))
        return str(message)
    return None


def validate_element_against_bricks_schema(
    element: dict[str, Any],
    schema_library: BricksSchemaLibrary | None,
    project_elements: set[str],
    path: Path,
) -> list[Issue]:
    issues: list[Issue] = []
    eid = str(element.get("id", "<missing>"))
    name = element.get("name")

    # Generic envelope checks documented by Bricks' common element schema.
    required = ("id", "name", "parent", "children", "settings")
    for key in required:
        if key not in element:
            issues.append(
                Issue("ERROR", path, f"element:{eid}", f"Missing required Bricks field {key!r}.")
            )
    allowed_top = {
        "id", "name", "parent", "children", "settings",
        "selectors", "label", "themeStyles", "cid", "instanceId", "global",
    }
    # Component/legacy fields are tolerated here and validated by project/topic
    # references; the official common envelope remains the baseline.
    unexpected = sorted(k for k in element if k not in allowed_top)
    for key in unexpected:
        issues.append(
            Issue(
                "WARN",
                path,
                f"element:{eid}.{key}",
                "Top-level field is not in the common Bricks element envelope; verify with official schema/project evidence.",
            )
        )

    if isinstance(element.get("id"), str) and not re.fullmatch(r"[a-z0-9]{6}", element["id"]):
        issues.append(
            Issue(
                "ERROR",
                path,
                f"element:{eid}.id",
                "Bricks element id must be a 6-character lowercase alphanumeric string.",
            )
        )
    if not isinstance(element.get("children"), list):
        issues.append(Issue("ERROR", path, f"element:{eid}.children", "children must be a list."))
    if not isinstance(element.get("settings"), dict):
        issues.append(Issue("ERROR", path, f"element:{eid}.settings", "settings must be an object."))

    if not isinstance(name, str) or not name:
        return issues

    if schema_library is None:
        # Project evidence can prove custom names, but element-specific built-in
        # settings remain unverified without the official library.
        return issues

    schema = schema_library.elements.get(name)
    if schema is None:
        if name not in project_elements:
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    f"element:{eid}.name",
                    f"Unknown Bricks element name {name!r}; absent from the supplied official Bricks schema library and project/custom evidence.",
                )
            )
        return issues

    settings = element.get("settings")
    if not isinstance(settings, dict):
        return issues
    allowed_settings = schema.get("settings", {})
    if not isinstance(allowed_settings, dict):
        return issues

    for key, value in settings.items():
        base = _setting_base_key(str(key))
        if base in BRICKS_META_SETTING_KEYS:
            continue
        setting_schema = allowed_settings.get(base)
        if not isinstance(setting_schema, dict):
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    f"element:{eid}.settings.{key}",
                    f"Setting {key!r} is not defined for Bricks element {name!r} in the supplied official schema library.",
                )
            )
            continue
        value_schema = setting_schema.get("valueSchema")
        if isinstance(value_schema, dict):
            error = validate_value_against_schema(value, value_schema)
            if error:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}.settings.{key}",
                        f"Value does not satisfy Bricks schema: {error}",
                    )
                )
    return issues


def extract_declared_properties(node: Any) -> set[str]:
    declared: set[str] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for item in value.values():
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str):
            declared.update(re.findall(r"(?m)(--[A-Za-z0-9_-]+)\s*:", value))

    walk(node)
    return declared


def extract_variable_references(node: Any) -> set[str]:
    refs: set[str] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for item in value.values():
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str):
            refs.update(VAR_REF_RE.findall(value))

    walk(node)
    return refs


def is_legacy(path: Path) -> bool:
    parts = {part.lower() for part in path.parts}
    return "legacy" in parts and "patterns" in parts


def iter_files(paths: Iterable[Path]) -> Iterable[Path]:
    seen: set[Path] = set()

    for path in paths:
        if path.is_file():
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                yield resolved
            continue

        if not path.exists():
            continue

        for child in path.rglob("*"):
            if not child.is_file():
                continue

            if any(
                part in {".git", "__pycache__", "node_modules", ".venv", "venv", "tests"}
                for part in child.parts
            ):
                continue

            if child.suffix.lower() not in {".md", ".txt", ".json"}:
                continue

            resolved = child.resolve()
            if resolved not in seen:
                seen.add(resolved)
                yield resolved


def check_skill_md(path: Path, root: Path) -> list[Issue]:
    issues: list[Issue] = []

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return [Issue("ERROR", path, "", "SKILL.md is not valid UTF-8.")]

    if not text.startswith("---\n") and not text.startswith("---\r\n"):
        return [
            Issue(
                "ERROR",
                path,
                "line 1",
                "SKILL.md must begin with YAML frontmatter on line 1.",
            )
        ]

    match = re.match(r"^---\s*\r?\n(.*?)\r?\n---\s*\r?\n", text, re.S)
    if not match:
        return [
            Issue(
                "ERROR",
                path,
                "frontmatter",
                "Could not find a complete YAML frontmatter block.",
            )
        ]

    frontmatter = match.group(1)

    name_match = re.search(r"(?m)^name:\s*(.+?)\s*$", frontmatter)
    desc_match = re.search(r"(?m)^description:\s*(.+?)\s*$", frontmatter)

    if not name_match:
        issues.append(Issue("ERROR", path, "frontmatter", "Missing required 'name'."))
    else:
        name = name_match.group(1).strip().strip("'\"")
        if not re.fullmatch(r"[a-z0-9-]{1,64}", name):
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    "frontmatter.name",
                    "Name must be lowercase letters, numbers, or hyphens.",
                )
            )
        if root.name.lower().replace("_", "-") != name.lower().replace("_", "-"):
            issues.append(
                Issue(
                    "WARN",
                    path,
                    "frontmatter.name",
                    f"Skill directory '{root.name}' does not match name '{name}'.",
                )
            )

    if not desc_match:
        issues.append(
            Issue("ERROR", path, "frontmatter", "Missing required 'description'.")
        )
    else:
        description = desc_match.group(1).strip().strip("'\"")
        if not description:
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    "frontmatter.description",
                    "Description must not be empty.",
                )
            )
        if len(description) > 1024:
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    "frontmatter.description",
                    "Description exceeds 1024 characters.",
                )
            )

    if len(text.splitlines()) > 500:
        issues.append(
            Issue(
                "WARN",
                path,
                "",
                f"SKILL.md is {len(text.splitlines())} lines; keep it under 500.",
            )
        )

    return issues


def check_markdown_references(path: Path, root: Path) -> list[Issue]:
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return []

    issues: list[Issue] = []
    for ref in sorted(set(REFERENCE_RE.findall(text))):
        candidate = root / ref
        if not candidate.exists():
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    ref,
                    f"Referenced file does not exist: {ref}",
                )
            )
    return issues


def token_sensitive_key(key: str) -> bool:
    lowered = key.lower()
    return any(part in lowered for part in TOKEN_SENSITIVE_KEY_PARTS)


def check_string(
    value: str,
    path: Path,
    trail: tuple[str, ...],
    legacy: bool,
) -> list[Issue]:
    if legacy:
        return []

    issues: list[Issue] = []
    location = ".".join(trail)
    key = trail[-1] if trail else ""

    if COLOR_RE.search(value):
        issues.append(
            Issue(
                "ERROR",
                path,
                location,
                f"Literal design color found: {value!r}",
            )
        )

    if RAW_RECIPE_RE.search(value):
        issues.append(
            Issue(
                "ERROR",
                path,
                location,
                "Raw ACSS 4.x Recipe trigger found inside final JSON.",
            )
        )

    if LEGACY_RECIPE_RE.search(value):
        issues.append(
            Issue(
                "ERROR",
                path,
                location,
                "Legacy ACSS 3.x Recipe syntax found.",
            )
        )

    if SCSS_INCLUDE_RE.search(value) or SCSS_VARIABLE_RE.search(value) or SCSS_FLUID_RE.search(value):
        issues.append(
            Issue(
                "ERROR",
                path,
                location,
                "SCSS-only ACSS construct found in Bricks JSON/CSS; compile it at ACSS Custom SCSS level instead.",
            )
        )

    if ROOT_VAR_DECL_RE.search(value):
        issues.append(
            Issue(
                "WARN",
                path,
                location,
                "Global :root custom property declaration found in Bricks JSON; verify it is not a parallel design system.",
            )
        )

    if token_sensitive_key(key) and DIMENSION_RE.search(value):
        if "var(--" not in value and "calc(var(--" not in value:
            issues.append(
                Issue(
                    "WARN",
                    path,
                    location,
                    f"Literal dimension on token-sensitive property: {value!r}",
                )
            )

    return issues


def walk_json(
    node: Any,
    path: Path,
    trail: tuple[str, ...] = (),
    legacy: bool = False,
) -> list[Issue]:
    issues: list[Issue] = []

    if isinstance(node, dict):
        for key, value in node.items():
            key_string = str(key)
            lowered = key_string.lower()

            if not legacy and any(part in lowered for part in RESPONSIVE_KEY_PARTS):
                issues.append(
                    Issue(
                        "WARN",
                        path,
                        ".".join(trail + (key_string,)),
                        "Explicit tablet/mobile override found; verify intrinsic/container-query layout cannot solve it.",
                    )
                )

            issues.extend(
                walk_json(
                    value,
                    path,
                    trail + (key_string,),
                    legacy,
                )
            )

    elif isinstance(node, list):
        for index, value in enumerate(node):
            issues.extend(
                walk_json(
                    value,
                    path,
                    trail + (str(index),),
                    legacy,
                )
            )

    elif isinstance(node, str):
        issues.extend(check_string(node, path, trail, legacy))

    return issues


def element_class_strings(element: dict[str, Any]) -> set[str]:
    settings = element.get("settings")
    if not isinstance(settings, dict):
        return set()

    classes: set[str] = set()

    direct = settings.get("_cssClasses")
    if isinstance(direct, str):
        classes.update(direct.split())

    hidden = settings.get("_hidden")
    if isinstance(hidden, dict):
        value = hidden.get("_cssClasses")
        if isinstance(value, str):
            classes.update(value.split())

    return classes


def check_bricks_structure(
    data: dict[str, Any],
    path: Path,
    acss: AcssContext | None,
    schema_library: BricksSchemaLibrary | None,
    project_elements: set[str],
) -> list[Issue]:
    content = None
    element_container_key = None
    for candidate in ("content", "header", "footer"):
        value = data.get(candidate)
        if isinstance(value, list):
            content = value
            element_container_key = candidate
            break

    if not isinstance(content, list):
        return []

    issues: list[Issue] = []
    elements = [e for e in content if isinstance(e, dict)]

    ids: list[str] = [
        str(e.get("id"))
        for e in elements
        if e.get("id") not in (None, "")
    ]
    id_set = set(ids)

    if len(ids) != len(id_set):
        seen: set[str] = set()
        for eid in ids:
            if eid in seen:
                issues.append(
                    Issue("ERROR", path, f"element:{eid}", "Duplicate element ID.")
                )
            seen.add(eid)

    by_id = {
        str(e.get("id")): e
        for e in elements
        if e.get("id") not in (None, "")
    }

    for eid, element in by_id.items():
        parent = element.get("parent", 0)
        if parent not in (0, "0", None, ""):
            parent_id = str(parent)
            if parent_id not in by_id:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}.parent",
                        f"Parent {parent_id!r} does not exist.",
                    )
                )
            else:
                parent_children = by_id[parent_id].get("children", [])
                if isinstance(parent_children, list) and eid not in {
                    str(x) for x in parent_children
                }:
                    issues.append(
                        Issue(
                            "ERROR",
                            path,
                            f"element:{eid}.parent",
                            f"Parent {parent_id!r} does not list this child.",
                        )
                    )

        children = element.get("children", [])
        if children is None:
            children = []
        if not isinstance(children, list):
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    f"element:{eid}.children",
                    "children must be a list.",
                )
            )
            continue

        for child in children:
            cid = str(child)
            if cid not in by_id:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}.children",
                        f"Child {cid!r} does not exist.",
                    )
                )
                continue

            child_parent = by_id[cid].get("parent", 0)
            if str(child_parent) != eid:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}.children",
                        f"Child {cid!r} points to parent {child_parent!r}, not {eid!r}.",
                    )
                )

    global_classes = data.get("globalClasses")
    global_class_key = "globalClasses"
    if not isinstance(global_classes, list):
        global_classes = data.get("global_classes")
        global_class_key = "global_classes"
    if not isinstance(global_classes, list):
        global_classes = []

    class_ids: list[str] = [
        str(c.get("id"))
        for c in global_classes
        if isinstance(c, dict) and c.get("id") not in (None, "")
    ]
    class_id_set = set(class_ids)

    if len(class_ids) != len(class_id_set):
        issues.append(
            Issue("ERROR", path, global_class_key, "Duplicate global class IDs.")
        )

    names = [
        str(c.get("name"))
        for c in global_classes
        if isinstance(c, dict) and c.get("name")
    ]
    if len(names) != len(set(names)):
        issues.append(
            Issue("WARN", path, global_class_key, "Duplicate global class names.")
        )

    for eid, element in by_id.items():
        settings = element.get("settings")
        if not isinstance(settings, dict):
            continue
        refs = settings.get("_cssGlobalClasses", [])
        if refs is None:
            refs = []
        if not isinstance(refs, list):
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    f"element:{eid}._cssGlobalClasses",
                    "_cssGlobalClasses must be a list of class IDs.",
                )
            )
            continue
        for class_id in refs:
            if str(class_id) not in class_id_set:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}._cssGlobalClasses",
                        f"Referenced global class {class_id!r} is missing.",
                    )
                )

    if acss:
        attached_classes: set[str] = set()
        attached_classes.update(names)
        for element in elements:
            attached_classes.update(element_class_strings(element))

        card_like = {
            name
            for name in attached_classes
            if re.search(r"(?:^card$|[-_]card$|card$|plan$)", name, re.I)
            and "__" not in name
            and not name.startswith("btn--")
        }

        if option_on(acss.settings.get("option-cards")):
            for name in sorted(card_like):
                if name not in acss.card_selectors:
                    issues.append(
                        Issue(
                            "WARN",
                            path,
                            f"class:{name}",
                            "Card-like wrapper is not present in target ACSS card-selectors.",
                        )
                    )

        for cls in sorted(attached_classes):
            m = re.fullmatch(
                r"btn--(primary|secondary|tertiary|accent|base|neutral|success|warning|info|danger)(?:-outline)?",
                cls,
                re.I,
            )
            if m:
                role = m.group(1).lower()
                if role not in acss.enabled_palette_roles:
                    issues.append(
                        Issue(
                            "ERROR",
                            path,
                            f"class:{cls}",
                            f"Button uses disabled ACSS palette role {role!r}.",
                        )
                    )

    # Validate generic/element-specific Bricks structure against the official
    # schema library, with project/custom element evidence as an extension.
    for element in elements:
        issues.extend(
            validate_element_against_bricks_schema(
                element, schema_library, project_elements, path
            )
        )

    # A reciprocal graph can still be cyclic. Every element must eventually reach parent 0.
    for eid in by_id:
        seen: set[str] = set()
        current = eid
        while True:
            if current in seen:
                issues.append(
                    Issue(
                        "ERROR",
                        path,
                        f"element:{eid}.parent",
                        f"Cyclic parent chain detected at element {current!r}.",
                    )
                )
                break
            seen.add(current)
            node = by_id.get(current)
            if node is None:
                break
            parent = node.get("parent", 0)
            if parent in (0, "0", None, ""):
                break
            current = str(parent)

    # Project-aware ACSS token verification.
    if acss:
        declared = extract_declared_properties(data)
        for var_name in sorted(extract_variable_references(data)):
            if var_name in declared:
                continue
            verified, disabled_subsystem = variable_is_project_verified(var_name, acss)
            if verified:
                continue
            if disabled_subsystem:
                message = (
                    f"Documented ACSS custom property {var_name!r} belongs to optional subsystem "
                    f"{disabled_subsystem!r}, but the supplied target settings do not prove that subsystem is enabled."
                )
            else:
                message = (
                    f"Unknown/unverified ACSS custom property {var_name!r}; verify it exists in the target project or declare it locally."
                )
            issues.append(
                Issue(
                    "ERROR",
                    path,
                    "ACSS variable references",
                    message,
                )
            )

    return issues


def check_pattern_classification(path: Path, root: Path) -> list[Issue]:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return []

    if path.suffix.lower() != ".json":
        return []

    parts = rel.parts
    if len(parts) == 2 and parts[0] == "patterns":
        return [
            Issue(
                "ERROR",
                path,
                "",
                "JSON pattern is unclassified at patterns/ root; place it under patterns/acss/ or patterns/legacy/.",
            )
        ]
    return []


def check_json(
    path: Path,
    root: Path,
    acss: AcssContext | None,
    schema_library: BricksSchemaLibrary | None,
    project_elements: set[str],
) -> list[Issue]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [
            Issue(
                "ERROR",
                path,
                f"line {exc.lineno}, column {exc.colno}",
                f"Invalid JSON: {exc.msg}",
            )
        ]
    except UnicodeDecodeError:
        return [Issue("ERROR", path, "", "JSON is not valid UTF-8.")]

    legacy = is_legacy(path)
    issues = walk_json(data, path, legacy=legacy)
    issues.extend(check_pattern_classification(path, root))

    if not legacy and isinstance(data, dict):
        issues.extend(check_bricks_structure(data, path, acss, schema_library, project_elements))

    return issues


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate Bricks structure and ACSS-first JSON policy."
    )
    parser.add_argument(
        "paths",
        nargs="*",
        default=["."],
        help="Files or directories to scan.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as a failing result.",
    )
    parser.add_argument(
        "--acss-settings",
        help="Optional complete target ACSS settings JSON for cross-validation.",
    )
    parser.add_argument(
        "--bricks-schema-library",
        help="Official Bricks bricks-schema.zip or extracted schema directory. Uses Bricks-supplied schemas as generic authority.",
    )
    parser.add_argument(
        "--allow-unverified-schema",
        action="store_true",
        help="Allow structural-only validation when the official Bricks schema library is unavailable. Element/schema conclusions remain NOT VERIFIABLE.",
    )
    parser.add_argument(
        "--bricks-element-registry",
        help="Optional JSON list/object containing project/custom Bricks element names as project evidence. Extends, never replaces, the official library.",
    )
    args = parser.parse_args()

    script_path = Path(__file__).resolve()
    root = script_path.parent.parent

    acss = None
    if args.acss_settings:
        try:
            acss = build_acss_context(load_json_object(args.acss_settings), root)
        except Exception as exc:
            print(f"ERROR: could not load --acss-settings: {exc}")
            return 1

    try:
        schema_library = load_bricks_schema_library(args.bricks_schema_library)
    except Exception as exc:
        print(f"ERROR: could not load --bricks-schema-library: {exc}")
        return 1

    schema_notice = None
    if schema_library is None:
        schema_notice = (
            "Official Bricks schema library not supplied. "
            "Element names, element-specific settings, and schema value constraints are NOT VERIFIABLE."
        )

    try:
        project_elements = (
            load_bricks_element_registry_file(Path(args.bricks_element_registry))
            if args.bricks_element_registry else set()
        )
    except Exception as exc:
        print(f"ERROR: could not load --bricks-element-registry: {exc}")
        return 1

    targets = [Path(p).resolve() for p in args.paths]
    files = list(iter_files(targets))

    issues: list[Issue] = []

    if schema_notice:
        if args.allow_unverified_schema:
            print(f"NOTICE: {schema_notice} Running structural-only validation by explicit request.")
        else:
            issues.append(
                Issue(
                    "WARN",
                    root,
                    "Bricks schema",
                    schema_notice + " Supply --bricks-schema-library or explicitly use --allow-unverified-schema for structural-only validation.",
                )
            )

    skill_md = root / "SKILL.md"
    if skill_md.exists():
        issues.extend(check_skill_md(skill_md, root))
    else:
        issues.append(Issue("ERROR", root, "", "Missing root SKILL.md."))

    for path in files:
        if path.suffix.lower() in {".md", ".txt"}:
            issues.extend(check_markdown_references(path, root))

        if path.suffix.lower() == ".json":
            # Avoid treating the settings profile itself as Bricks JSON if it was
            # included among the requested paths.
            if args.acss_settings and path.resolve() == Path(args.acss_settings).resolve():
                continue
            issues.extend(check_json(path, root, acss, schema_library, project_elements))

    errors = [issue for issue in issues if issue.severity == "ERROR"]
    warnings = [issue for issue in issues if issue.severity == "WARN"]

    for issue in issues:
        print(issue.render(root))

    print()
    print(
        f"Validation complete: {len(errors)} error(s), "
        f"{len(warnings)} warning(s)."
    )

    if errors:
        return 1
    if args.strict and warnings:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
