#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from typing import Any

from acss_common import category_for_key, load_json_object


def scalar(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Create a readable diff between complete ACSS settings exports."
    )
    parser.add_argument("source")
    parser.add_argument("target")
    parser.add_argument("--json", action="store_true", help="Print JSON diff.")
    args = parser.parse_args()

    try:
        source = load_json_object(args.source)
        target = load_json_object(args.target)
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 1

    keys = sorted(set(source) | set(target))
    changes = []

    for key in keys:
        before = source.get(key, "__MISSING__")
        after = target.get(key, "__MISSING__")
        if before == after:
            continue
        changes.append({
            "category": category_for_key(key),
            "key": key,
            "before": before,
            "after": after,
        })

    if args.json:
        print(json.dumps(changes, indent=2, ensure_ascii=False))
        return 0

    print("# ACSS Settings Change Report")
    print()
    print(f"Changed settings: {len(changes)}")

    grouped = defaultdict(list)
    for change in changes:
        grouped[change["category"]].append(change)

    for category in sorted(grouped):
        print(f"\n## {category}\n")
        print("| Key | Before | After |")
        print("|---|---|---|")
        for change in grouped[category]:
            before = scalar(change["before"]).replace("|", "\\|").replace("\n", "\\n")
            after = scalar(change["after"]).replace("|", "\\|").replace("\n", "\\n")
            print(f"| `{change['key']}` | `{before}` | `{after}` |")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
