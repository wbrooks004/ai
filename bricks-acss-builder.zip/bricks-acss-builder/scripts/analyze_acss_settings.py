#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from acss_common import (
    PALETTE_ROLES,
    extract_custom_properties,
    extract_var_references,
    load_json_object,
    option_on,
)


def build_profile(data: dict, ws_forms_pro: bool = False) -> dict:
    palette = {}
    for role in PALETTE_ROLES:
        palette[role] = {
            "enabled": option_on(data.get(f"option-{role}-clr")),
            "value": data.get(f"color-{role}"),
            "button_enabled": option_on(data.get(f"option-{role}-btn")),
            "button_outline_enabled": option_on(data.get(f"option-{role}-btn-outline")),
            "button_shades_enabled": option_on(data.get(f"option-{role}-btn-shades")),
        }

    shadows = []
    for i in range(1, 6):
        shadows.append({
            "slot": i,
            "name": data.get(f"box-shadow-{i}-name"),
            "value": data.get(f"box-shadow-{i}-value"),
        })

    drop_shadows = []
    for i in range(1, 6):
        drop_shadows.append({
            "slot": i,
            "name": data.get(f"drop-shadow-{i}-name"),
            "value": data.get(f"drop-shadow-{i}-value"),
        })

    text_shadows = []
    for i in range(1, 6):
        text_shadows.append({
            "slot": i,
            "name": data.get(f"text-shadow-{i}-name"),
            "value": data.get(f"text-shadow-{i}-value"),
        })

    surfaces = []
    for i in range(1, 6):
        surfaces.append({
            "slot": i,
            "name": data.get(f"surface-{i}-name"),
            "background": data.get(f"surface-{i}-bg-color"),
            "relationship": data.get(f"surface-{i}-color-relationship"),
            "asset": data.get(f"surface-{i}-asset"),
        })

    overlays = []
    for i in range(1, 6):
        overlays.append({
            "slot": i,
            "name": data.get(f"overlay-{i}-name"),
            "background": data.get(f"overlay-{i}-background"),
            "background_color": data.get(f"overlay-{i}-bg-color"),
            "type": data.get(f"overlay-{i}-background-type"),
            "opacity": data.get(f"overlay-{i}-opacity"),
        })

    custom_css = data.get("custom-global-css", "") or ""
    custom_props = sorted(extract_custom_properties(custom_css))

    enabled_options = sorted(
        key for key, value in data.items()
        if key.startswith("option-") and option_on(value)
    )

    warnings = []

    for role, info in palette.items():
        if info["button_enabled"] and not info["enabled"]:
            warnings.append(
                f"{role}: button group is enabled while the palette role is disabled."
            )

    if option_on(data.get("option-cards")) and not str(data.get("card-selectors", "") or "").strip():
        warnings.append("Card Framework is enabled but card-selectors is empty.")

    if option_on(data.get("option-forms")) and not option_on(data.get("option-style-forms-automatically")):
        warnings.append("Forms are enabled but automatic form styling is disabled.")

    if not option_on(data.get("option-focus-styles")):
        warnings.append("ACSS focus styles are disabled.")

    effect_prefixes = (
        "option-enter-", "option-exit-", "option-visible-",
        "option-hover-", "option-smooth-scrolling"
    )
    effects_enabled = any(
        option_on(v)
        for k, v in data.items()
        if k.startswith(effect_prefixes)
    )
    if effects_enabled and not option_on(data.get("option-reduce-motion")):
        warnings.append("Effects are enabled while Reduce Motion is disabled.")

    timestamp = data.get("timestamp")
    timestamp_iso = None
    if isinstance(timestamp, (int, float)):
        try:
            timestamp_iso = datetime.fromtimestamp(timestamp, timezone.utc).isoformat()
        except Exception:
            pass

    return {
        "settings_count": len(data),
        "timestamp": timestamp,
        "timestamp_iso_utc": timestamp_iso,
        "form_system": "WS Forms Pro" if ws_forms_pro else "unspecified",
        "palette": palette,
        "typography": {
            "body_family": data.get("text-font-family"),
            "heading_family": data.get("heading-font-family"),
            "body_weight": data.get("text-font-weight"),
            "heading_weight": data.get("heading-weight"),
            "base_text_desktop": data.get("base-text-desk"),
            "base_text_mobile": data.get("base-text-mob"),
            "heading_scale": data.get("heading-scale"),
            "text_scale": data.get("text-scale"),
        },
        "spacing": {
            "base_space": data.get("base-space"),
            "base_space_min": data.get("base-space-min"),
            "space_scale": data.get("space-scale"),
            "section_adjustment": data.get("space-adjust-section"),
            "content_gap": data.get("contextual-content-gap"),
            "grid_gap": data.get("contextual-grid-gap"),
            "container_gap": data.get("contextual-container-gap"),
            "section_padding_block": data.get("section-padding-block"),
            "gutter_min": data.get("gutter-min"),
            "gutter_max": data.get("gutter-max"),
        },
        "dimensions": {
            "viewport_min": data.get("vp-min"),
            "viewport_max": data.get("vp-max"),
            "body_max_width": data.get("body-max-width"),
            "root_font_size": data.get("root-font-size"),
        },
        "cards": {
            "enabled": option_on(data.get("option-cards")),
            "selectors": data.get("card-selectors"),
            "padding": data.get("card-padding"),
            "gap": data.get("card-gap"),
            "radius": data.get("card-radius"),
            "shadow": data.get("card-shadow"),
            "button_style": data.get("card-button-style"),
        },
        "forms": {
            "enabled": option_on(data.get("option-forms")),
            "auto_style": option_on(data.get("option-style-forms-automatically")),
            "load_tokens_globally": option_on(data.get("option-load-form-tokens-globally")),
            "font_family": data.get("f-form-font-family"),
            "grid_gap": data.get("f-form-grid-gap"),
            "ws_forms_pro_expected": ws_forms_pro,
            "ws_form_styler_required_external": ws_forms_pro,
        },
        "layout_systems": {
            "content_grid": option_on(data.get("option-content-grid")),
            "grid_variables": option_on(data.get("option-grid-variables")),
            "auto_grid_variables": option_on(data.get("option-auto-grid-variables")),
            "container_gap": option_on(data.get("option-container-gap")),
            "content_gap": option_on(data.get("option-content-gap")),
            "grid_gap": option_on(data.get("option-grid-gap")),
            "smart_spacing": option_on(data.get("option-smart-spacing")),
            "section_padding": option_on(data.get("option-section-padding")),
            "section_space_variables": option_on(data.get("option-section-space-variables")),
            "space_variables": option_on(data.get("option-space-variables")),
        },
        "frameworks": {
            "buttons": option_on(data.get("option-buttons")),
            "cards": option_on(data.get("option-cards")),
            "forms": option_on(data.get("option-forms")),
            "icons": option_on(data.get("option-icons")),
            "basic_overlays": option_on(data.get("option-basic-overlays")),
            "border_variables": option_on(data.get("option-border-variables")),
            "divider_variables": option_on(data.get("option-divider-variables")),
            "box_shadow_variables": option_on(data.get("option-box-shadow-variables")),
            "drop_shadow_variables": option_on(data.get("option-drop-shadow-variables")),
            "text_shadow_variables": option_on(data.get("option-text-shadow-variables")),
            "contextual_color_classes": option_on(data.get("option-contextual-color-classes")),
            "contextual_color_variables": option_on(data.get("option-contextual-color-variables")),
            "relate_background_text": option_on(data.get("option-relate-bg-text")),
        },
        "accessibility": {
            "focus_styles": option_on(data.get("option-focus-styles")),
            "reduce_motion": option_on(data.get("option-reduce-motion")),
            "focus_color": data.get("focus-color"),
            "focus_width": data.get("focus-width"),
            "focus_offset": data.get("focus-offset"),
        },
        "shadows": {
            "box": shadows,
            "drop": drop_shadows,
            "text": text_shadows,
        },
        "surfaces": surfaces,
        "overlays": overlays,
        "custom_global_properties": custom_props,
        "variable_references": sorted(extract_var_references(data)),
        "enabled_options": enabled_options,
        "warnings": warnings,
    }


def print_human(profile: dict) -> None:
    print(f"ACSS settings: {profile['settings_count']} keys")
    if profile.get("timestamp_iso_utc"):
        print(f"Timestamp: {profile['timestamp_iso_utc']}")
    print(f"Form system: {profile['form_system']}")

    print("\nPalette:")
    for role, info in profile["palette"].items():
        print(
            f"  {role:10} enabled={info['enabled']!s:5} "
            f"button={info['button_enabled']!s:5} value={info['value']}"
        )

    print("\nCards:")
    print(json.dumps(profile["cards"], indent=2))

    print("\nForms:")
    print(json.dumps(profile["forms"], indent=2))

    print("\nSpacing:")
    print(json.dumps(profile["spacing"], indent=2))

    print("\nCustom global properties:")
    if profile["custom_global_properties"]:
        for name in profile["custom_global_properties"]:
            print(f"  {name}")
    else:
        print("  none")

    if profile["warnings"]:
        print("\nWarnings:")
        for warning in profile["warnings"]:
            print(f"  - {warning}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Analyze a complete Automatic.css settings export."
    )
    parser.add_argument("settings", help="Path to ACSS settings JSON.")
    parser.add_argument(
        "--ws-forms-pro",
        action="store_true",
        help="Record WS Forms Pro as the form system assumption.",
    )
    parser.add_argument(
        "--json-out",
        help="Write the derived profile to this JSON file.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print JSON profile instead of human-readable output.",
    )
    args = parser.parse_args()

    try:
        data = load_json_object(args.settings)
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 1

    profile = build_profile(data, ws_forms_pro=args.ws_forms_pro)

    if args.json_out:
        Path(args.json_out).write_text(
            json.dumps(profile, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    if args.json:
        print(json.dumps(profile, indent=2, ensure_ascii=False))
    else:
        print_human(profile)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
