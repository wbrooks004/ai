# Pattern Policy

## Active Styling Examples

Only `patterns/acss/` may teach styling.

Active examples must:

- use ACSS as the design-system authority;
- prefer native ACSS subsystems over manually rebuilding them with variables;
- use semantic/BEM identity in Bricks;
- use ACSS behavioral classes/attributes when those activate framework behavior;
- contain no raw Recipe triggers or SCSS-only code;
- avoid automatic device-breakpoint boilerplate;
- pass strict validation.

Read `patterns/acss/ACSS-REQUIREMENTS.md` for Card Framework selectors, button dependencies, contextual backgrounds, section/header spacing behavior, and WS Forms Pro requirements.

## Legacy Patterns

`patterns/legacy/` is structure-only.

Legacy files may teach:

- Bricks wrapper/element shape;
- hierarchy;
- IDs and parent/child reciprocity;
- global-class linkage;
- query/template/nestable structure.

They may **not** teach:

- colors;
- spacing;
- typography;
- borders/radii;
- shadows;
- buttons;
- cards;
- responsive strategy;
- ACSS architecture.

## Migration Rule

To promote a legacy pattern:

1. preserve verified Bricks structure;
2. identify which ACSS subsystem owns each reusable design decision;
3. configure/assume that native subsystem first;
4. keep semantic Bricks/BEM classes for identity;
5. attach ACSS behavior classes/attributes where required;
6. use Card Framework for reusable cards;
7. use native ACSS Buttons for standard buttons;
8. use current Recipe behavior when non-token CSS is needed;
9. remove raw Recipe/SCSS syntax from final JSON;
10. remove unnecessary breakpoint overrides;
11. validate strictly.

A token-only rewrite is not enough. A pattern can use `var(--...)` everywhere and still be architecturally wrong if it manually rebuilds a native ACSS subsystem.
