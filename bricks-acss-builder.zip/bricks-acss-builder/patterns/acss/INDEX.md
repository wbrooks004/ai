# ACSS Pattern Index

The JSON files in this directory are active examples for Bricks + Automatic.css 4.x.

They are intentionally **subsystem-first**: ACSS owns the reusable design system; Bricks owns structure, semantic/BEM identity, and only the component-specific styling ACSS does not already provide.

Read [`ACSS-REQUIREMENTS.md`](ACSS-REQUIREMENTS.md) before using these examples.

| File | Format | ACSS-first behavior |
|---|---|---|
| `hero-centered.json` | Clipboard | `section--xl`, `bg--dark`, Automatic Color Relationships, ACSS button classes |
| `hero-split-image.json` | Clipboard | ACSS section spacing, grid variables/contextual gaps, native button classes |
| `logo-strip.json` | Clipboard | ACSS section spacing, grid/gap system, semantic logo structure |
| `feature-grid.json` | Clipboard | Card Framework-owned cards; `[data-icon]`; ACSS grid/contextual spacing |
| `pricing-table.json` | Clipboard | Card Framework pricing cards; local card-border variant; native ACSS buttons |
| `testimonials-slider.json` | Clipboard | `bg--dark` context + Card Framework testimonial cards |
| `faq-accordion.json` | Clipboard | Bricks nestable structure preserved; ACSS section/spacing/type/border primitives |
| `cta-section.json` | Clipboard | ACSS section rhythm, palette roles and native Accent button |
| `contact-section.json` | Clipboard | Card Framework form panel + **WS Forms Pro shortcode placeholder** |
| `team-grid-acf.json` | Clipboard | ACF loop + Card Framework team cards and `__media` convention |
| `blog-archive-filters.json` | Clipboard | Query/filter structure + Card Framework post cards and `__media` convention |
| `bem-hero.json` | Clipboard | BEM identity + `section--xl` + `bg--dark` + native ACSS buttons |
| `bem-card-grid.json` | Clipboard | Card Framework `.card` wrappers; `[data-icon]`; local card variant token |
| `bem-pricing.json` | Clipboard | Card Framework `.plan` wrappers + native solid/outline button behavior |
| `header-template.json` | Template | `header--s`, semantic header structure, native Primary button |
| `footer-template.json` | Template | `section--l`, `bg--dark`, relationship-aware foregrounds, divider token |
| `popup-newsletter.json` | Template | ACSS popup dimensions/type + **WS Forms Pro shortcode placeholder** |

## Pattern rules

- These examples are not allowed to create their own global spacing/type/color/radius/shadow/button/card systems.
- `patterns/legacy/` is structure-only and must not be used as styling guidance.
- A current ACSS 4.x rule overrides an older pattern convention.
- Standard buttons use ACSS runtime button classes, not manually copied button tokens.
- Reusable cards use Card Framework targeting, not manually rebuilt card defaults.
- Dark contextual sections use ACSS relationship-triggering behavior where appropriate.
- Raw Recipe strings never belong in final paste/import JSON.
- Device breakpoint boilerplate is not generated automatically.

## Structural baseline

The Bricks shapes remain based on the bundled verified structural references. The historical schema baseline is Bricks 2.3.6; do not treat these examples as proof of a newer Bricks schema unless the supplied project/export confirms it.
