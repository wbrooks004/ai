# ACSS Requirements for Active Patterns

These patterns are examples of **ACSS-owned styling**, not standalone design systems.

Their classes, selectors, and assumed subsystem states are examples only. Never copy a pattern or example export's brand values or enabled/disabled feature state into another project without deriving the target design.

Before using a pattern in a real build, generate the complete target ACSS settings JSON first and enable/configure the ACSS subsystems the target design requires.

## Global requirements

For normal builds:

- Standard Spacing and Section Spacing configured
- Contextual spacing enabled where used
- Automatic Spacing enabled when the page structure follows normal section/container/grid conventions
- Typography configured
- Button framework configured for every button role used
- Focus styling enabled
- Reduce Motion enabled when effects are used
- Global border/radius system configured
- required grid variables/features enabled

## Card Framework selectors

When the matching pattern is used, add its wrapper selector to **Cards → Card Selectors** in the target ACSS settings.

| Pattern | Card selector(s) |
|---|---|
| `bem-card-grid.json` | `.card` |
| `bem-pricing.json` | `.plan` |
| `blog-archive-filters.json` | `.post-card` |
| `contact-section.json` | `.contact-section__form-card` |
| `feature-grid.json` | `.feature-card` |
| `pricing-table.json` | `.pricing-card` |
| `team-grid-acf.json` | `.team-card` |
| `testimonials-slider.json` | `.testimonial-card` |

Do not manually restore default card padding/gap/background/border/radius/shadow to these wrappers. The Card Framework should own those defaults.

Card child naming intentionally uses Card Framework conventions where relevant:

- `__media` for card media
- headings for card heading styling
- `[data-icon]` for framework-managed card icons

## Button requirements

Patterns use ACSS runtime button classes rather than duplicating button styling:

- `btn--primary`
- `btn--primary btn--outline`
- `btn--accent`

The target ACSS settings must enable the matching palette role, button group, and outline variant when used.

If the design requires a different semantic button role, change the target ACSS configuration and behavioral class together.

## Contextual backgrounds

Some dark patterns attach `bg--dark` so ACSS Automatic Color Relationships can own foreground text/link/button/icon/focus behavior.

Do not replace this with only `background: var(--bg-dark)` when relationship behavior is intended.

Patterns using this behavior include:

- `bem-hero.json`
- `hero-centered.json`
- `footer-template.json`
- `testimonials-slider.json`

## Section/header spacing

Patterns use ACSS section/header spacing behavior classes such as:

- `section--s`
- `section--l`
- `section--xl`
- `header--s`

rather than duplicating normal section padding values in semantic classes.

## WS Forms Pro

The active form patterns use a Bricks `shortcode` element containing:

`[ws_form id="123"]`

Replace `123` with the real published WS Form Pro form ID.

Before relying on ACSS form styling:

1. enable ACSS Forms / Load Forms;
2. enable **WS Form Styler** in WS Form;
3. configure the ACSS Forms design system;
4. publish the WS Form;
5. insert the real form ID.

Patterns:

- `contact-section.json`
- `popup-newsletter.json`

Do not replace these with a Bricks native Form element unless the user explicitly changes form platforms/workflow.

## Recipe rule

Final pattern JSON must contain runtime-valid CSS only.

Do not store raw:

- `?recipe`
- old `@recipe`
- `@include`
- SCSS-only ACSS functions

If a Recipe is needed, resolve it to the verified runtime CSS before writing final JSON.

## Validation

From the skill root with the official Bricks schema library:

```bash
python scripts/validate_acss_bricks.py --strict --bricks-schema-library references/data/bricks-schema.zip patterns/acss
```

If official schema evidence is intentionally unavailable, a structural-only check may be run with `--allow-unverified-schema`, but its Bricks element/schema conclusions remain NOT VERIFIABLE.

For a real project with a generated target settings file:

```bash
python scripts/validate_acss_bricks.py --strict --acss-settings target-acss.json path/to/output.json
```

The second command verifies project-level constraints such as active button palette roles and Card Framework selectors.
