# Bricks + Automatic.css Builder

A complete AI skill for translating brand/design systems and visual references into complete Automatic.css configuration and maintainable Bricks Builder sections, pages, templates, and components.

The workflow is:

```text
brand / design system / mockup / Figma / brief
        ↓
derive reusable design decisions
        ↓
current ACSS export or compatible complete baseline
        ↓
enable + configure ACSS systems for the target design
        ↓
complete target ACSS settings JSON
        ↓
construct Bricks against that target
        ↓
validate Bricks + ACSS dependencies + dashboard control
```

The skill does **not** create a second global design system and then pipe it through ACSS.

## Defaults

- Automatic.css: current 4.x workflow, conservative with 4.0-era compatibility
- Bricks generic JSON authority: current official Bricks schema library (`bricks-schema.zip`)
- Project-specific Bricks exports/configuration override generic defaults for project state
- Forms: **WS Forms Pro**
- Styling architecture: complete ACSS design system → ACSS behavior/variables/Recipes → semantic Bricks component classes → local CSS only when necessary
- Design goal: reusable visual edits remain controllable from the ACSS dashboard
- Update delivery: complete replacement archive, not patch files

## What is included

```text
bricks/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
│   ├── design-system-to-acss.md
│   ├── acss-settings-workflow.md
│   ├── acss-subsystem-decision-map.md
│   ├── acss-4x.md
│   ├── acss-recipes-4x.md
│   ├── acss-component-frameworks.md
│   ├── acss-background-system.md
│   ├── acss-layout-decision-tree.md
│   ├── acss-effects-accessibility.md
│   ├── acss-mixins-functions-policy.md
│   ├── acss-json-policy.md
│   ├── acss-style-examples.md
│   ├── version-compatibility.md
│   └── Bricks schema/element/query/template references
├── patterns/
│   ├── acss/
│   │   ├── ACSS-REQUIREMENTS.md
│   │   ├── INDEX.md
│   │   └── 17 active JSON examples
│   └── legacy/
│       └── original structure-only JSON examples
└── scripts/
    ├── analyze_acss_settings.py
    ├── validate_acss_settings.py
    ├── diff_acss_settings.py
    ├── validate_acss_bricks.py
    └── acss_common.py
```

## Core principle: subsystem ownership

Before writing CSS, the skill asks:

> Which ACSS subsystem should own this reusable design decision, and will a future dashboard edit propagate through Bricks?

Examples:

- brand palette → ACSS Palette
- foreground relationships → Color Assignments / Automatic Color Relationships
- section rhythm → Section Spacing
- normal container/content/grid rhythm → Automatic + Contextual Spacing
- reusable cards → Card Framework
- standard CTAs → Button Framework/classes
- WS Forms Pro → ACSS Forms + WS Form Styler
- recurring shadows → ACSS Shadow slots
- recurring hero/media treatments → Surface/Overlay systems
- responsive card changes → Card Framework + container-query Recipe behavior
- non-token CSS patterns → current ACSS Recipe
- third-party/global selectors requiring SCSS → ACSS Custom SCSS mixins/functions

Only when ACSS does not appropriately own the requirement should the skill fall back to component CSS or a unique raw value.

## Full ACSS settings workflow

For a new styled build, provide a **complete current ACSS settings export** when one exists, or a compatible complete baseline export for a new site.

A baseline/example export supplies settings structure only. Its brand values and disabled-feature state do not constrain the target site.

The skill should:

1. parse the full export;
2. inspect the design/brand/reference and derive a coherent reusable design system;
3. map reusable decisions to ACSS subsystems;
4. enable/configure the native ACSS settings needed for the new design, even when they were off in the source/baseline;
5. preserve unrelated technical keys;
6. return a **complete target ACSS import JSON**, not a patch;
7. return a change report;
8. validate source vs target;
9. generate Bricks only against the target configuration.

A supplied old/custom global token layer may be preserved when unrelated, but a new build should not extend it when ACSS has native controls for the same role.

## WS Forms Pro

This skill assumes **WS Forms Pro** for form work unless explicitly told otherwise.

For the ACSS 4.x Forms workflow:

- ACSS Forms / Load Forms must be enabled;
- WS Form Styler must be enabled in WS Form;
- form styling is configured in ACSS first;
- Bricks embeds the published WS Form, normally through its builder integration or a verified `[ws_form id="..."]` shortcode;
- local `.form--light` / `.form--dark` behavior is used only when a form needs an explicit scheme override.

The active contact and newsletter patterns use a shortcode placeholder `[ws_form id="123"]`; replace the ID with the real published form ID.

## Cards

Active examples use Card Framework ownership.

When a new card type is introduced:

1. create the semantic wrapper class;
2. add the wrapper selector to ACSS Card Selectors in the target settings;
3. let Card Framework apply defaults;
4. use `--card-*` values only for local variants;
5. use `[data-icon]` for framework-managed icons;
6. use `__media` / `__avatar` conventions where applicable;
7. prefer card-container Recipe/container-query behavior for component-responsive changes.

See `patterns/acss/ACSS-REQUIREMENTS.md`.

## Buttons

Standard buttons use ACSS button classes such as:

```text
btn--primary
btn--primary btn--outline
btn--accent
```

The corresponding palette/button groups must be enabled in the target ACSS settings.

Do not manually copy global button padding, radius, typography, border, transition, and base hover values into every BEM button class.

## Recipes

ACSS 4.x Recipes use `?`.

Recipes are authoring-time expansions, not final runtime CSS syntax.

For generated Bricks JSON:

```text
choose current Recipe
→ verify its behavior
→ resolve/expand it
→ emit ordinary runtime-valid CSS
```

Never leave raw `?recipe`, old `@recipe`, or SCSS-only `@include` syntax in Bricks JSON.

See `references/acss-recipes-4x.md`.

## Mixins and functions

ACSS mixins/functions are for ACSS Custom SCSS/dashboard contexts, not Bricks builder CSS.

The validator rejects common SCSS-only constructs when they appear in Bricks JSON.

## ACSS pattern library

`patterns/acss/` contains the active examples.

Notable changes from the legacy library:

- section/header spacing behavior uses ACSS classes;
- dark contextual sections use `bg--dark` where relationship behavior is intended;
- standard buttons use native ACSS button classes;
- reusable cards depend on Card Framework instead of rebuilding card defaults;
- card icons use `[data-icon]`;
- card media uses `__media` conventions;
- form examples use WS Forms Pro placeholders;
- no raw Recipe syntax;
- no automatic tablet/mobile boilerplate.

`patterns/legacy/` exists only for Bricks structural evidence.

## Validation

### Analyze a current ACSS export

```bash
python scripts/analyze_acss_settings.py current-acss.json --ws-forms-pro
```

Optional profile file:

```bash
python scripts/analyze_acss_settings.py current-acss.json --ws-forms-pro --json-out acss-profile.json
```

### Validate a complete target ACSS import

```bash
python scripts/validate_acss_settings.py current-acss.json target-acss.json
```

Use strict mode once warnings are intentionally resolved:

```bash
python scripts/validate_acss_settings.py current-acss.json target-acss.json --strict
```

### Produce a readable ACSS change report

```bash
python scripts/diff_acss_settings.py current-acss.json target-acss.json > ACSS-CHANGELOG.md
```

### Validate Bricks/skill output

```bash
python scripts/validate_acss_bricks.py --strict .
```

For project-aware cross-validation:

```bash
python scripts/validate_acss_bricks.py --strict --acss-settings target-acss.json path/to/bricks-output.json
```

Use Bricks' official schema library for generic element/settings validation:

```bash
python scripts/sync_bricks_schema.py
python scripts/validate_acss_bricks.py \
  --strict \
  --acss-settings target-acss.json \
  --bricks-schema-library references/data/bricks-schema.zip \
  path/to/bricks-output.json
```

For project/custom elements absent from the official library, add `--bricks-element-registry project-elements.json` as project evidence. It extends project evidence; it does not replace the Bricks-supplied schema library.

The Bricks validator checks JSON syntax, tree integrity, global-class references, active/legacy pattern classification, raw Recipe/SCSS leakage, hard-coded design-system drift, and selected ACSS project dependencies.

## Regression tests

Run the bundled negative/positive regression suite after validator changes:

```bash
python tests/run_regression_tests.py
```

The executable suite verifies that strict validation:
- accepts documented core ACSS tokens;
- accepts elements proven by a supplied official Bricks schema library;
- rejects element settings absent from that schema;
- rejects unknown built-in element names without official/project evidence;
- accepts explicit project/custom element evidence;
- rejects unresolved global-class dependencies;
- rejects cyclic trees;
- rejects unknown ACSS variables;
- rejects optional-subsystem variables when the target settings do not prove enablement;
- fails strict Bricks validation when official schema evidence is absent;
- permits a target ACSS configuration to enable systems that were off in the source/example;
- permits Card Framework availability before a project actually defines card selectors.

Use `tests/ACCEPTANCE-TESTS.md` for behavior-level design-to-ACSS-to-Bricks cases that are not reducible to a deterministic JSON validator.

Add a new regression fixture or acceptance test for every repeatable HIGH or CRITICAL production failure.

## Important version policy

Use Bricks' current official schema library as the generic data-model authority. The former hand-maintained 2.3.6 element allowlist has been removed.

Project configuration controls project-specific state. Current official documentation controls generic product semantics, migrations, and current-version claims. When the official schema library is unavailable, do not invent element-specific keys; mark those conclusions NOT VERIFIABLE.

See `references/bricks-schema-library.md` and `references/version-compatibility.md`.

## Installation

### Claude / skill-capable tools

Use the complete `skill.zip` as the replacement skill archive.

### Other AI tools

Point the tool to `SKILL.md`; it routes to the necessary references and patterns.

Do not copy only one ACSS reference and ignore the control plane—ACSS settings workflow and subsystem ownership are part of the skill's behavior.

## Updating this skill

When this customized skill changes, distribute a **complete replacement archive**.

Do not provide update fragments that require manually merging old/new files.
