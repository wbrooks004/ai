# Changelog

## Design-system-to-dashboard rebuild — 2026-09-02

- Clarified the core workflow as design evidence → complete ACSS target → Bricks composition → dashboard-control validation.
- Added `references/design-system-to-acss.md` for brand/design-system/mockup/Figma ingestion, design-token normalization, mockup fidelity, one-off handling, and dashboard-control checks.
- Changed source ACSS exports from immutable capability whitelists into starting-state evidence: relevant subsystems may be enabled/configured in the target when the design requires them.
- Explicitly isolated example/baseline exports so their brand values and `off` flags never constrain another site.
- Strengthened the Skill mission around constructing Bricks sections/pages/templates/components that consume ACSS-controlled design decisions.
- Added a dashboard-control rule: repeated styles that should be globally editable must inherit/reference ACSS rather than duplicate local literals.
- Added schema-less validation disclosure and `--allow-unverified-schema` for explicitly degraded structural-only checks.
- Removed the blanket warning for an enabled Card Framework with no selectors; selectors are required when actual card targets exist, not merely because Cards are available.
- Added executable regression cases for source-off → target-on ACSS configuration and strict schema evidence.
- Added `tests/ACCEPTANCE-TESTS.md` for design-system ingestion, dashboard propagation, example-export isolation, mockup normalization, one-off exceptions, schema evidence, and requirement traceability.

## Official Bricks schema-library modernization — 2026-09-02

- Renamed the skill to `bricks-acss-builder`.
- Replaced the hand-maintained Bricks 2.3.6 element allowlist with Bricks' official machine-readable schema library as generic JSON authority.
- Added `references/bricks-schema-library.md` and `scripts/sync_bricks_schema.py`.
- Added `--bricks-schema-library` support for official zip or extracted schemas.
- Added element-specific settings validation from Bricks resolved schemas.
- Preserved `--bricks-element-registry` only as project/custom element evidence.
- Added import/dependency reconciliation guidance in `references/bricks-import-reconciliation.md`.
- Reduced `SKILL.md` to a routing/control-plane document with conditional ACSS reference loading.
- Added regression coverage for official-schema-only elements, invalid element settings, and unresolved global-class dependencies.
- Removed the former hand-maintained Bricks 2.3.6 element allowlist.


## Deep-audit corrections — 2026-09-02

- Corrected authority precedence so supplied project ACSS/Bricks configuration controls project state while current official docs control generic semantics, migrations, and version claims.
- Added explicit reference routing for exact Bricks schema and ACSS token/Recipe lookups.
- Changed strict project-aware ACSS validation so documented optional-subsystem variables are not accepted merely because they exist in the bundled token index.
- Added project evidence support through `--bricks-element-registry` for custom or newer Bricks element names.
- Added regression coverage for disabled Card Framework token use and evidence-backed project/custom elements.
- Updated the dated Bricks stable-version verification record to 2.3.12 (2026-08-26) and made current-version verification an explicit runtime requirement.

## Audit hardening — 2026-09-02

- Corrected Bricks Theme Styles guidance so ACSS remains the design-system authority.
- Corrected root-font/rem ownership to resolve from ACSS/project configuration before user clarification.
- Clarified that automated validation does not override the final quality gate.
- Added a machine-readable Bricks 2.3.6 element registry.
- Added strict rejection for unknown built-in element names.
- Added parent-chain cycle detection.
- Added project-aware rejection for unknown ACSS custom-property references.
- Added regression fixtures and `tests/run_regression_tests.py`.


## ACSS subsystem-first rebuild — 2026-08-23

This archive is a complete replacement for the previous customized Bricks skill.

### Workflow

- ACSS is now explicitly the design-system authority.
- New styled builds start from a complete ACSS settings export.
- The skill produces a complete target ACSS settings JSON before styled Bricks JSON.
- Parallel global design systems are prohibited when ACSS has a native owner.
- Added documentation precedence rules for current ACSS 4.x vs legacy 3.x pages.

### ACSS subsystems

Added dedicated workflow guidance for:

- Palette / color assignments / Automatic Color Relationships
- Standard, contextual, automatic, smart, and section spacing
- Typography
- Cards
- Buttons
- WS Forms Pro
- Icons
- Borders and dividers
- Box/drop/text shadows
- Backgrounds
- Surfaces and overlays
- Effects and accessibility
- Grid/Flex/Content Grid/container-query responsive strategy
- Recipes
- Mixins and functions

### WS Forms Pro

- WS Forms Pro is the default form platform.
- ACSS Forms workflow requires WS Form Styler.
- Active contact/newsletter patterns use a WS Form shortcode placeholder instead of Bricks native Form.

### Recipes

- ACSS 4.x `?` Recipe syntax is authoritative.
- Raw Recipe triggers are prohibited in final Bricks JSON.
- Legacy `@recipe` syntax is prohibited.
- Recipe behavior must be resolved to runtime CSS for generated JSON.
- SCSS-only mixins/functions are restricted to ACSS Custom SCSS.

### Pattern library

- Active patterns remain under `patterns/acss/`.
- Legacy patterns remain under `patterns/legacy/`.
- Standard buttons now use ACSS button behavior classes.
- Dark contextual sections use `bg--dark` where relationship behavior is intended.
- Section/header rhythm uses ACSS section/header behavior classes.
- Reusable cards now depend on Card Framework ownership.
- Card icons use `data-icon`.
- Card media naming follows `__media` conventions where relevant.
- Added `patterns/acss/ACSS-REQUIREMENTS.md`.

### Tooling

Added:

- `scripts/analyze_acss_settings.py`
- `scripts/validate_acss_settings.py`
- `scripts/diff_acss_settings.py`
- `scripts/acss_common.py`

Upgraded:

- `scripts/validate_acss_bricks.py`

Validation now includes Bricks tree integrity, global-class references, active/legacy pattern classification, raw Recipe/SCSS leakage, selected ACSS dependency checks, and template-format class validation.

### Packaging

- Added `agents/openai.yaml`.
- Updates are distributed as complete replacement archives.
