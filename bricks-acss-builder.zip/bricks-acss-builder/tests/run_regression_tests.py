#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = ROOT / "scripts" / "validate_acss_bricks.py"
SETTINGS_VALIDATOR = ROOT / "scripts" / "validate_acss_settings.py"
FIX = Path(__file__).resolve().parent / "fixtures"
DEFAULT_ACSS = FIX / "minimal-acss.json"

CASES = [
    {
        "title": "PASS core documented ACSS token",
        "file": "pass-known-token.json",
        "code": 0,
    },
    {
        "title": "PASS element proven by supplied official Bricks schema library",
        "file": "pass-official-schema-element.json",
        "code": 0,
    },
    {
        "title": "FAIL setting absent from official Bricks element schema",
        "file": "fail-invalid-bricks-setting.json",
        "code": 1,
        "text": "is not defined for Bricks element",
    },
    {
        "title": "FAIL unresolved Bricks global-class dependency",
        "file": "fail-missing-global-class.json",
        "code": 1,
        "text": "Referenced global class",
    },
    {
        "title": "FAIL unknown Bricks element without evidence",
        "file": "fail-unknown-element.json",
        "code": 1,
        "text": "Unknown Bricks element name",
    },
    {
        "title": "PASS project/custom Bricks element with supplied evidence",
        "file": "pass-project-element.json",
        "code": 0,
        "extra": ["--bricks-element-registry", str(FIX / "project-element-registry.json")],
    },
    {
        "title": "FAIL cyclic Bricks tree",
        "file": "fail-cycle.json",
        "code": 1,
        "text": "Cyclic parent chain detected",
    },
    {
        "title": "FAIL unknown ACSS token",
        "file": "fail-unknown-acss-token.json",
        "code": 1,
        "text": "Unknown/unverified ACSS custom property",
    },
    {
        "title": "FAIL documented Card token when Cards are disabled",
        "file": "fail-disabled-card-token.json",
        "code": 1,
        "text": "optional subsystem 'Cards'",
        "acss": "acss-cards-disabled.json",
    },
    {
        "title": "FAIL strict Bricks validation without official schema evidence",
        "file": "pass-known-token.json",
        "code": 1,
        "text": "NOT VERIFIABLE",
        "no_schema": True,
    },
]

failed = 0
for case in CASES:
    acss = FIX / case.get("acss", DEFAULT_ACSS.name)
    cmd = [
        sys.executable,
        "-S",
        str(VALIDATOR),
        "--strict",
        "--acss-settings",
        str(acss),
    ]
    if not case.get("no_schema"):
        cmd.extend(["--bricks-schema-library", str(FIX / "bricks-schema")])
    cmd.extend(case.get("extra", []))
    cmd.append(str(FIX / case["file"]))

    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    output = result.stdout + result.stderr
    expected_text = case.get("text")
    ok = result.returncode == case["code"] and (
        expected_text is None or expected_text in output
    )
    print(("PASS" if ok else "FAIL") + ": " + case["title"])
    if not ok:
        failed += 1
        print(output)

SETTINGS_CASES = [
    {
        "title": "PASS target may enable ACSS systems that are off in source/example",
        "source": "source-example-disabled-systems.json",
        "target": "target-enabled-systems.json",
        "code": 0,
    },
    {
        "title": "PASS Card Framework may be enabled before a card selector is needed",
        "source": "acss-cards-enabled-no-selectors.json",
        "target": "acss-cards-enabled-no-selectors.json",
        "code": 0,
    },
]

for case in SETTINGS_CASES:
    cmd = [
        sys.executable,
        str(SETTINGS_VALIDATOR),
        str(FIX / case["source"]),
        str(FIX / case["target"]),
        "--strict",
    ]
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    output = result.stdout + result.stderr
    ok = result.returncode == case["code"]
    print(("PASS" if ok else "FAIL") + ": " + case["title"])
    if not ok:
        failed += 1
        print(output)

if failed:
    print(f"\nRegression suite: {failed} failure(s).")
    raise SystemExit(1)

print("\nRegression suite: all cases passed.")
