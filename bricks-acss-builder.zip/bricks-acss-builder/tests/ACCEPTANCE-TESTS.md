# Bricks + ACSS Acceptance / Regression Tests

Use these behavior-level tests in addition to `run_regression_tests.py`.

Every repeatable CRITICAL or HIGH production failure should be added here or to the executable suite unless an existing test already covers the same failure mode.

## TEST ACSS-DESIGN-001 — Design evidence configures ACSS before Bricks

**Failure being prevented:** Bricks-local styling is created first and ACSS is only partially configured afterward.

**Input**
- complete compatible ACSS source/baseline export;
- brand/design system or mockup with repeated colors, typography, spacing, card geometry, and CTA styles;
- request for Bricks sections/page/template.

**Required references**
- `references/design-system-to-acss.md`
- `references/acss-settings-workflow.md`
- applicable ACSS topic references

**Expected behavior**
- derive reusable design decisions;
- generate a complete target ACSS settings object first;
- enable/configure relevant ACSS subsystems;
- generate Bricks against that target.

**Forbidden behavior**
- recreating the design primarily with per-element Bricks values;
- treating source/example `off` flags as permanent restrictions.

**Pass conditions**
- reusable design decisions have ACSS/global owners;
- Bricks consumes those owners.

**Severity if failed:** CRITICAL

---

## TEST ACSS-DASHBOARD-001 — Global edits remain dashboard-controlled

**Failure being prevented:** visually accurate output that cannot be maintained centrally.

**Input**
- repeated card padding/radius/shadow;
- repeated heading style;
- section rhythm;
- standard CTA style.

**Expected behavior**
Each repeated concern uses its appropriate ACSS subsystem/variable/framework or a semantic component class consuming ACSS.

**Forbidden behavior**
Repeated local literals where ACSS can own the value.

**Pass conditions**
Changing the relevant ACSS setting would propagate to all applicable generated Bricks elements.

**Severity if failed:** CRITICAL

---

## TEST ACSS-EXAMPLE-ISOLATION-001 — Example export does not constrain another site

**Input**
- example/baseline export with Auto Grid, contextual classes, text classes, transitions, radius sizes, shadows, or other systems set `off`;
- new project whose design benefits from those systems.

**Expected behavior**
Treat the example as settings structure. Enable/configure appropriate systems in the target.

**Forbidden behavior**
Avoiding an ACSS system solely because it was off in the example.

**Severity if failed:** HIGH

---

## TEST ACSS-MOCKUP-001 — Normalize measurement noise

**Input**
A mockup where equivalent cards measure approximately 30px, 31px, and 32px padding.

**Expected behavior**
Infer one coherent project spacing/card value unless evidence shows intentional variants.

**Forbidden behavior**
Create three unrelated local values solely to match noisy measurements.

**Severity if failed:** HIGH

---

## TEST ACSS-ONEOFF-001 — Preserve genuine local exceptions

**Input**
A mockup with one intentionally offset decorative element.

**Expected behavior**
Keep the exception local when no reusable ACSS owner is appropriate.

**Forbidden behavior**
Create a new site-wide token/scale for a unique decorative adjustment.

**Severity if failed:** MEDIUM

---

## TEST ACSS-TARGET-ENABLE-001 — Source off → target on

**Input**
Current/source export has a relevant subsystem disabled; user/design requires the behavior.

**Expected behavior**
Enable and configure the subsystem in target ACSS before using it in Bricks.

**Forbidden behavior**
Reimplement equivalent behavior locally because the source state was off.

**Severity if failed:** HIGH

---

## TEST BRICKS-SCHEMA-001 — Schema-less run is visibly unverified

**Input**
Valid-looking Bricks JSON without official Bricks schema evidence.

**Expected behavior**
Strict validation fails or explicitly requires `--allow-unverified-schema`; output says element/schema conclusions are NOT VERIFIABLE.

**Forbidden behavior**
A clean result that can be mistaken for full Bricks schema validation.

**Severity if failed:** HIGH

---

## TEST USER-REQUIREMENTS-001 — Requirement traceability

**Input**
Explicit mockup, content, section, responsive, and interaction requirements.

**Expected behavior**
Every explicit requirement maps to output evidence or is reported as not verifiable/unsupported.

**Severity if failed:** HIGH
